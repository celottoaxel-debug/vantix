// VANTIX — démarrage : charge la version la plus récente de l'application.
// L'installateur fournit une « coquille » (Electron + ce fichier). Les mises à jour téléchargées
// (dossier « updates » des données de l'application) remplacent le code sans réinstallation.
// Si une mise à jour plante deux fois de suite avant d'être déclarée saine, on revient à la version installée.
'use strict';
const { app } = require('electron');
const path = require('path');
const fs = require('fs');

const SHELL = app.getVersion();
const dir = path.join(app.getPath('userData'), 'updates');
const stateFile = path.join(dir, 'state.json');
const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };
const readState = () => { try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { return null; } };
const writeState = (s) => { try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(stateFile, JSON.stringify(s)); } catch {} };

let entry = path.join(__dirname, 'main.js');
let root = null;
const st = readState();
if (st && st.version) {
  if (st.pending && (st.tries || 0) >= 2) {
    st.disabled = st.version; st.pending = false; writeState(st); // deux démarrages ratés : on revient en arrière
  } else if (st.version !== st.disabled && cmp(st.version, SHELL) > 0 && (!st.minShell || cmp(SHELL, st.minShell) >= 0)) {
    const cand = path.join(dir, st.version, 'src', 'main.js');
    if (fs.existsSync(cand)) {
      if (st.pending) { st.tries = (st.tries || 0) + 1; writeState(st); }
      entry = cand; root = path.join(dir, st.version);
    }
  }
}
global.__vxBoot = { shell: SHELL, root, dir, stateFile };
try {
  require(entry);
} catch (e) {
  if (!root) throw e;
  // la mise à jour ne se charge pas : on la désactive et on relance sur la version installée
  const s = readState() || {}; s.disabled = s.version; s.pending = false; writeState(s);
  console.error('[VANTIX] mise à jour inutilisable, retour à la version installée :', e);
  app.relaunch(); app.exit(0);
}
