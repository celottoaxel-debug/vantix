// VANTIX — extension : lit la page ouverte, son robots.txt et son llms.txt, puis note le SEO et la visibilité IA.
// Tout se passe dans le navigateur : rien n'est envoyé ailleurs.
'use strict';

/** Exécutée dans la page : relève tout ce qu'il faut pour noter. */
async function collect() {
  const q = (s) => document.querySelector(s);
  const meta = (n) => { const m = q(`meta[name="${n}"]`) || q(`meta[property="${n}"]`); return m ? (m.getAttribute('content') || '').trim() : ''; };
  const clone = document.body ? document.body.cloneNode(true) : document.createElement('body');
  clone.querySelectorAll('script,style,noscript,nav,header,footer,aside,form,svg').forEach((n) => n.remove());
  const main = clone.querySelector('main, article, [role=main]') || clone;
  const text = (main.textContent || '').replace(/\s+/g, ' ').trim();
  const paras = [...main.querySelectorAll('p')].map((p) => p.textContent.replace(/\s+/g, ' ').trim()).filter((t) => t.split(' ').length >= 8);
  const ld = [];
  for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
    try { const j = JSON.parse(s.textContent); const walk = (o) => { if (!o || typeof o !== 'object') return; if (Array.isArray(o)) return o.forEach(walk); if (o['@type']) [].concat(o['@type']).forEach((t) => ld.push(String(t))); if (o['@graph']) walk(o['@graph']); if (o.mainEntity) walk(o.mainEntity); }; walk(j); } catch {}
  }
  const heads = [...document.querySelectorAll('h2,h3')].map((h) => h.textContent.trim());
  const imgs = [...document.images];
  const host = location.hostname;
  const out = [...document.querySelectorAll('a[href^="http"]')].filter((a) => { try { return new URL(a.href).hostname.replace(/^www\./, '') !== host.replace(/^www\./, ''); } catch { return false; } }).length;
  const get = async (p) => { try { const r = await fetch(location.origin + p, { cache: 'no-store' }); const t = r.ok ? await r.text() : ''; return { status: r.status, text: /<html/i.test(t) ? '' : t.slice(0, 200000) }; } catch { return { status: 0, text: '' }; } };
  const [robots, llms] = await Promise.all([get('/robots.txt'), get('/llms.txt')]);
  return {
    url: location.href, path: location.pathname, title: document.title || '', description: meta('description'), robotsMeta: meta('robots'),
    h1: [...document.querySelectorAll('h1')].map((h) => h.textContent.trim()), lang: document.documentElement.lang || '',
    canonical: (q('link[rel="canonical"]') || {}).href || '', words: text ? text.split(' ').length : 0,
    first: paras[0] || '', questions: heads.filter((h) => /\?$/.test(h) || /^(comment|pourquoi|quel|quelle|combien|quand|où|est-ce|how|what|why|when|which)/i.test(h)).length,
    h2: heads.length, lists: main.querySelectorAll('ul,ol').length, tables: main.querySelectorAll('table').length,
    imgs: imgs.length, noAlt: imgs.filter((i) => !i.hasAttribute('alt')).length, ld: [...new Set(ld)], outbound: out,
    dated: !!(q('time[datetime]') || meta('article:modified_time') || meta('article:published_time') || ld.includes('Article') && /dateModified|datePublished/.test([...document.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent).join(''))),
    author: !!(meta('author') || q('[rel="author"]') || q('[itemprop="author"]') || /"author"/.test([...document.querySelectorAll('script[type="application/ld+json"]')].map((s) => s.textContent).join(''))),
    viewport: !!q('meta[name="viewport"]'), https: location.protocol === 'https:',
    robots, llms,
  };
}

const AI_BOTS = ['GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-SearchBot', 'PerplexityBot', 'Google-Extended', 'CCBot'];
/** Le robot peut-il lire ce chemin ? (groupes User-agent, règle la plus longue gagne) */
function botAllowed(robotsText, bot, path) {
  const groups = []; let cur = null, lastUa = false;
  for (const raw of String(robotsText || '').split(/\r?\n/)) {
    const line = raw.replace(/#.*/, '').trim(); if (!line) continue;
    const m = line.match(/^([a-z-]+)\s*:\s*(.*)$/i); if (!m) continue;
    const k = m[1].toLowerCase(), v = m[2].trim();
    if (k === 'user-agent') { if (!lastUa) { cur = { uas: [], rules: [] }; groups.push(cur); } cur.uas.push(v.toLowerCase()); lastUa = true; }
    else { lastUa = false; if (cur && (k === 'allow' || k === 'disallow')) cur.rules.push({ allow: k === 'allow', path: v }); }
  }
  const b = bot.toLowerCase();
  const g = groups.filter((x) => x.uas.some((u) => u !== '*' && b.includes(u))).concat([]);
  const use = g.length ? g : groups.filter((x) => x.uas.includes('*'));
  let best = null;
  for (const grp of use) for (const r of grp.rules) {
    if (!r.path) { continue; }
    const re = new RegExp('^' + r.path.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\\\$$/, '$'));
    if (re.test(path) && (!best || r.path.length > best.path.length || (r.path.length === best.path.length && r.allow))) best = r;
  }
  return !best || best.allow;
}

function grade(d) {
  const seo = [
    [d.title.length >= 25 && d.title.length <= 65, 'Title', d.title ? `${d.title.length} caractères` : 'absent', 12],
    [d.description.length >= 110 && d.description.length <= 165, 'Meta description', d.description ? `${d.description.length} caractères` : 'absente', 10],
    [d.h1.length === 1, 'Un seul H1', `${d.h1.length} trouvé${d.h1.length > 1 ? 's' : ''}`, 10],
    [!!d.lang, 'Langue déclarée', d.lang || 'absente', 5],
    [!!d.canonical, 'Adresse canonique', d.canonical ? 'présente' : 'absente', 6],
    [!/noindex/i.test(d.robotsMeta), 'Page indexable', /noindex/i.test(d.robotsMeta) ? 'noindex : Google l’ignore' : 'oui', 15],
    [d.imgs === 0 || d.noAlt / d.imgs <= 0.1, 'Textes alternatifs des images', d.imgs ? `${d.noAlt} image${d.noAlt > 1 ? 's' : ''} sans alt sur ${d.imgs}` : 'aucune image', 8],
    [d.words >= 300, 'Contenu suffisant', `${d.words} mots`, 12],
    [d.viewport, 'Adaptée au mobile', d.viewport ? 'oui' : 'pas de balise viewport', 10],
    [d.https, 'HTTPS', d.https ? 'oui' : 'non', 12],
  ];
  const fw = (d.first || '').split(' ').length;
  const blocked = AI_BOTS.filter((b) => !botAllowed(d.robots.text, b, d.path || '/'));
  const geo = [
    [d.first && fw <= 60 && /\b(est|sont|permet|consiste|co[ûu]te|propose|offre|is|are|means|costs|lets)\b/i.test(d.first.split(/[.!?]/)[0] || ''), 'Réponse directe en ouverture', d.first ? 'premier paragraphe : ' + fw + ' mots' : 'pas de paragraphe lisible', 16],
    [d.ld.includes('FAQPage') || d.questions >= 3, 'FAQ ou intertitres en questions', d.ld.includes('FAQPage') ? 'FAQPage balisée' : `${d.questions} intertitre${d.questions > 1 ? 's' : ''} en question`, 12],
    [d.ld.length > 0, 'Données structurées', d.ld.length ? d.ld.slice(0, 5).join(', ') : 'aucune', 14],
    [d.lists + d.tables >= 2, 'Listes ou tableaux', `${d.lists} liste${d.lists > 1 ? 's' : ''}, ${d.tables} tableau${d.tables > 1 ? 'x' : ''}`, 8],
    [d.outbound >= 1, 'Sources citées', `${d.outbound} lien${d.outbound > 1 ? 's' : ''} externe${d.outbound > 1 ? 's' : ''}`, 8],
    [d.dated, 'Date visible', d.dated ? 'oui' : 'absente', 8],
    [d.author, 'Auteur', d.author ? 'indiqué' : 'non indiqué', 6],
    [blocked.length === 0, 'Robots d’IA autorisés', blocked.length ? 'bloqués : ' + blocked.join(', ') : 'tous autorisés', 18],
    [d.llms.status === 200 && /^#\s|\n#\s/.test(d.llms.text), 'Fichier llms.txt', d.llms.status === 200 ? 'présent' : 'absent', 10],
  ];
  const score = (list) => Math.round((list.reduce((s, c) => s + (c[0] ? c[3] : 0), 0) / list.reduce((s, c) => s + c[3], 0)) * 100);
  return { seo, geo, seoScore: score(seo), geoScore: score(geo), blocked };
}

const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const col = (v) => (v >= 75 ? 'var(--ok)' : v >= 50 ? 'var(--warn)' : 'var(--crit)');
function render(d) {
  const g = grade(d);
  const list = (items) => `<ul>${items.map(([ok, label, detail]) => `<li class="${ok ? 'ok' : 'ko'}"><i>${ok ? '✓' : '✕'}</i><div>${esc(label)}<small>${esc(detail)}</small></div></li>`).join('')}</ul>`;
  document.getElementById('out').innerHTML = `<p class="url">${esc(d.url)}</p>
    <div class="scores"><div class="sc"><b style="color:${col(g.seoScore)}">${g.seoScore}</b><span>Score SEO</span></div><div class="sc"><b style="color:${col(g.geoScore)}">${g.geoScore}</b><span>Visibilité IA</span></div></div>
    <h2>Robots d’IA</h2><div class="bots">${AI_BOTS.map((b) => `<span class="bot ${g.blocked.includes(b) ? 'no' : ''}">${g.blocked.includes(b) ? '✕' : '✓'} ${esc(b)}</span>`).join('')}</div>
    <h2>Visibilité dans les IA</h2>${list(g.geo)}<h2>SEO</h2>${list(g.seo)}
    <footer>Pour l’analyse complète du site et les corrections automatiques, ouvrez l’application VANTIX.</footer>`;
}

if (typeof document !== 'undefined') (async () => {
  const out = document.getElementById('out');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !/^https?:/.test(tab.url || '')) { out.innerHTML = '<p class="muted">Ouvrez une page web (http ou https) puis cliquez à nouveau sur l’icône.</p>'; return; }
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collect });
    if (!res || !res.result) throw new Error('page illisible');
    render(res.result);
  } catch (e) {
    out.innerHTML = `<p class="muted">Impossible d’analyser cette page (${esc(e.message || e)}). Les pages internes du navigateur et le Chrome Web Store ne peuvent pas être lues.</p>`;
  }
})();

if (typeof module !== 'undefined') module.exports = { botAllowed, grade };
