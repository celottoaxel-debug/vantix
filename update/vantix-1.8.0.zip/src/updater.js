// VANTIX — mises à jour sans réinstallation : vérifie la dernière version publiée, la télécharge,
// contrôle son empreinte SHA-256, la décompresse dans le dossier de l'application, puis propose de redémarrer.
'use strict';
const { app } = require('electron');
const path = require('path');
const fs = require('fs');
const zlib = require('zlib');
const crypto = require('crypto');

const FEED = 'https://raw.githubusercontent.com/celottoaxel-debug/vantix/main/update/latest.json';
const ALLOWED = /^https:\/\/raw\.githubusercontent\.com\/celottoaxel-debug\/vantix\/main\/update\/vantix-\d+\.\d+\.\d+\.zip$/;
const DOWNLOAD_PAGE = 'https://github.com/celottoaxel-debug/vantix/releases/latest';
const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; };

/** Lit une archive zip (méthodes « stockée » et « deflate ») ; refuse tout chemin qui sortirait du dossier. */
function unzip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 66000); i--) if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error('archive illisible');
  const n = buf.readUInt16LE(eocd + 10); let p = buf.readUInt32LE(eocd + 16);
  const files = [];
  for (let k = 0; k < n; k++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('archive abîmée');
    const method = buf.readUInt16LE(p + 10), crc = buf.readUInt32LE(p + 16), csize = buf.readUInt32LE(p + 20), size = buf.readUInt32LE(p + 24);
    const nlen = buf.readUInt16LE(p + 28), xlen = buf.readUInt16LE(p + 30), clen = buf.readUInt16LE(p + 32), off = buf.readUInt32LE(p + 42);
    const name = buf.slice(p + 46, p + 46 + nlen).toString('utf8');
    p += 46 + nlen + xlen + clen;
    if (name.endsWith('/')) continue;
    if (name.includes('..') || name.startsWith('/') || name.includes('\\') || !/^(package\.json|src\/[\w./-]+)$/.test(name)) throw new Error('chemin refusé dans l’archive : ' + name);
    const lstart = off + 30 + buf.readUInt16LE(off + 26) + buf.readUInt16LE(off + 28);
    const raw = buf.slice(lstart, lstart + csize);
    const data = method === 0 ? raw : method === 8 ? zlib.inflateRawSync(raw) : null;
    if (!data || data.length !== size || (zlib.crc32 && zlib.crc32(data) >>> 0 !== crc >>> 0)) throw new Error('fichier abîmé dans l’archive : ' + name);
    files.push({ name, data });
  }
  return files;
}

function create({ getWindow, version }) {
  const boot = global.__vxBoot || { shell: app.getVersion(), dir: path.join(app.getPath('userData'), 'updates') };
  const dir = boot.dir, stateFile = path.join(dir, 'state.json');
  let status = { state: 'idle', current: version, shell: boot.shell };
  let busy = false;
  const send = (s) => { status = { ...status, ...s }; const w = getWindow(); if (w && !w.isDestroyed()) w.webContents.send('vx:update', status); return status; };
  const readState = () => { try { return JSON.parse(fs.readFileSync(stateFile, 'utf8')); } catch { return {}; } };
  const writeState = (s) => { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(stateFile, JSON.stringify(s)); };

  async function getBuf(url, max) {
    const ctrl = new AbortController(); const t = setTimeout(() => ctrl.abort(), 60000);
    try {
      const res = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { signal: ctrl.signal, headers: { 'cache-control': 'no-cache' } });
      if (!res.ok) throw new Error('erreur ' + res.status);
      const b = Buffer.from(await res.arrayBuffer());
      if (b.length > max) throw new Error('fichier trop gros');
      return b;
    } finally { clearTimeout(t); }
  }

  async function check(manual = false) {
    if (busy) return status;
    busy = true;
    try {
      send({ state: 'checking', error: null });
      const feed = JSON.parse((await getBuf(FEED, 64 * 1024)).toString('utf8'));
      if (!feed.version || !/^\d+\.\d+\.\d+$/.test(feed.version)) throw new Error('annonce de version illisible');
      const st = readState();
      if (cmp(feed.version, version) <= 0) return send({ state: 'uptodate', latest: feed.version, checkedAt: new Date().toISOString() });
      if (st.disabled === feed.version) return send({ state: 'error', error: 'La version ' + feed.version + ' n’a pas démarré correctement sur cet ordinateur : elle a été mise de côté.' });
      if (feed.minShell && cmp(boot.shell, feed.minShell) < 0) return send({ state: 'manual', latest: feed.version, notes: feed.notes || '', url: DOWNLOAD_PAGE });
      if (st.version === feed.version && fs.existsSync(path.join(dir, feed.version, 'src', 'main.js'))) return send({ state: 'ready', latest: feed.version, notes: feed.notes || '' });
      if (!ALLOWED.test(feed.url || '') || !/^[a-f0-9]{64}$/.test(feed.sha256 || '')) throw new Error('adresse de téléchargement non autorisée');
      send({ state: 'downloading', latest: feed.version });
      const zip = await getBuf(feed.url, 30 * 1024 * 1024);
      const sum = crypto.createHash('sha256').update(zip).digest('hex');
      if (sum !== feed.sha256) throw new Error('empreinte incorrecte : téléchargement refusé');
      const files = unzip(zip);
      const pkg = files.find((f) => f.name === 'package.json');
      if (!pkg || JSON.parse(pkg.data.toString('utf8')).version !== feed.version || !files.some((f) => f.name === 'src/main.js')) throw new Error('contenu inattendu');
      const tmp = path.join(dir, feed.version + '.tmp'), dest = path.join(dir, feed.version);
      fs.rmSync(tmp, { recursive: true, force: true });
      for (const f of files) { const out = path.join(tmp, f.name); if (!out.startsWith(tmp + path.sep)) throw new Error('chemin refusé'); fs.mkdirSync(path.dirname(out), { recursive: true }); fs.writeFileSync(out, f.data); }
      fs.rmSync(dest, { recursive: true, force: true });
      fs.renameSync(tmp, dest);
      // on ne garde que la version en cours et la nouvelle
      for (const d of fs.readdirSync(dir)) if (/^\d+\.\d+\.\d+(\.tmp)?$/.test(d) && d !== feed.version && d !== version) fs.rmSync(path.join(dir, d), { recursive: true, force: true });
      writeState({ version: feed.version, minShell: feed.minShell || null, pending: true, tries: 0, disabled: st.disabled && st.disabled !== feed.version ? st.disabled : undefined, at: new Date().toISOString() });
      return send({ state: 'ready', latest: feed.version, notes: feed.notes || '' });
    } catch (e) {
      return send({ state: manual ? 'error' : 'idle', error: (e && e.name === 'AbortError') ? 'pas de réponse' : (e.message || String(e)) });
    } finally { busy = false; }
  }

  function healthy() {
    const st = readState();
    if (st.pending && st.version === version) { st.pending = false; st.tries = 0; writeState(st); }
    return true;
  }
  function restart() { app.relaunch(); app.exit(0); }
  function start() {
    setTimeout(() => check(false), 8000);
    setInterval(() => check(false), 6 * 3600 * 1000);
  }
  return { check, healthy, restart, start, status: () => status, DOWNLOAD_PAGE };
}

module.exports = { create, unzip, cmp, FEED, ALLOWED };
