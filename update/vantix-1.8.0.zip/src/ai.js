// VANTIX — appel IA générique (processus principal) pour les outils : réécriture, vérification de faits, FAQ, assistant…
// Utilise Claude si une clé est enregistrée, sinon ChatGPT. Les clés ne quittent jamais ce processus.
'use strict';

const MODELS = { anthropic: 'claude-haiku-5-5', openai: 'gpt-5.5' };

async function post(fetcher, url, headers, body, timeoutMs) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetcher(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal: ctrl.signal });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = (data.error && (data.error.message || data.error.type)) || data.message || ('erreur ' + res.status);
      const err = new Error(typeof msg === 'string' ? msg : JSON.stringify(msg)); err.status = res.status; throw err;
    }
    return data;
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('pas de réponse après ' + Math.round(timeoutMs / 1000) + ' s');
    throw e;
  } finally { clearTimeout(timer); }
}

/**
 * Envoie une consigne à l'IA disponible.
 * keys : { anthropic, openai } ; web : autoriser la recherche web ; prefer : 'anthropic' | 'openai'.
 */
async function complete({ keys = {}, prompt, system = '', maxTokens = 3000, web = false, prefer, fetcher = fetch, timeoutMs = 120000 }) {
  if (!prompt) throw new Error('consigne vide');
  const order = prefer === 'openai' ? ['openai', 'anthropic'] : ['anthropic', 'openai'];
  const provider = order.find((p) => keys[p]);
  if (!provider) throw new Error('Ajoutez une clé Claude ou ChatGPT (onglet Radar IA) pour utiliser cette fonction.');
  maxTokens = Math.max(200, Math.min(8000, Number(maxTokens) || 3000));
  if (provider === 'anthropic') {
    const body = { model: MODELS.anthropic, max_tokens: maxTokens, messages: [{ role: 'user', content: String(prompt).slice(0, 120000) }] };
    if (system) body.system = String(system).slice(0, 8000);
    if (web) body.tools = [{ type: 'web_search_20250305', name: 'web_search', max_uses: 3 }];
    const data = await post(fetcher, 'https://api.anthropic.com/v1/messages', { 'x-api-key': keys.anthropic, 'anthropic-version': '2023-06-01' }, body, timeoutMs);
    const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text || '').join('').trim();
    if (!text) throw new Error('réponse vide');
    return { provider, model: MODELS.anthropic, text };
  }
  const body = { model: MODELS.openai, input: String(prompt).slice(0, 120000), max_output_tokens: maxTokens };
  if (system) body.instructions = String(system).slice(0, 8000);
  if (web) body.tools = [{ type: 'web_search' }];
  const data = await post(fetcher, 'https://api.openai.com/v1/responses', { authorization: 'Bearer ' + keys.openai }, body, timeoutMs);
  let text = typeof data.output_text === 'string' ? data.output_text : '';
  if (!text) for (const item of data.output || []) if (item.type === 'message') for (const c of item.content || []) if (typeof c.text === 'string') text += c.text;
  if (!text.trim()) throw new Error('réponse vide');
  return { provider, model: MODELS.openai, text: text.trim() };
}

/** Extrait le premier objet ou tableau JSON d'un texte (les IA l'entourent parfois de phrases ou de ```). */
function extractJson(text) {
  const s = String(text || '').replace(/```(?:json)?/gi, '');
  const starts = [s.indexOf('{'), s.indexOf('[')].filter((i) => i >= 0);
  if (!starts.length) return null;
  const start = Math.min(...starts);
  const open = s[start], close = open === '{' ? '}' : ']';
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < s.length; i++) {
    const c = s[i];
    if (inStr) { if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false; continue; }
    if (c === '"') inStr = true;
    else if (c === '{' || c === '[') depth++;
    else if (c === '}' || c === ']') { depth--; if (depth === 0) { try { return JSON.parse(s.slice(start, i + 1)); } catch { return null; } } }
  }
  void close;
  return null;
}

module.exports = { complete, extractJson, MODELS };
