// VANTIX — Radar IA (processus principal) : pose une question à ChatGPT, Claude, Perplexity ou Gemini
// avec recherche web, et renvoie la réponse + les sources citées. Les clés ne quittent jamais ce processus.
'use strict';

const PROVIDERS = {
  openai: { label: 'ChatGPT', defaultModel: 'gpt-5.5', keyHint: /^sk-/ },
  anthropic: { label: 'Claude', defaultModel: 'claude-haiku-5-5', keyHint: /^sk-ant-/ },
  perplexity: { label: 'Perplexity', defaultModel: 'fast', keyHint: /^pplx-/ },
  gemini: { label: 'Gemini', defaultModel: 'gemini-3.5-flash', keyHint: /^AI/ },
};

const LANG_NAMES = { fr: 'français', en: 'anglais', es: 'espagnol', de: 'allemand', it: 'italien', pt: 'portugais', nl: 'néerlandais' };
function instruction(lang) {
  return `Réponds en ${LANG_NAMES[lang] || lang}, naturellement, comme tu le ferais pour n'importe quel utilisateur qui te pose cette question. Quand c'est pertinent, cite des noms précis de services, sites, applications ou marques.`;
}

const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
function addSource(list, url, title) {
  if (!url || typeof url !== 'string') return;
  let domain = hostOf(url);
  // Gemini renvoie des liens de redirection : le vrai domaine est dans le titre
  if (/vertexaisearch\.cloud\.google\.com|googleusercontent\.com/.test(domain) && title && /^[\w.-]+\.[a-z]{2,}$/i.test(title.trim())) domain = title.trim().toLowerCase().replace(/^www\./, '');
  if (!domain) return;
  if (list.some((s) => s.url === url)) return;
  list.push({ url, title: (title || '').slice(0, 200), domain });
}

async function call(fetcher, url, opts, timeoutMs) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetcher(url, { ...opts, signal: ctrl.signal });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const msg = (data.error && (data.error.message || data.error.type)) || data.message || data.detail || ('erreur ' + res.status);
      const err = new Error(typeof msg === 'string' ? msg : JSON.stringify(msg));
      err.status = res.status;
      throw err;
    }
    return data;
  } catch (e) {
    if (e.name === 'AbortError') throw new Error('pas de réponse après ' + Math.round(timeoutMs / 1000) + ' s');
    throw e;
  } finally { clearTimeout(timer); }
}

// ---------- lecture des réponses (exportées pour les tests) ----------
function parseOpenAI(data) {
  const sources = [];
  let text = typeof data.output_text === 'string' ? data.output_text : '';
  const parts = [];
  for (const item of data.output || []) {
    if (item.type !== 'message') continue;
    for (const c of item.content || []) {
      if (typeof c.text === 'string') parts.push(c.text);
      for (const a of c.annotations || []) if (a.type === 'url_citation') addSource(sources, a.url, a.title);
    }
  }
  if (!text) text = parts.join('\n');
  return { text, sources };
}

function parseAnthropic(data) {
  const sources = [];
  const parts = [];
  for (const b of data.content || []) {
    if (b.type === 'text') {
      parts.push(b.text || '');
      for (const c of b.citations || []) if (c.url) addSource(sources, c.url, c.title);
    }
  }
  // les résultats consultés mais non cités comptent moins : on les garde à part
  const consulted = [];
  for (const b of data.content || []) if (b.type === 'web_search_tool_result' && Array.isArray(b.content)) for (const r of b.content) addSource(consulted, r.url, r.title);
  return { text: parts.join('').trim(), sources, consulted };
}

function parsePerplexity(data) {
  const sources = [];
  let text = typeof data.output_text === 'string' ? data.output_text : '';
  const parts = [];
  for (const item of data.output || []) {
    if (item.type === 'search_results') for (const r of item.results || []) addSource(sources, r.url, r.title);
    if (item.type === 'message') for (const c of item.content || []) {
      if (typeof c.text === 'string') parts.push(c.text);
      for (const a of c.annotations || []) if (a.url) addSource(sources, a.url, a.title);
    }
  }
  // ancien format (chat completions), au cas où
  if (!text && !parts.length && data.choices && data.choices[0]) text = (data.choices[0].message || {}).content || '';
  for (const r of data.search_results || []) addSource(sources, r.url, r.title);
  for (const u of data.citations || []) addSource(sources, typeof u === 'string' ? u : u.url, u.title);
  if (!text) text = parts.join('\n');
  return { text, sources };
}

function parseGemini(data) {
  const sources = [];
  const cand = (data.candidates || [])[0] || {};
  const text = ((cand.content || {}).parts || []).map((p) => p.text || '').join('').trim();
  const gm = cand.groundingMetadata || {};
  for (const ch of gm.groundingChunks || []) if (ch.web) addSource(sources, ch.web.uri, ch.web.title);
  return { text, sources, queries: gm.webSearchQueries || [] };
}

// ---------- appel d'une IA ----------
async function ask({ provider, key, model, question, lang = 'fr', fetcher = fetch, timeoutMs = 120000 }) {
  const P = PROVIDERS[provider];
  if (!P) throw new Error('IA inconnue : ' + provider);
  if (!key) throw new Error('aucune clé ' + P.label);
  model = model || P.defaultModel;
  const t0 = Date.now();
  let out;
  if (provider === 'openai') {
    const data = await call(fetcher, 'https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { authorization: 'Bearer ' + key, 'content-type': 'application/json' },
      body: JSON.stringify({ model, instructions: instruction(lang), input: question, tools: [{ type: 'web_search' }] }),
    }, timeoutMs);
    out = parseOpenAI(data);
  } else if (provider === 'anthropic') {
    const data = await call(fetcher, 'https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model, max_tokens: 2500, system: instruction(lang), messages: [{ role: 'user', content: question }], tools: [{ type: 'web_search_20250305', name: 'web_search', max_uses: 3 }] }),
    }, timeoutMs);
    out = parseAnthropic(data);
  } else if (provider === 'perplexity') {
    const data = await call(fetcher, 'https://api.perplexity.ai/v1/agent', {
      method: 'POST',
      headers: { authorization: 'Bearer ' + key, 'content-type': 'application/json' },
      body: JSON.stringify({ preset: model, instructions: instruction(lang), input: question }),
    }, timeoutMs);
    out = parsePerplexity(data);
  } else {
    const data = await call(fetcher, `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
      method: 'POST',
      headers: { 'x-goog-api-key': key, 'content-type': 'application/json' },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: instruction(lang) }] }, contents: [{ role: 'user', parts: [{ text: question }] }], tools: [{ google_search: {} }] }),
    }, timeoutMs);
    out = parseGemini(data);
  }
  if (!out.text) throw new Error('réponse vide ou dans un format inattendu');
  return { provider, model, text: out.text.slice(0, 12000), sources: out.sources.slice(0, 40), consulted: (out.consulted || []).slice(0, 40), ms: Date.now() - t0 };
}

// ---------- idées de questions (avec Claude) ----------
async function suggestQuestions({ key, brand, site, description, competitors, lang = 'fr', n = 15, fetcher = fetch }) {
  const prompt = `Tu aides une marque à mesurer si les assistants IA (ChatGPT, Claude, Perplexity, Gemini) la recommandent.
Marque : ${brand} (${site})
${description ? 'Activité : ' + description + '\n' : ''}Concurrents : ${(competitors || []).join(', ') || 'non précisés'}

Écris ${n} questions réalistes, en ${LANG_NAMES[lang] || lang}, que de vrais clients potentiels posent à une IA AVANT de connaître la marque : recherche d'une solution, comparatifs, « meilleur … pour … », « quelle appli pour … », alternatives aux concurrents. Ne cite jamais ${brand} dans les questions. Varie les besoins et les formulations.
Réponds uniquement par un tableau JSON de chaînes.`;
  const data = await call(fetcher, 'https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'claude-haiku-5-5', max_tokens: 2000, messages: [{ role: 'user', content: prompt }] }),
  }, 60000);
  const text = (data.content || []).map((c) => c.text || '').join('');
  const m = text.match(/\[[\s\S]*\]/);
  if (!m) throw new Error('réponse illisible');
  return JSON.parse(m[0]).filter((q) => typeof q === 'string' && q.trim()).map((q) => q.trim()).slice(0, n);
}

module.exports = { PROVIDERS, ask, suggestQuestions, parseOpenAI, parseAnthropic, parsePerplexity, parseGemini, hostOf };
