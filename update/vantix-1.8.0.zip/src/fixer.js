// VANTIX — application des corrections dans les fichiers d'un site local (processus principal)
// Modifications ciblées du HTML (jamais de réécriture complète), sauvegarde avant chaque changement, annulation possible.
'use strict';
const fs = require('fs');
const path = require('path');

const escAttr = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
const escText = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const escRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function insertInHead(html, snippet) {
  if (/<\/head\s*>/i.test(html)) return html.replace(/<\/head\s*>/i, (m) => '  ' + snippet + '\n' + m);
  if (/<html[^>]*>/i.test(html)) return html.replace(/<html[^>]*>/i, (m) => m + '\n<head>\n  ' + snippet + '\n</head>');
  return snippet + '\n' + html;
}
function setMetaName(html, name, value) {
  const tag = `<meta name="${name}" content="${escAttr(value)}">`;
  const re = new RegExp(`<meta\\b[^>]*\\bname\\s*=\\s*["']${escRe(name)}["'][^>]*>`, 'gi');
  let first = true;
  if (re.test(html)) return html.replace(re, () => { if (first) { first = false; return tag; } return ''; });
  return insertInHead(html, tag);
}

// Chaque correction : { type, key, value }. Retourne { html, done: [], skipped: [] }
function applyEdits(html, edits) {
  const done = [], skipped = [];
  for (const e of edits) {
    const before = html;
    switch (e.type) {
      case 'title': {
        const tag = `<title>${escText(e.value)}</title>`;
        let first = true;
        if (/<title\b[^>]*>[\s\S]*?<\/title\s*>/i.test(html)) html = html.replace(/<title\b[^>]*>[\s\S]*?<\/title\s*>/gi, () => { if (first) { first = false; return tag; } return ''; });
        else html = insertInHead(html, tag);
        break;
      }
      case 'description': html = setMetaName(html, 'description', e.value); break;
      case 'viewport': html = setMetaName(html, 'viewport', e.value); break;
      case 'canonical': {
        const tag = `<link rel="canonical" href="${escAttr(e.value)}">`;
        const re = /<link\b[^>]*\brel\s*=\s*["']canonical["'][^>]*>/gi;
        let first = true;
        if (re.test(html)) html = html.replace(re, () => { if (first) { first = false; return tag; } return ''; });
        else html = insertInHead(html, tag);
        break;
      }
      case 'lang': {
        html = html.replace(/<html\b([^>]*)>/i, (m, attrs) => /\blang\s*=/.test(attrs) ? m.replace(/\blang\s*=\s*(["'])[^"']*\1/i, `lang="${escAttr(e.value)}"`) : `<html lang="${escAttr(e.value)}"${attrs}>`);
        break;
      }
      case 'head': {
        // évite les doublons si le bloc est déjà présent
        const firstLine = e.value.split('\n')[0];
        if (e.key === 'org' && /"@type"\s*:\s*"Organization"/.test(html)) break;
        if (e.key === 'faq' && /"@type"\s*:\s*"FAQPage"/.test(html)) break;
        if (e.key === 'og' && html.includes(firstLine)) break;
        html = insertInHead(html, e.value.replace(/\n/g, '\n  '));
        break;
      }
      case 'alt': {
        const re = new RegExp(`<img\\b(?![^>]*\\balt\\s*=)([^>]*?\\bsrc\\s*=\\s*["']${escRe(e.key)}["'][^>]*?)(\\s*/?)>`, 'gi');
        html = html.replace(re, (m, attrs, close) => `<img${attrs} alt="${escAttr(e.value)}"${close}>`);
        break;
      }
      case 'href': {
        const re = new RegExp(`(\\bhref\\s*=\\s*)(["'])${escRe(e.key)}\\2`, 'g');
        html = html.replace(re, (m, a, q) => `${a}${q}${escAttr(e.value)}${q}`);
        break;
      }
      default: skipped.push(Object.assign({ reason: 'type non géré' }, e)); continue;
    }
    if (html !== before) done.push(e); else skipped.push(Object.assign({ reason: 'déjà correct ou élément introuvable' }, e));
  }
  return { html, done, skipped };
}

// Trouve le fichier HTML qui correspond à un chemin d'URL
function resolveFile(root, urlPath) {
  let p;
  try { p = decodeURIComponent(urlPath || '/'); } catch { p = urlPath || '/'; }
  p = p.split('?')[0].split('#')[0];
  const cands = [];
  if (p.endsWith('/')) cands.push(p + 'index.html', p + 'index.htm', p + 'index.php');
  else if (/\.(html?|php)$/i.test(p)) cands.push(p);
  else cands.push(p + '.html', p + '/index.html', p + '.htm', p + '/index.htm');
  for (const c of cands) {
    const abs = path.resolve(root, '.' + c);
    if (!abs.startsWith(path.resolve(root) + path.sep) && abs !== path.resolve(root)) continue; // jamais en dehors du dossier
    try { if (fs.statSync(abs).isFile()) return path.relative(root, abs); } catch {}
  }
  return null;
}

function scan(root, paths) {
  const out = {};
  for (const p of paths) out[p] = resolveFile(root, p);
  return out;
}

function stamp() { return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19); }

function backupFile(root, backupDir, rel) {
  const src = path.join(root, rel);
  const dst = path.join(backupDir, rel);
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  if (fs.existsSync(src)) fs.copyFileSync(src, dst);
  else fs.writeFileSync(dst + '.vantix-absent', ''); // le fichier n'existait pas : l'annulation le supprimera
}

// ops = { pages: [{url, path, edits}], writes: [{rel, content, mergeBlock?, append?}] }
function apply(root, ops) {
  root = path.resolve(root);
  const id = stamp();
  const backupDir = path.join(root, '.vantix-backups', id);
  const report = { id, files: [], done: 0, skipped: [], notFound: [] };
  for (const pg of ops.pages || []) {
    const rel = resolveFile(root, pg.path);
    if (!rel) { report.notFound.push(pg.url); continue; }
    const abs = path.join(root, rel);
    const html = fs.readFileSync(abs, 'utf8');
    const r = applyEdits(html, pg.edits);
    if (r.done.length) {
      backupFile(root, backupDir, rel);
      fs.writeFileSync(abs, r.html, 'utf8');
      report.files.push({ rel, url: pg.url, changes: r.done.length });
      report.done += r.done.length;
    }
    for (const s of r.skipped) report.skipped.push({ url: pg.url, type: s.type, reason: s.reason });
  }
  for (const w of ops.writes || []) {
    if (/(^|[\\/])\.\.([\\/]|$)/.test(w.rel)) continue;
    const abs = path.join(root, w.rel);
    backupFile(root, backupDir, w.rel);
    let content = w.content;
    if (w.mergeBlock && fs.existsSync(abs)) {
      const old = fs.readFileSync(abs, 'utf8');
      const re = new RegExp(`# BEGIN ${escRe(w.mergeBlock)}[\\s\\S]*?# END ${escRe(w.mergeBlock)}\\n?`);
      content = re.test(old) ? old.replace(re, w.content) : w.content + '\n' + old;
    } else if (w.append && fs.existsSync(abs)) {
      content = fs.readFileSync(abs, 'utf8').replace(/\s*$/, '\n') + w.content;
    }
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    fs.writeFileSync(abs, content, 'utf8');
    report.files.push({ rel: w.rel, changes: 1, written: true });
    report.done += 1;
  }
  if (!report.files.length) { try { fs.rmSync(backupDir, { recursive: true, force: true }); } catch {} report.id = null; }
  return report;
}

function undo(root, id) {
  root = path.resolve(root);
  if (!/^[\w-]+$/.test(id)) throw new Error('identifiant invalide');
  const dir = path.join(root, '.vantix-backups', id);
  if (!fs.existsSync(dir)) throw new Error('Sauvegarde introuvable');
  let restored = 0;
  const walk = (d) => {
    for (const f of fs.readdirSync(d)) {
      const abs = path.join(d, f);
      if (fs.statSync(abs).isDirectory()) { walk(abs); continue; }
      let rel = path.relative(dir, abs);
      if (rel.endsWith('.vantix-absent')) { rel = rel.slice(0, -'.vantix-absent'.length); try { fs.unlinkSync(path.join(root, rel)); } catch {} }
      else fs.copyFileSync(abs, path.join(root, rel));
      restored++;
    }
  };
  walk(dir);
  fs.rmSync(dir, { recursive: true, force: true });
  return { restored };
}

module.exports = { applyEdits, resolveFile, scan, apply, undo };
