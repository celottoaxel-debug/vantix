// VANTIX — mises à jour : bandeau « nouvelle version prête », vérification à la demande
(function () {
  'use strict';
  const api = window.vantix, UI = window.__vxUi;
  if (!api || !api.onUpdate || !UI) return;
  const { $, esc, toast } = UI;
  const box = document.createElement('div');
  box.className = 'updbox'; box.hidden = true; box.setAttribute('role', 'status');
  $('#newBtn').before(box);
  let manual = false;
  function render(s) {
    if (s.state === 'ready') {
      box.hidden = false;
      box.innerHTML = `<b>VANTIX ${esc(s.latest)} est prêt</b><span>${esc(s.notes || 'Nouvelles fonctions et corrections.')}</span><button class="btn" type="button" id="updGo">Redémarrer</button>`;
      $('#updGo').addEventListener('click', () => { $('#updGo').textContent = 'Redémarrage…'; api.updateRestart(); });
    } else if (s.state === 'manual') {
      box.hidden = false;
      box.innerHTML = `<b>VANTIX ${esc(s.latest)} est disponible</b><span>Cette version demande une nouvelle installation, une seule fois.</span><button class="btn" type="button" id="updDl">Télécharger</button>`;
      $('#updDl').addEventListener('click', () => api.openExternal(s.url));
    } else if (s.state === 'downloading') {
      box.hidden = false; box.innerHTML = `<b>Téléchargement de VANTIX ${esc(s.latest)}…</b><span>Vous pouvez continuer à travailler.</span>`;
    } else {
      box.hidden = true;
      if (manual && s.state === 'uptodate') toast('VANTIX est à jour');
      if (manual && s.state === 'error') toast('Mise à jour : ' + s.error);
    }
    if (s.state !== 'checking') manual = false;
  }
  api.onUpdate(render);
  api.updateStatus().then(render).catch(() => {});
  // le pied de la barre latérale sert aussi de bouton « Rechercher une mise à jour »
  const foot = $('#sideFoot');
  foot.title = 'Rechercher une mise à jour'; foot.style.cursor = 'pointer';
  foot.addEventListener('click', () => { manual = true; toast('Recherche d’une mise à jour…'); api.updateCheck(); });
  // l'interface s'est chargée correctement : la version en cours est déclarée saine
  setTimeout(() => api.updateHealthy().catch(() => {}), 5000);
})();
