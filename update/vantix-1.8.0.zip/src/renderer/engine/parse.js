// VANTIX — analyse complète d'une page HTML (chaque balise, chaque mot, chaque lien)
(function (VX) {
  'use strict';
  const U = VX.util;
  const GENERIC_ANCHORS = /^(cliquez ici|ici|click here|here|en savoir plus|lire la suite|read more|learn more|plus|more|voir plus|suite|lien|link|>>|→)$/i;

  const txt = (el) => (el ? el.textContent.replace(/\s+/g, ' ').trim() : '');
  const attr = (doc, sel, a) => { const el = doc.querySelector(sel); return el ? (el.getAttribute(a) || '').trim() : null; };

  function analyzePage(res, ctx) {
    const pageUrl = res.finalUrl || res.url;
    const doc = new DOMParser().parseFromString(res.body || '', 'text/html');
    const base = attr(doc, 'base[href]', 'href');
    const baseUrl = base ? new URL(base, pageUrl).href : pageUrl;
    const h = res.headers || {};
    const p = {
      url: res.url, finalUrl: pageUrl, status: res.status, redirects: res.redirects || [],
      timeMs: res.timeMs, ttfbMs: res.ttfbMs, bytes: res.bytes, truncated: !!res.truncated,
      contentType: res.contentType, depth: ctx.depth,
      headers: {
        encoding: h['content-encoding'] || null, cache: h['cache-control'] || null, server: h['server'] || null,
        poweredBy: h['x-powered-by'] || null, hsts: !!h['strict-transport-security'], xRobots: h['x-robots-tag'] || null,
        csp: !!h['content-security-policy'], xcto: !!h['x-content-type-options'], lastModified: h['last-modified'] || null,
      },
    };

    // --- tête de page ---
    p.title = txt(doc.querySelector('head title') || doc.querySelector('title'));
    p.titleCount = doc.querySelectorAll('title').length;
    p.description = attr(doc, 'meta[name="description" i]', 'content');
    p.descriptionCount = doc.querySelectorAll('meta[name="description" i]').length;
    const canon = attr(doc, 'link[rel~="canonical" i]', 'href');
    p.canonical = canon ? U.normalizeUrl(canon, baseUrl) : null;
    p.canonicalCount = doc.querySelectorAll('link[rel~="canonical" i]').length;
    const robots = ((attr(doc, 'meta[name="robots" i]', 'content') || '') + ',' + (p.headers.xRobots || '')).toLowerCase();
    p.noindex = /noindex|none/.test(robots);
    p.nofollow = /nofollow|none/.test(robots);
    p.lang = (doc.documentElement.getAttribute('lang') || '').trim() || null;
    p.charset = !!doc.querySelector('meta[charset], meta[http-equiv="content-type" i]');
    p.viewport = attr(doc, 'meta[name="viewport" i]', 'content');
    p.favicon = !!doc.querySelector('link[rel~="icon" i]');
    p.hreflang = [...doc.querySelectorAll('link[rel="alternate" i][hreflang]')].map(l => ({ lang: l.getAttribute('hreflang'), href: U.normalizeUrl(l.getAttribute('href') || '', baseUrl) }));
    p.og = {
      title: attr(doc, 'meta[property="og:title" i]', 'content'),
      description: attr(doc, 'meta[property="og:description" i]', 'content'),
      image: attr(doc, 'meta[property="og:image" i]', 'content'),
      type: attr(doc, 'meta[property="og:type" i]', 'content'),
      twitter: attr(doc, 'meta[name="twitter:card" i]', 'content'),
    };
    p.author = attr(doc, 'meta[name="author" i]', 'content');
    p.published = attr(doc, 'meta[property="article:published_time" i]', 'content') || (doc.querySelector('time[datetime]') ? doc.querySelector('time[datetime]').getAttribute('datetime') : null);
    p.modified = attr(doc, 'meta[property="article:modified_time" i]', 'content');

    // --- données structurées ---
    p.schema = { types: [], errors: 0, hasFAQ: false, hasOrg: false, hasArticle: false, hasBreadcrumb: false, hasProduct: false, hasLocal: false, hasHowTo: false, author: false, dates: false };
    const collect = (node) => {
      if (!node || typeof node !== 'object') return;
      if (Array.isArray(node)) return node.forEach(collect);
      const t = node['@type'];
      (Array.isArray(t) ? t : t ? [t] : []).forEach(x => p.schema.types.push(String(x)));
      if (node.author) p.schema.author = true;
      if (node.datePublished || node.dateModified) p.schema.dates = true;
      if (node['@graph']) collect(node['@graph']);
      for (const k in node) if (k !== '@graph' && typeof node[k] === 'object') collect(node[k]);
    };
    doc.querySelectorAll('script[type="application/ld+json" i]').forEach(s => {
      try { collect(JSON.parse(s.textContent)); } catch { p.schema.errors++; }
    });
    doc.querySelectorAll('[itemtype]').forEach(el => { const t = (el.getAttribute('itemtype') || '').split('/').pop(); if (t) p.schema.types.push(t); });
    p.schema.types = [...new Set(p.schema.types)];
    const has = (re) => p.schema.types.some(t => re.test(t));
    p.schema.hasFAQ = has(/^FAQPage$|^QAPage$/i); p.schema.hasOrg = has(/^Organization$|Corporation|^Brand$/i);
    p.schema.hasArticle = has(/Article|BlogPosting|NewsArticle/i); p.schema.hasBreadcrumb = has(/BreadcrumbList/i);
    p.schema.hasProduct = has(/^Product$|^Offer$/i); p.schema.hasLocal = has(/LocalBusiness|Restaurant|Store|Hotel/i); p.schema.hasHowTo = has(/HowTo/i);

    // --- titres ---
    // texte avec un espace entre chaque élément : un titre découpé en lignes (<span>3 jours</span><span>à Paris</span>) reste lisible
    const spaced = (e) => { const c = e.cloneNode(true); c.querySelectorAll('*').forEach(x => x.append(' ')); return txt(c).replace(/\s+([,.;:!?])/g, '$1'); };
    p.headings = [...doc.querySelectorAll('h1,h2,h3,h4,h5,h6')].map(e => ({ level: +e.tagName[1], text: spaced(e) }));
    p.h1 = p.headings.filter(x => x.level === 1).map(x => x.text);
    p.headingSkips = 0;
    for (let i = 1; i < p.headings.length; i++) if (p.headings[i].level - p.headings[i - 1].level > 1) p.headingSkips++;
    p.emptyHeadings = p.headings.filter(x => !x.text).length;
    p.questionHeadings = p.headings.filter(x => /\?\s*$/.test(x.text) || /^(comment|pourquoi|quand|quel|quelle|quels|quelles|qu'est|où|combien|how|what|why|when|which|who|where|can|is|are|do|does)\b/i.test(x.text)).length;

    // --- images ---
    const imgs = [...doc.querySelectorAll('img')];
    p.images = {
      total: imgs.length,
      noAlt: imgs.filter(i => !i.hasAttribute('alt')).length,
      emptyAlt: imgs.filter(i => i.hasAttribute('alt') && !i.getAttribute('alt').trim()).length,
      noDims: imgs.filter(i => !i.getAttribute('width') || !i.getAttribute('height')).length,
      lazy: imgs.filter(i => i.getAttribute('loading') === 'lazy').length,
      list: imgs.slice(0, 200).map(i => ({ src: U.normalizeUrl(i.getAttribute('src') || i.getAttribute('data-src') || '', baseUrl), raw: i.getAttribute('src') || i.getAttribute('data-src') || '', alt: i.getAttribute('alt') })),
    };

    // --- contenu mixte (http sur une page https) ---
    p.mixedContent = 0;
    if (pageUrl.startsWith('https:')) {
      doc.querySelectorAll('img[src],script[src],link[href][rel~="stylesheet" i],iframe[src],video[src],audio[src],source[src]').forEach(el => {
        const v = el.getAttribute('src') || el.getAttribute('href') || '';
        if (/^http:\/\//i.test(v)) p.mixedContent++;
      });
    }
    p.scripts = doc.querySelectorAll('script[src]').length;
    p.stylesheets = doc.querySelectorAll('link[rel~="stylesheet" i]').length;
    p.inlineStyleBytes = [...doc.querySelectorAll('style')].reduce((s, e) => s + e.textContent.length, 0);

    // --- liens (chacun d'entre eux) ---
    p.links = [];
    doc.querySelectorAll('a[href], area[href]').forEach(a => {
      const raw = (a.getAttribute('href') || '').trim();
      const rel = (a.getAttribute('rel') || '').toLowerCase();
      const anchor = (txt(a) || a.getAttribute('aria-label') || (a.querySelector('img[alt]') ? a.querySelector('img[alt]').getAttribute('alt') : '') || '').slice(0, 160);
      let kind = 'page';
      if (/^mailto:/i.test(raw)) kind = 'mailto'; else if (/^tel:/i.test(raw)) kind = 'tel'; else if (/^javascript:/i.test(raw)) kind = 'js'; else if (raw.startsWith('#')) kind = 'anchor';
      const url = kind === 'page' ? U.normalizeUrl(raw, baseUrl) : null;
      if (kind === 'page' && !url) kind = 'invalid';
      p.links.push({
        url, raw: raw.slice(0, 500), anchor, kind,
        internal: url ? U.isInternal(url, ctx.startHost, ctx.includeSubdomains) : false,
        nofollow: /nofollow/.test(rel) || p.nofollow, sponsored: /sponsored/.test(rel), ugc: /ugc/.test(rel),
        blank: a.getAttribute('target') === '_blank', noopener: /noopener|noreferrer/.test(rel),
        generic: GENERIC_ANCHORS.test(anchor), empty: !anchor,
      });
    });

    // --- texte et mots ---
    const body = doc.body ? doc.body.cloneNode(true) : doc.createElement('body');
    body.querySelectorAll('script,style,noscript,template,svg,iframe').forEach(e => e.remove());
    // un espace après chaque élément, pour ne jamais coller deux mots de blocs voisins
    body.querySelectorAll('*').forEach(e => e.append(' '));
    const main = body.querySelector('main, article, [role="main"]') || body;
    const fullText = txt(body);
    // Next.js / React : contenu envoyé plus tard dans des blocs cachés (<div hidden id="S:0">), remis en place par JavaScript.
    // Les robots d'IA qui n'exécutent pas JavaScript ne le voient pas à sa place : on le compte quand même, et on le signale.
    const streamed = [...body.querySelectorAll('div[hidden][id^="S:"], template[id^="B:"] + div[hidden]')].filter(e => !main.contains(e) || main === body);
    const streamedText = streamed.map(txt).join(' ');
    p.streamedWords = streamedText ? U.tokenize(streamedText).length : 0;
    let mainText = txt(main);
    if (main !== body && p.streamedWords > U.tokenize(mainText).length) mainText = (mainText + ' ' + streamedText).trim();
    const words = U.tokenize(mainText);
    p.wordCount = U.tokenize(fullText).length;
    p.mainWordCount = words.length;
    p.textRatio = res.bytes ? Math.round((fullText.length / res.bytes) * 1000) / 10 : 0;
    p.readability = U.readability(mainText, p.lang);
    const freq = new Map(), bi = new Map();
    let prev = null;
    for (const w of words) {
      const stop = U.STOP.has(w) || w.length < 3 || /^\d+$/.test(w);
      if (!stop) freq.set(w, (freq.get(w) || 0) + 1);
      if (prev && !stop) bi.set(prev + ' ' + w, (bi.get(prev + ' ' + w) || 0) + 1);
      prev = stop ? null : w;
    }
    p.keywords = U.topCounts(freq, 40);
    p.bigrams = U.topCounts(bi, 20).filter(x => x[1] > 1);
    p.uniqueWords = freq.size;
    p.contentHash = words.length > 20 ? U.hash(words.join(' ')) : null;
    p.shingles = words.length > 50 ? U.shingles(words) : [];
    // le mot-clé principal apparaît-il dans le title, le H1, la description, l'URL ?
    const kw = p.keywords[0] ? p.keywords[0][0] : null;
    p.focus = kw ? {
      word: kw, count: p.keywords[0][1], density: Math.round((p.keywords[0][1] / Math.max(1, words.length)) * 1000) / 10,
      inTitle: (p.title || '').toLowerCase().includes(kw), inH1: p.h1.join(' ').toLowerCase().includes(kw),
      inDesc: (p.description || '').toLowerCase().includes(kw), inUrl: decodeURIComponent(pageUrl).toLowerCase().includes(kw),
    } : null;

    // --- signaux GEO (capacité à être cité par une IA) ---
    const firstP = [...main.querySelectorAll('p')].map(txt).find(t => t.length > 40) || '';
    // paires question / réponse (pour générer un balisage FAQPage)
    const qa = [];
    main.querySelectorAll('h2,h3,h4,dt,summary').forEach(hd => {
      if (qa.length >= 12) return;
      const q = txt(hd);
      if (!q || !(/\?\s*$/.test(q))) return;
      let n = hd.tagName === 'SUMMARY' ? hd.parentElement && hd.parentElement.querySelector('p') : hd.nextElementSibling, a = '';
      for (let i = 0; n && i < 4 && a.length < 400; i++, n = n.nextElementSibling) { if (/^H[1-6]$/.test(n.tagName)) break; a += ' ' + txt(n); }
      a = a.trim();
      if (a.length > 30) qa.push({ q, a: a.slice(0, 600) });
    });
    const numbers = (mainText.match(/\b\d+(?:[.,]\d+)?\s?(%|€|\$|euros?|ans|mois|km|kg|millions?|milliards?)/gi) || []).length;
    const outboundSources = p.links.filter(l => l.kind === 'page' && !l.internal && !l.nofollow).length;
    p.geo = {
      answerFirst: firstP.length >= 40 && firstP.length <= 320,
      firstParagraph: firstP.slice(0, 320),
      questionHeadings: p.questionHeadings,
      lists: main.querySelectorAll('ul li, ol li').length,
      tables: main.querySelectorAll('table').length,
      definitions: main.querySelectorAll('dl, dfn').length,
      stats: numbers,
      sources: outboundSources,
      author: !!(p.author || p.schema.author || doc.querySelector('[rel~="author"], .author, [itemprop="author"]')),
      dated: !!(p.published || p.modified || p.schema.dates),
      faqSchema: p.schema.hasFAQ,
      qa,
      longParagraphs: [...main.querySelectorAll('p')].filter(e => U.tokenize(txt(e)).length > 120).length,
    };
    return p;
  }

  VX.parse = { analyzePage };
})(window.VX = window.VX || {});
