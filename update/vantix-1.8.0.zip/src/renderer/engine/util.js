// VANTIX — outils partagés du moteur
(function (VX) {
  'use strict';

  const TRACKING = /^(utm_\w+|gclid|fbclid|msclkid|mc_cid|mc_eid|_ga|ref|yclid)$/i;

  // Normalise une URL pour dédoublonner : sans fragment, sans paramètres de suivi, hôte en minuscule
  function normalizeUrl(href, base) {
    let u;
    try { u = new URL(href, base); } catch { return null; }
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    u.hash = '';
    u.hostname = u.hostname.toLowerCase();
    if ((u.protocol === 'http:' && u.port === '80') || (u.protocol === 'https:' && u.port === '443')) u.port = '';
    const keep = [];
    u.searchParams.forEach((v, k) => { if (!TRACKING.test(k)) keep.push([k, v]); });
    keep.sort((a, b) => a[0].localeCompare(b[0]));
    u.search = keep.length ? '?' + keep.map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(v)).join('&') : '';
    if (!u.pathname) u.pathname = '/';
    return u.href;
  }

  const rootDomain = (host) => {
    const parts = host.replace(/^www\./, '').split('.');
    return parts.length > 2 && /^(co|com|org|gouv|ac|net)$/.test(parts[parts.length - 2]) ? parts.slice(-3).join('.') : parts.slice(-2).join('.');
  };

  // startHost peut contenir un port (ex. localhost:8080) : on compare hôte + port
  function isInternal(url, startHost, includeSubdomains) {
    let h;
    try { h = new URL(url).host; } catch { return false; }
    const a = h.replace(/^www\./, ''), b = startHost.replace(/^www\./, '');
    if (a === b) return true;
    if (!includeSubdomains) return false;
    const pa = a.split(':')[1] || '', pb = b.split(':')[1] || '';
    return pa === pb && rootDomain(a.split(':')[0]) === rootDomain(b.split(':')[0]);
  }

  const SKIP_EXT = /\.(jpe?g|png|gif|webp|avif|svg|ico|bmp|tiff?|pdf|zip|rar|7z|gz|tar|mp4|webm|mov|avi|mp3|wav|ogg|woff2?|ttf|otf|eot|css|js|json|xml|txt|csv|xlsx?|docx?|pptx?|exe|dmg|apk)$/i;
  const isLikelyPage = (url) => { try { return !SKIP_EXT.test(new URL(url).pathname); } catch { return false; } };

  // Mots vides français + anglais (pour l'analyse des mots-clés)
  const STOP = new Set(('a à afin ai aie aient aies ait alors après as au aucun aucune aujourd auprès aussi autre autres aux avaient avais avait avant avec avez aviez avoir avons ayant b bah beaucoup bien bon c ça car ce ceci cela celle celles celui cependant certain certaine certaines certains ces cet cette ceux chacun chaque chez ci comme comment d dans de des depuis devant doit donc dont du durant e elle elles en encore entre es est et étaient étais était étant été être eu eux f faire fait fois font g h hors i ici il ils j je jusqu l la là le les leur leurs lors lorsque lui m ma mais me même mes moi moins mon n ne ni non nos notre nous o on ont ou où où p par parce pas peu peut peuvent plus plusieurs pour pourquoi qu quand que quel quelle quelles quels qui quoi s sa sans se selon ses si sien sinon soi soit son sont sous suis sur t ta te tes toi ton tous tout toute toutes très tu u un une unes uns v va vers voici voilà vos votre vous vu y ' +
    'about above after again against all also am an and any are aren as at be because been before being below between both but by can cannot could did do does doing down during each few for from further get got had has have having he her here hers herself him himself his how i if in into is it its itself just let me more most my myself no nor not now of off on once only or other our ours out over own same she should so some such than that the their theirs them then there these they this those through to too under until up us very was we were what when where which while who whom why will with would you your yours yourself www http https com fr').split(/\s+/));

  function tokenize(text) {
    return (text.toLowerCase().normalize('NFC').match(/[\p{L}\p{N}][\p{L}\p{N}'’-]*/gu) || [])
      .map(w => w.replace(/^['’-]+|['’-]+$/g, '').replace(/^(l|d|j|m|n|s|t|c|qu|jusqu|lorsqu)['’]/, ''))
      .filter(Boolean);
  }

  function syllables(word) {
    const m = word.toLowerCase().match(/[aeiouyàâäéèêëîïôöùûüÿœæ]+/g);
    return Math.max(1, m ? m.length : 1);
  }

  // Lisibilité : Kandel & Moles pour le français, Flesch pour l'anglais (0 à 100, plus haut = plus simple)
  function readability(text, lang) {
    const sentences = Math.max(1, (text.match(/[.!?…]+(\s|$)/g) || []).length);
    const words = tokenize(text);
    if (words.length < 30) return null;
    const syl = words.reduce((s, w) => s + syllables(w), 0);
    const wps = words.length / sentences, spw = syl / words.length;
    const fr = !lang || /^fr/i.test(lang);
    const score = fr ? 207 - 1.015 * wps - 73.6 * spw : 206.835 - 1.015 * wps - 84.6 * spw;
    return Math.round(Math.max(0, Math.min(100, score)));
  }

  // Empreinte de contenu (FNV-1a) pour repérer les pages en double
  function hash(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(36);
  }

  // Ensemble de « shingles » de 5 mots, pour la similarité entre pages
  function shingles(words, n = 5, cap = 400) {
    const set = new Set();
    for (let i = 0; i + n <= words.length && set.size < cap; i++) set.add(hash(words.slice(i, i + n).join(' ')));
    return [...set];
  }
  function jaccard(a, b) {
    if (!a.length || !b.length) return 0;
    const A = new Set(a); let inter = 0;
    for (const x of b) if (A.has(x)) inter++;
    return inter / (A.size + b.length - inter);
  }

  function topCounts(map, n) {
    return [...map.entries()].sort((a, b) => b[1] - a[1]).slice(0, n);
  }

  async function pool(items, concurrency, fn, shouldStop) {
    let i = 0;
    const workers = Array.from({ length: Math.max(1, concurrency) }, async () => {
      while (i < items.length) {
        if (shouldStop && shouldStop()) return;
        const idx = i++;
        await fn(items[idx], idx);
      }
    });
    await Promise.all(workers);
  }

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));

  VX.util = { normalizeUrl, isInternal, isLikelyPage, tokenize, STOP, readability, hash, shingles, jaccard, topCounts, pool, sleep, rootDomain };
})(window.VX = window.VX || {});
