// VANTIX — exploration complète d'un site : robots.txt, sitemaps, chaque page, chaque lien
(function (VX) {
  'use strict';
  const U = VX.util;
  const AI_BOTS = ['GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-SearchBot', 'Claude-User', 'anthropic-ai', 'PerplexityBot', 'Perplexity-User', 'Google-Extended', 'Applebot-Extended', 'Bingbot', 'Googlebot', 'CCBot', 'Bytespider', 'meta-externalagent', 'Amazonbot', 'DuckAssistBot', 'MistralAI-User'];

  // ---------- robots.txt ----------
  function parseRobots(text) {
    const groups = []; const sitemaps = []; let cur = null; let lastWasAgent = false;
    for (const rawLine of (text || '').split(/\r?\n/)) {
      const line = rawLine.replace(/#.*/, '').trim();
      if (!line) continue;
      const i = line.indexOf(':'); if (i < 0) continue;
      const key = line.slice(0, i).trim().toLowerCase(), val = line.slice(i + 1).trim();
      if (key === 'user-agent') {
        if (!cur || !lastWasAgent) { cur = { agents: [], rules: [], delay: null }; groups.push(cur); }
        cur.agents.push(val.toLowerCase()); lastWasAgent = true; continue;
      }
      lastWasAgent = false;
      if (key === 'sitemap') { sitemaps.push(val); continue; }
      if (!cur) continue;
      if (key === 'disallow' || key === 'allow') cur.rules.push({ allow: key === 'allow', path: val });
      if (key === 'crawl-delay') cur.delay = parseFloat(val) || null;
    }
    return { groups, sitemaps };
  }
  function groupFor(robots, agent) {
    const a = agent.toLowerCase();
    return robots.groups.find(g => g.agents.some(x => x !== '*' && a.includes(x))) || robots.groups.find(g => g.agents.includes('*')) || null;
  }
  function ruleMatch(path, rule) {
    if (!rule.path) return -1;
    const re = new RegExp('^' + rule.path.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\\\$$/, '$'));
    return re.test(path) ? rule.path.length : -1;
  }
  function allowed(robots, agent, url) {
    if (!robots) return true;
    const g = groupFor(robots, agent); if (!g) return true;
    let path; try { const u = new URL(url); path = u.pathname + u.search; } catch { return true; }
    let best = -1, allow = true;
    for (const r of g.rules) {
      const m = ruleMatch(path, r);
      if (m > best || (m === best && r.allow)) { if (m >= 0) { best = m; allow = r.allow; } }
    }
    return allow;
  }
  function aiBotAccess(robots, origin) {
    return AI_BOTS.map(bot => {
      const g = robots ? robots.groups.find(gr => gr.agents.some(x => x === bot.toLowerCase())) : null;
      return { bot, explicit: !!g, home: allowed(robots, bot, origin + '/'), blog: allowed(robots, bot, origin + '/blog/') };
    });
  }

  // ---------- sitemaps ----------
  async function readSitemaps(origin, robotsSitemaps, fetchPage, log, cap) {
    const queue = [...new Set([...robotsSitemaps, origin + '/sitemap.xml', origin + '/sitemap_index.xml'])];
    const seen = new Set(); const urls = new Map(); const files = [];
    while (queue.length && seen.size < 60) {
      const sm = queue.shift(); if (seen.has(sm)) continue; seen.add(sm);
      const r = await fetchPage({ url: sm });
      const ok = r.ok && r.status === 200 && /<(urlset|sitemapindex)/i.test(r.body || '');
      files.push({ url: sm, status: r.status, ok, count: 0, fromRobots: robotsSitemaps.includes(sm) });
      if (!ok) continue;
      const xml = new DOMParser().parseFromString(r.body, 'text/xml');
      const f = files[files.length - 1];
      xml.querySelectorAll('sitemap > loc').forEach(l => queue.push(l.textContent.trim()));
      xml.querySelectorAll('url').forEach(u => {
        if (urls.size >= cap) return;
        const loc = u.querySelector('loc'); if (!loc) return;
        const n = U.normalizeUrl(loc.textContent.trim()); if (!n) return;
        const lm = u.querySelector('lastmod');
        urls.set(n, { lastmod: lm ? lm.textContent.trim() : null, sitemap: sm }); f.count++;
      });
      log && log(`Sitemap lu : ${sm} (${f.count} adresses)`);
    }
    return { files: files.filter(f => f.ok || f.fromRobots), urls };
  }

  // ---------- exploration ----------
  async function crawl(opts, hooks) {
    const o = Object.assign({ maxPages: 500, concurrency: 4, respectRobots: true, checkExternal: true, includeSubdomains: false, useSitemaps: true, delayMs: 0, maxExternal: 1500 }, opts);
    const fetchPage = hooks.fetchPage;
    const log = hooks.log || (() => {}), progress = hooks.progress || (() => {});
    const stop = () => hooks.isCancelled && hooks.isCancelled();
    const t0 = performance.now();

    let start = U.normalizeUrl(/^https?:\/\//i.test(o.url) ? o.url : 'https://' + o.url);
    if (!start) throw new Error('Adresse invalide. Exemple : monsite.fr');
    log('Connexion à ' + start);
    let first = await fetchPage({ url: start });
    if (!first.ok && start.startsWith('https:')) { // repli en http si le https ne répond pas
      const alt = start.replace(/^https:/, 'http:');
      const r2 = await fetchPage({ url: alt });
      if (r2.ok) { first = r2; start = alt; }
    }
    if (!first.ok) throw new Error(`Le site ne répond pas (${first.error || 'erreur ' + first.status}). Vérifiez l'adresse.`);
    const home = U.normalizeUrl(first.finalUrl);
    const origin = new URL(home).origin, startHost = new URL(home).host, hostOnly = new URL(home).hostname, port = new URL(home).port;
    const ctxBase = { startHost, includeSubdomains: o.includeSubdomains };

    // robots.txt et llms.txt
    const rr = await fetchPage({ url: origin + '/robots.txt' });
    const robotsText = rr.ok && rr.status === 200 && !/<html/i.test(rr.body || '') ? rr.body : null;
    const robots = robotsText ? parseRobots(robotsText) : null;
    log(robotsText ? 'robots.txt trouvé' : 'Pas de robots.txt');
    const lr = await fetchPage({ url: origin + '/llms.txt' });
    const llms = { status: lr.status, ok: lr.ok && lr.status === 200 && !/<html/i.test(lr.body || ''), length: (lr.body || '').length, preview: lr.ok && lr.status === 200 ? (lr.body || '').slice(0, 1500) : null };
    const lfr = await fetchPage({ url: origin + '/llms-full.txt' });
    llms.full = lfr.ok && lfr.status === 200 && !/<html/i.test(lfr.body || '');

    // variantes : http -> https, www / sans www
    const variants = [];
    const variantUrls = new Set();
    const isIp = /^[\d.]+$|^\[|^localhost$/.test(hostOnly);
    const hostAlt = (hostOnly.startsWith('www.') ? hostOnly.slice(4) : 'www.' + hostOnly) + (port ? ':' + port : '');
    if (!port) variantUrls.add((home.startsWith('https:') ? 'http://' : 'https://') + startHost + '/');
    if (!isIp) { variantUrls.add('https://' + hostAlt + '/'); variantUrls.add('http://' + hostAlt + '/'); }
    for (const v of variantUrls) {
      if (v === home) continue;
      const r = await fetchPage({ url: v, wantBody: false });
      let finalOk = false; try { finalOk = r.ok && U.normalizeUrl(r.finalUrl) === home; } catch {}
      variants.push({ url: v, status: r.status, finalUrl: r.finalUrl, redirectsToHome: finalOk, error: r.error || null, hops: (r.redirects || []).length });
    }

    // sitemaps
    let sitemap = { files: [], urls: new Map() };
    if (o.useSitemaps) sitemap = await readSitemaps(origin, robots ? robots.sitemaps : [], fetchPage, log, 50000);

    // file d'exploration
    const pages = new Map();       // url -> page analysée
    const resources = new Map();   // url -> {status, contentType} pour les non-HTML
    const blocked = [];            // bloquées par robots.txt
    const queued = new Set(); const queue = [];
    const discovered = new Map();  // url -> {depth, from}
    const enqueue = (url, depth, from) => {
      if (!url || queued.has(url)) return;
      if (!U.isInternal(url, startHost, o.includeSubdomains) || !U.isLikelyPage(url)) return;
      if (o.respectRobots && robots && !allowed(robots, 'VANTIXBot', url)) { if (!blocked.includes(url)) blocked.push(url); return; }
      queued.add(url); discovered.set(url, { depth, from }); queue.push(url);
    };
    enqueue(home, 0, null);
    if (o.useSitemaps) for (const u of sitemap.urls.keys()) enqueue(u, 99, 'sitemap');
    // les pages venant du sitemap passent après les pages liées (priorité au maillage)
    queue.sort((a, b) => discovered.get(a).depth - discovered.get(b).depth);

    const robotsDelay = robots && groupFor(robots, 'VANTIXBot') && groupFor(robots, 'VANTIXBot').delay ? groupFor(robots, 'VANTIXBot').delay * 1000 : 0;
    const delay = Math.max(o.delayMs || 0, o.respectRobots ? Math.min(robotsDelay, 10000) : 0);
    let done = 0, active = 0;

    const worker = async () => {
      while (!stop()) {
        if (pages.size + active >= o.maxPages) return;
        const url = queue.shift();
        if (!url) { if (active === 0) return; await U.sleep(60); continue; }
        active++;
        try {
          const meta = discovered.get(url);
          const res = await fetchPage({ url });
          const finalN = res.ok ? U.normalizeUrl(res.finalUrl) : null;
          const isHtml = res.ok && /html/i.test(res.contentType || '') && res.body;
          if (res.ok && res.redirects && res.redirects.length && finalN && finalN !== url) {
            // adresse qui redirige : on la note, et on explore la destination comme une page à part
            pages.set(url, { url, finalUrl: finalN, status: res.redirects[0].status, finalStatus: res.status, redirectTo: finalN, redirects: res.redirects, timeMs: res.timeMs, depth: meta.depth, links: [], html: false, isRedirect: true });
            enqueue(finalN, meta.depth, url);
          } else if (!res.ok || !isHtml) {
            if (res.ok && !isHtml && res.status === 200) resources.set(url, { status: res.status, contentType: res.contentType });
            pages.set(url, { url, finalUrl: res.finalUrl, status: res.status, error: res.error || (res.ok && !isHtml ? 'Pas une page HTML' : null), redirects: res.redirects || [], timeMs: res.timeMs, depth: meta.depth, links: [], html: false });
          } else {
            const page = VX.parse.analyzePage(res, Object.assign({ depth: meta.depth }, ctxBase));
            page.html = true;
            page.fromSitemap = sitemap.urls.has(url);
            pages.set(url, page);
            if (!page.nofollow) for (const l of page.links) if (l.kind === 'page' && l.internal && !l.nofollow) {
              const d = discovered.get(l.url);
              if (d && d.depth > meta.depth + 1) d.depth = meta.depth + 1; // un lien rapproche une page du sitemap
              enqueue(l.url, meta.depth + 1, url);
            }
          }
        } catch (e) {
          pages.set(url, { url, status: 0, error: String(e.message || e), links: [], html: false, depth: discovered.get(url).depth });
        } finally {
          active--; done++;
          progress({ phase: 'pages', done: pages.size, queued: queue.length, current: url, max: o.maxPages });
          if (delay) await U.sleep(delay);
        }
      }
    };
    await Promise.all(Array.from({ length: o.concurrency }, worker));
    const truncated = queue.length > 0;

    // profondeur réelle (clics depuis l'accueil) d'après le graphe des liens
    const depthMap = new Map([[home, 0]]); const bfs = [home];
    while (bfs.length) {
      const u = bfs.shift(); const pg = pages.get(u); if (!pg) continue;
      if (pg.redirectTo && !depthMap.has(pg.redirectTo)) { depthMap.set(pg.redirectTo, depthMap.get(u)); bfs.push(pg.redirectTo); }
      for (const l of pg.links || []) if (l.kind === 'page' && l.internal && !depthMap.has(l.url)) { depthMap.set(l.url, depthMap.get(u) + 1); bfs.push(l.url); }
    }
    for (const [u, pg] of pages) pg.depth = depthMap.has(u) ? depthMap.get(u) : null;

    // vérification des liens externes
    const external = new Map();
    if (o.checkExternal && !stop()) {
      const ext = new Set();
      for (const pg of pages.values()) for (const l of pg.links || []) if (l.kind === 'page' && !l.internal) ext.add(l.url);
      const list = [...ext].slice(0, o.maxExternal);
      let n = 0;
      await U.pool(list, 6, async (url) => {
        let r = await fetchPage({ url, method: 'HEAD', wantBody: false, timeoutMs: 12000 });
        if (!r.ok || r.status === 405 || r.status === 403 || r.status === 501 || r.status === 0) r = await fetchPage({ url, wantBody: false, timeoutMs: 15000 });
        external.set(url, { status: r.status, error: r.error || null, finalUrl: r.finalUrl, redirects: (r.redirects || []).length });
        n++; progress({ phase: 'external', done: n, total: list.length, current: url });
      }, stop);
      if (ext.size > list.length) log(`${ext.size - list.length} liens externes non vérifiés (limite atteinte)`);
    }

    // liens internes vers des adresses non explorées (limite de pages) : on vérifie leur statut
    const internalTargets = new Set();
    for (const pg of pages.values()) for (const l of pg.links || []) if (l.kind === 'page' && l.internal && !pages.has(l.url)) internalTargets.add(l.url);
    const internalExtra = new Map();
    if (!stop() && internalTargets.size && internalTargets.size <= 3000) {
      let n = 0; const list = [...internalTargets];
      await U.pool(list, o.concurrency, async (url) => {
        const r = await fetchPage({ url, method: 'HEAD', wantBody: false, timeoutMs: 12000 });
        internalExtra.set(url, { status: r.status, error: r.error || null, finalUrl: r.finalUrl });
        n++; progress({ phase: 'internal', done: n, total: list.length, current: url });
      }, stop);
    }

    return {
      start, home, origin, startHost, options: o,
      robots: robotsText ? { text: robotsText.slice(0, 20000), sitemaps: robots.sitemaps, groups: robots.groups, ai: aiBotAccess(robots, origin) } : { text: null, sitemaps: [], groups: [], ai: aiBotAccess(null, origin) },
      llms, variants,
      sitemap: { files: sitemap.files, count: sitemap.urls.size, urls: [...sitemap.urls.entries()].slice(0, 50000) },
      pages: [...pages.values()], resources: [...resources.entries()], blocked,
      external: [...external.entries()], internalExtra: [...internalExtra.entries()],
      cancelled: !!stop(), truncated, durationMs: Math.round(performance.now() - t0),
    };
  }

  VX.crawler = { crawl, parseRobots, allowed, AI_BOTS, readSitemaps, aiBotAccess };
})(window.VX = window.VX || {});
