// VANTIX — diagnostic du site : problèmes, explications, corrections, scores, index des liens
(function (VX) {
  'use strict';
  const U = VX.util;
  const SEV = { critique: 16, important: 8, mineur: 3, info: 0 };
  const CATS = { technique: 'Technique', contenu: 'Contenu', liens: 'Liens', geo: 'GEO (IA)' };
  const KEY_AI = ['GPTBot', 'OAI-SearchBot', 'ClaudeBot', 'PerplexityBot', 'Google-Extended'];

  function buildReport(raw) {
    const pages = raw.pages;
    const byUrl = new Map(pages.map(p => [p.url, p]));
    const html = pages.filter(p => p.html && p.status >= 200 && p.status < 300);
    const indexable = html.filter(p => !p.noindex && (!p.canonical || p.canonical === p.url || p.canonical === U.normalizeUrl(p.finalUrl)));
    const external = new Map(raw.external);
    const internalExtra = new Map(raw.internalExtra);
    const sitemapUrls = new Map(raw.sitemap.urls);
    const issues = [];
    const add = (id, cat, sev, title, why, fix, items, opts = {}) => {
      if (!items || (Array.isArray(items) && !items.length)) return;
      issues.push({ id, cat, sev, title, why, fix, items: Array.isArray(items) ? items : [items], siteWide: !!opts.siteWide });
    };
    const statusOf = (url) => {
      const p = byUrl.get(url); if (p) return { status: p.status, redirect: !!p.isRedirect, to: p.redirectTo, error: p.error };
      const e = internalExtra.get(url) || external.get(url); if (e) return { status: e.status, redirect: !!(e.finalUrl && U.normalizeUrl(e.finalUrl) !== url) && e.status < 400, to: e.finalUrl, error: e.error };
      return null;
    };

    // ---------- index de tous les liens ----------
    const links = []; const inlinks = new Map(); const anchorsTo = new Map();
    for (const p of html) for (const l of p.links) {
      if (l.kind !== 'page') { links.push({ from: p.url, to: l.raw, kind: l.kind, anchor: l.anchor, internal: false, nofollow: l.nofollow, status: null }); continue; }
      const st = statusOf(l.url);
      links.push({ from: p.url, to: l.url, kind: 'page', anchor: l.anchor, internal: l.internal, nofollow: l.nofollow, sponsored: l.sponsored, ugc: l.ugc, status: st ? st.status : null, redirect: st ? st.redirect : false, error: st ? st.error : null, generic: l.generic, empty: l.empty, blank: l.blank, noopener: l.noopener });
      if (l.internal && l.url !== p.url) {
        if (!inlinks.has(l.url)) inlinks.set(l.url, new Set());
        inlinks.get(l.url).add(p.url);
        if (!anchorsTo.has(l.url)) anchorsTo.set(l.url, new Map());
        const am = anchorsTo.get(l.url); am.set(l.anchor || '(vide)', (am.get(l.anchor || '(vide)') || 0) + 1);
      }
    }
    for (const p of pages) {
      p.inlinks = inlinks.has(p.url) ? inlinks.get(p.url).size : 0;
      p.anchorsIn = anchorsTo.has(p.url) ? U.topCounts(anchorsTo.get(p.url), 8) : [];
    }

    // ================= TECHNIQUE =================
    const home = byUrl.get(raw.home) || html[0];
    if (!raw.home.startsWith('https:')) add('no_https', 'technique', 'critique', 'Le site n’est pas en HTTPS', 'Google et les navigateurs signalent les sites sans HTTPS comme non sécurisés, et les IA les citent moins.', 'Activez un certificat SSL (gratuit chez la plupart des hébergeurs) et redirigez tout le trafic vers https://.', { url: raw.home });
    const badVariants = raw.variants.filter(v => !v.redirectsToHome && v.status && v.status < 400);
    add('variants', 'technique', 'important', 'Plusieurs versions du site sont accessibles', 'Les versions http/https et avec/sans www doivent toutes rediriger vers une seule adresse, sinon le site est vu en double.', 'Ajoutez une redirection 301 de chaque variante vers ' + raw.home + '.', badVariants.map(v => ({ url: v.url, detail: 'répond ' + v.status + (v.finalUrl ? ' → ' + v.finalUrl : '') })), { siteWide: true });
    const multiHop = raw.variants.filter(v => v.redirectsToHome && v.hops > 1);
    add('variant_hops', 'technique', 'mineur', 'Redirections en plusieurs étapes vers l’accueil', 'Chaque étape de redirection ralentit l’accès et dilue un peu la valeur des liens.', 'Faites pointer chaque variante directement vers l’adresse finale en une seule redirection.', multiHop.map(v => ({ url: v.url, detail: v.hops + ' redirections' })), { siteWide: true });

    const errors4 = pages.filter(p => p.status >= 400 && p.status < 500);
    const errors5 = pages.filter(p => p.status >= 500);
    const errors0 = pages.filter(p => !p.status);
    add('pages_4xx', 'technique', 'critique', 'Pages introuvables (erreurs 4xx)', 'Ces adresses sont liées ou listées, mais renvoient une erreur. Les visiteurs et les robots tombent dans une impasse.', 'Restaurez la page, ou redirigez-la (301) vers la page la plus proche, puis corrigez les liens qui y mènent.', errors4.map(p => ({ url: p.url, detail: 'erreur ' + p.status })));
    add('pages_5xx', 'technique', 'critique', 'Erreurs serveur (5xx)', 'Le serveur plante sur ces pages. Si ça dure, Google les retire de son index.', 'Regardez les journaux d’erreurs de l’hébergeur pour ces adresses.', errors5.map(p => ({ url: p.url, detail: 'erreur ' + p.status })));
    add('pages_timeout', 'technique', 'important', 'Pages qui ne répondent pas', 'Délai dépassé ou connexion refusée.', 'Vérifiez la disponibilité du serveur et le temps de génération de ces pages.', errors0.map(p => ({ url: p.url, detail: p.error || 'aucune réponse' })));

    const chains = pages.filter(p => p.redirects && p.redirects.length > 1);
    add('redirect_chains', 'technique', 'important', 'Chaînes de redirections', 'Plusieurs redirections à la suite ralentissent le chargement et font perdre de la valeur SEO.', 'Remplacez la chaîne par une redirection unique vers la destination finale.', chains.map(p => ({ url: p.url, detail: p.redirects.map(r => r.status).join(' → ') + ' → ' + (p.finalStatus || p.status) })));

    const slow = html.filter(p => p.timeMs > 1500);
    add('slow', 'technique', slow.length > html.length * 0.3 ? 'important' : 'mineur', 'Pages lentes à répondre', 'Au-delà de 1,5 s pour recevoir la page, l’expérience et le classement en souffrent.', 'Activez la mise en cache, un CDN et la compression ; allégez les requêtes faites à chaque chargement.', slow.map(p => ({ url: p.url, detail: p.timeMs + ' ms' })));
    const slowTtfb = html.filter(p => p.ttfbMs > 800 && p.timeMs <= 1500);
    add('ttfb', 'technique', 'mineur', 'Premier octet trop lent (TTFB)', 'Le serveur met plus de 800 ms à commencer à répondre.', 'Cache serveur, hébergement plus rapide, ou génération statique des pages.', slowTtfb.map(p => ({ url: p.url, detail: p.ttfbMs + ' ms' })));
    const heavy = html.filter(p => p.bytes > 1500000);
    add('heavy', 'technique', 'mineur', 'Code HTML très lourd', 'Plus de 1,5 Mo de HTML, c’est souvent du code inutile ou des données intégrées.', 'Retirez le code inline superflu et chargez les données à la demande.', heavy.map(p => ({ url: p.url, detail: Math.round(p.bytes / 1024) + ' Ko' })));
    const nocomp = html.filter(p => !p.headers.encoding && p.bytes > 10000);
    add('no_compression', 'technique', 'important', 'Pages envoyées sans compression', 'Sans gzip ou brotli, les pages pèsent 3 à 5 fois plus lourd sur le réseau.', 'Activez la compression gzip ou brotli sur le serveur (une ligne dans la configuration).', nocomp.map(p => ({ url: p.url, detail: Math.round(p.bytes / 1024) + ' Ko non compressés' })));
    const mixed = html.filter(p => p.mixedContent > 0);
    add('mixed', 'technique', 'important', 'Contenu mixte (http sur une page https)', 'Le navigateur bloque ou signale ces ressources non sécurisées.', 'Passez toutes les ressources en https://.', mixed.map(p => ({ url: p.url, detail: p.mixedContent + ' ressources en http' })));
    if (raw.home.startsWith('https:') && home && home.headers && !home.headers.hsts) add('no_hsts', 'technique', 'mineur', 'En-tête HSTS absent', 'HSTS force les navigateurs à toujours utiliser HTTPS.', 'Ajoutez l’en-tête Strict-Transport-Security: max-age=31536000.', { url: raw.home }, { siteWide: true });
    const powered = html.filter(p => p.headers.poweredBy);
    if (powered.length) add('powered_by', 'technique', 'mineur', 'Le serveur révèle sa technologie', 'L’en-tête X-Powered-By donne des indices aux attaquants.', 'Masquez cet en-tête dans la configuration du serveur.', { url: powered[0].url, detail: powered[0].headers.poweredBy }, { siteWide: true });

    const truncPages = html.filter(p => p.truncated);
    add('truncated', 'technique', 'mineur', 'Pages trop grandes pour être lues en entier', 'Au-delà de 8 Mo, l’analyse a été coupée.', 'Réduisez le poids de ces pages.', truncPages.map(p => ({ url: p.url })));

    const noLang = html.filter(p => !p.lang);
    add('no_lang', 'technique', 'mineur', 'Langue de la page non déclarée', 'L’attribut lang aide Google, les IA et les lecteurs d’écran.', 'Ajoutez <html lang="fr"> (ou la bonne langue).', noLang.map(p => ({ url: p.url })));
    const noViewport = html.filter(p => !p.viewport);
    add('no_viewport', 'technique', 'important', 'Pas de balise viewport (mobile)', 'Sans elle, la page s’affiche mal sur téléphone, et Google indexe la version mobile.', 'Ajoutez <meta name="viewport" content="width=device-width, initial-scale=1">.', noViewport.map(p => ({ url: p.url })));

    // robots et sitemaps
    if (!raw.robots.text) add('no_robots', 'technique', 'mineur', 'Pas de fichier robots.txt', 'Ce fichier indique aux robots ce qu’ils peuvent explorer et où trouver le sitemap.', 'Créez /robots.txt avec au minimum : User-agent: * puis Allow: / puis Sitemap: ' + raw.origin + '/sitemap.xml', { url: raw.origin + '/robots.txt' }, { siteWide: true });
    else if (!raw.robots.sitemaps.length) add('robots_no_sitemap', 'technique', 'mineur', 'robots.txt ne signale pas le sitemap', 'Les robots trouvent plus vite toutes vos pages quand le sitemap est indiqué.', 'Ajoutez la ligne : Sitemap: ' + raw.origin + '/sitemap.xml', { url: raw.origin + '/robots.txt' }, { siteWide: true });
    if (raw.options.useSitemaps && !raw.sitemap.count) add('no_sitemap', 'technique', 'important', 'Aucun sitemap XML trouvé', 'Le sitemap liste toutes vos pages pour Google, Bing et les moteurs IA.', 'Générez un sitemap.xml (extension SEO sur WordPress, ou plugin de votre outil) et déclarez-le dans Search Console.', { url: raw.origin + '/sitemap.xml' }, { siteWide: true });
    const smBad = [];
    for (const [u] of sitemapUrls) { const st = statusOf(u); if (st && (st.status >= 300 || !st.status)) smBad.push({ url: u, detail: st.redirect ? 'redirige vers ' + st.to : 'statut ' + (st.status || st.error) }); }
    add('sitemap_bad', 'technique', 'important', 'Le sitemap contient des adresses en erreur ou redirigées', 'Le sitemap ne doit lister que des pages finales qui répondent 200.', 'Retirez ces adresses du sitemap ou remplacez-les par leur destination.', smBad);
    const smNoindex = html.filter(p => p.noindex && sitemapUrls.has(p.url));
    add('sitemap_noindex', 'technique', 'important', 'Pages en noindex présentes dans le sitemap', 'Signal contradictoire : vous demandez d’indexer et d’ignorer la même page.', 'Retirez ces pages du sitemap, ou enlevez le noindex si elles doivent apparaître.', smNoindex.map(p => ({ url: p.url })));
    if (raw.sitemap.count) {
      const notIn = indexable.filter(p => !sitemapUrls.has(p.url));
      add('not_in_sitemap', 'technique', 'mineur', 'Pages indexables absentes du sitemap', 'Ces pages existent et sont liées, mais le sitemap les oublie.', 'Régénérez le sitemap pour inclure toutes les pages indexables.', notIn.map(p => ({ url: p.url })));
    }
    const orphans = html.filter(p => p.depth === null && p.url !== raw.home);
    add('orphans', 'liens', 'important', 'Pages orphelines', 'Aucune page du site ne fait de lien vers elles : on ne les trouve que par le sitemap. Google les juge peu importantes.', 'Ajoutez des liens vers ces pages depuis des pages proches (menu, catégorie, articles liés).', orphans.map(p => ({ url: p.url })));
    const deep = html.filter(p => p.depth > 3);
    add('deep', 'liens', 'mineur', 'Pages trop profondes (plus de 3 clics)', 'Plus une page est loin de l’accueil, moins elle est explorée et valorisée.', 'Rapprochez-les : liens depuis l’accueil, les catégories ou un bloc « articles populaires ».', deep.map(p => ({ url: p.url, detail: p.depth + ' clics' })));
    add('blocked', 'technique', 'info', 'Adresses bloquées par robots.txt', 'Ces adresses n’ont pas été explorées car robots.txt les interdit. Vérifiez que c’est voulu.', 'Si ces pages doivent être trouvées, retirez la règle Disallow correspondante.', raw.blocked.slice(0, 500).map(u => ({ url: u })));
    const noindexPages = html.filter(p => p.noindex);
    add('noindex', 'technique', 'info', 'Pages exclues de Google (noindex)', 'Ces pages demandent à ne pas être indexées.', 'Vérifiez qu’aucune page importante n’est dans cette liste.', noindexPages.map(p => ({ url: p.url })));

    // canonical
    const noCanon = indexable.filter(p => !p.canonical);
    add('no_canonical', 'technique', 'mineur', 'Pas de balise canonical', 'La canonical évite les doublons quand une page est accessible par plusieurs adresses (paramètres, tri).', 'Ajoutez <link rel="canonical" href="adresse-de-la-page">.', noCanon.map(p => ({ url: p.url })));
    const multiCanon = html.filter(p => p.canonicalCount > 1);
    add('multi_canonical', 'technique', 'important', 'Plusieurs balises canonical', 'Google ignore toutes les canonical quand elles se contredisent.', 'Gardez une seule balise canonical par page.', multiCanon.map(p => ({ url: p.url, detail: p.canonicalCount + ' balises' })));
    const badCanon = [];
    for (const p of html) if (p.canonical && p.canonical !== p.url) { const st = statusOf(p.canonical); if (st && (st.status >= 300 || !st.status)) badCanon.push({ url: p.url, detail: 'canonical → ' + p.canonical + ' (' + (st.redirect ? 'redirige' : st.status || st.error) + ')' }); }
    const extCanon = html.filter(p => p.canonical && !U.isInternal(p.canonical, raw.startHost, raw.options.includeSubdomains));
    add('canonical_external', 'technique', 'critique', 'Canonical vers un autre domaine', 'Ces pages déclarent que leur version officielle se trouve sur un autre site : Google indexera l’autre site à leur place. Normal pour une copie de test, grave en production.', 'Faites pointer la canonical vers l’adresse de la page sur ce domaine.', extCanon.map(p => ({ url: p.url, detail: '→ ' + p.canonical })));
    add('bad_canonical', 'technique', 'critique', 'Canonical vers une page en erreur ou redirigée', 'Vous dites à Google que la vraie version est une page cassée : la page risque de disparaître.', 'Faites pointer la canonical vers une adresse finale qui répond 200.', badCanon);
    const hreflangBad = [];
    for (const p of html) for (const hl of p.hreflang || []) { const st = hl.href && statusOf(hl.href); if (st && (st.status >= 300 || !st.status)) hreflangBad.push({ url: p.url, detail: hl.lang + ' → ' + hl.href + ' (' + (st.status || st.error) + ')' }); }
    add('hreflang_bad', 'technique', 'important', 'Balises hreflang vers des pages en erreur', 'Les versions de langue doivent pointer vers des pages valides.', 'Corrigez les adresses hreflang.', hreflangBad);

    // ================= CONTENU =================
    const noTitle = html.filter(p => !p.title);
    add('no_title', 'contenu', 'critique', 'Pages sans balise title', 'Le title est le texte bleu cliquable dans Google : c’est l’élément SEO le plus important de la page.', 'Écrivez un title unique de 30 à 60 caractères, avec le sujet principal au début.', noTitle.map(p => ({ url: p.url })));
    const shortTitle = html.filter(p => p.title && p.title.length < 30);
    add('short_title', 'contenu', 'mineur', 'Title trop court', 'Moins de 30 caractères : vous laissez de la place inutilisée pour convaincre.', 'Allongez vers 50 à 60 caractères avec un bénéfice ou une précision.', shortTitle.map(p => ({ url: p.url, detail: '« ' + p.title + ' » (' + p.title.length + ')' })));
    const longTitle = html.filter(p => p.title && p.title.length > 60);
    add('long_title', 'contenu', 'mineur', 'Title trop long', 'Au-delà d’environ 60 caractères, Google coupe le titre.', 'Raccourcissez à 60 caractères, l’essentiel en premier.', longTitle.map(p => ({ url: p.url, detail: p.title.length + ' caractères' })));
    const multiTitle = html.filter(p => p.titleCount > 1);
    add('multi_title', 'contenu', 'important', 'Plusieurs balises title', 'Une page ne doit avoir qu’un seul title.', 'Supprimez les balises title en trop (souvent un thème + une extension SEO).', multiTitle.map(p => ({ url: p.url })));
    const dupGroups = (key) => { const m = new Map(); for (const p of indexable) { const k = key(p); if (!k) continue; if (!m.has(k)) m.set(k, []); m.get(k).push(p.url); } return [...m.entries()].filter(([, v]) => v.length > 1); };
    const dupTitles = dupGroups(p => p.title && p.title.toLowerCase());
    add('dup_title', 'contenu', 'important', 'Titles en double', 'Plusieurs pages ont le même title : Google ne sait pas laquelle montrer.', 'Rendez chaque title unique en précisant le sujet propre à la page.', dupTitles.flatMap(([t, urls]) => urls.map(u => ({ url: u, detail: '« ' + t.slice(0, 80) + ' » (' + urls.length + ' pages)' }))));
    const noDesc = indexable.filter(p => !p.description);
    add('no_desc', 'contenu', 'important', 'Meta description manquante', 'Sans description, Google en invente une à partir du texte, souvent mal choisie.', 'Écrivez 120 à 155 caractères qui résument la page et donnent envie de cliquer.', noDesc.map(p => ({ url: p.url })));
    const shortDesc = indexable.filter(p => p.description && p.description.length < 70);
    add('short_desc', 'contenu', 'mineur', 'Meta description trop courte', 'Moins de 70 caractères, c’est peu pour convaincre.', 'Visez 120 à 155 caractères.', shortDesc.map(p => ({ url: p.url, detail: p.description.length + ' caractères' })));
    const longDesc = indexable.filter(p => p.description && p.description.length > 160);
    add('long_desc', 'contenu', 'mineur', 'Meta description trop longue', 'Google coupe au-delà d’environ 155 caractères.', 'Raccourcissez à 155 caractères.', longDesc.map(p => ({ url: p.url, detail: p.description.length + ' caractères' })));
    const dupDesc = dupGroups(p => p.description && p.description.toLowerCase());
    add('dup_desc', 'contenu', 'mineur', 'Meta descriptions en double', 'La même description sur plusieurs pages réduit leur attrait.', 'Écrivez une description propre à chaque page.', dupDesc.flatMap(([d, urls]) => urls.map(u => ({ url: u, detail: urls.length + ' pages identiques' }))));
    const noH1 = indexable.filter(p => !p.h1.length);
    add('no_h1', 'contenu', 'important', 'Pas de titre H1', 'Le H1 annonce le sujet de la page aux lecteurs, à Google et aux IA.', 'Ajoutez un H1 unique qui décrit le sujet principal.', noH1.map(p => ({ url: p.url })));
    const multiH1 = indexable.filter(p => p.h1.length > 1);
    add('multi_h1', 'contenu', 'mineur', 'Plusieurs H1 sur la page', 'Un seul H1 clarifie le sujet principal.', 'Gardez un H1, passez les autres en H2.', multiH1.map(p => ({ url: p.url, detail: p.h1.length + ' H1' })));
    const dupH1 = dupGroups(p => p.h1[0] && p.h1[0].toLowerCase());
    add('dup_h1', 'contenu', 'mineur', 'H1 identiques sur plusieurs pages', 'Des pages différentes devraient avoir des titres différents.', 'Personnalisez le H1 de chaque page.', dupH1.flatMap(([h, urls]) => urls.map(u => ({ url: u, detail: '« ' + h.slice(0, 60) + ' »' }))));
    const skips = html.filter(p => p.headingSkips > 0);
    add('heading_skips', 'contenu', 'mineur', 'Hiérarchie des titres irrégulière', 'Passer d’un H2 à un H4 sans H3 brouille la structure lue par Google et les IA.', 'Respectez l’ordre H1 > H2 > H3 sans sauter de niveau.', skips.map(p => ({ url: p.url, detail: p.headingSkips + ' sauts' })));
    const emptyH = html.filter(p => p.emptyHeadings > 0);
    add('empty_headings', 'contenu', 'mineur', 'Titres vides', 'Des balises H sans texte, souvent un reste de mise en page.', 'Supprimez-les ou mettez du texte dedans.', emptyH.map(p => ({ url: p.url, detail: p.emptyHeadings })));
    const thin = indexable.filter(p => p.mainWordCount < 300);
    add('thin', 'contenu', thin.length > indexable.length * 0.4 ? 'important' : 'mineur', 'Contenu trop mince', 'Moins de 300 mots : la page a peu de chances de se classer ou d’être citée par une IA.', 'Développez : réponses aux questions des clients, exemples, chiffres, comparaison.', thin.map(p => ({ url: p.url, detail: p.mainWordCount + ' mots' })));
    const dupContent = dupGroups(p => p.contentHash);
    add('dup_content', 'contenu', 'critique', 'Contenu dupliqué à l’identique', 'Ces pages ont exactement le même texte : Google n’en gardera qu’une.', 'Fusionnez-les avec une redirection 301, ou réécrivez-les, ou ajoutez une canonical vers la version principale.', dupContent.flatMap(([, urls]) => urls.map(u => ({ url: u, detail: urls.length + ' pages identiques' }))));
    // quasi-doublons (comparaison par paires, limitée)
    const near = []; const cand = indexable.filter(p => p.shingles && p.shingles.length > 20).slice(0, 700);
    const exact = new Set(dupContent.flatMap(([, u]) => u));
    for (let i = 0; i < cand.length; i++) for (let j = i + 1; j < cand.length; j++) {
      if (exact.has(cand[i].url) && exact.has(cand[j].url)) continue;
      const s = U.jaccard(cand[i].shingles, cand[j].shingles);
      if (s >= 0.8) near.push({ url: cand[i].url, detail: Math.round(s * 100) + ' % identique à ' + cand[j].url });
    }
    add('near_dup', 'contenu', 'important', 'Pages presque identiques', 'Le texte de ces pages se recoupe à plus de 80 %. Elles se font concurrence entre elles.', 'Différenciez-les nettement, ou regroupez-les en une seule page plus complète.', near);
    const hard = indexable.filter(p => p.readability !== null && p.readability < 40);
    add('readability', 'contenu', 'mineur', 'Texte difficile à lire', 'Phrases longues et mots compliqués : les lecteurs décrochent et les IA résument moins bien.', 'Phrases plus courtes (15 à 20 mots), un message par paragraphe, mots simples.', hard.map(p => ({ url: p.url, detail: 'lisibilité ' + p.readability + '/100' })));
    const focusMiss = indexable.filter(p => p.focus && p.mainWordCount > 150 && !p.focus.inTitle && !p.focus.inH1);
    add('focus', 'contenu', 'mineur', 'Le sujet principal n’apparaît ni dans le title ni dans le H1', 'Le mot le plus utilisé dans le texte est absent des deux endroits les plus importants.', 'Placez le sujet principal dans le title et le H1, ou recentrez le texte.', focusMiss.map(p => ({ url: p.url, detail: 'mot principal : « ' + p.focus.word + ' »' })));
    const stuffing = indexable.filter(p => p.focus && p.focus.density > 4 && p.mainWordCount > 150);
    add('stuffing', 'contenu', 'important', 'Mot répété de façon excessive', 'Plus de 4 % du texte est le même mot : Google peut y voir une sur-optimisation.', 'Variez le vocabulaire avec des synonymes et des expressions proches.', stuffing.map(p => ({ url: p.url, detail: '« ' + p.focus.word + ' » ' + p.focus.density + ' %' })));
    const altMiss = html.filter(p => p.images && p.images.noAlt > 0);
    add('img_alt', 'contenu', 'important', 'Images sans texte alternatif', 'Le texte alternatif décrit l’image à Google Images, aux IA et aux personnes malvoyantes.', 'Ajoutez un attribut alt descriptif à chaque image (alt="" pour les images purement décoratives).', altMiss.map(p => ({ url: p.url, detail: p.images.noAlt + ' images' })));
    const dims = html.filter(p => p.images && p.images.noDims > 2);
    add('img_dims', 'technique', 'mineur', 'Images sans dimensions', 'Sans largeur et hauteur, la page « saute » pendant le chargement (CLS).', 'Ajoutez width et height sur les balises img.', dims.map(p => ({ url: p.url, detail: p.images.noDims + ' images' })));
    const noOg = indexable.filter(p => !p.og.title || !p.og.image);
    add('no_og', 'contenu', 'mineur', 'Aperçu de partage incomplet (Open Graph)', 'Sans og:title et og:image, le lien partagé sur les réseaux s’affiche sans image.', 'Ajoutez les balises og:title, og:description et og:image.', noOg.map(p => ({ url: p.url })));

    // ================= LIENS =================
    const brokenInt = links.filter(l => l.kind === 'page' && l.internal && l.status !== null && (l.status >= 400 || l.status === 0));
    add('broken_internal', 'liens', 'critique', 'Liens internes cassés', 'Ces liens mènent à une page en erreur : visiteurs perdus et budget d’exploration gaspillé.', 'Corrigez l’adresse du lien, ou redirigez la page manquante.', brokenInt.map(l => ({ url: l.from, detail: '→ ' + l.to + ' (' + (l.status || l.error) + ')' + (l.anchor ? ' « ' + l.anchor.slice(0, 40) + ' »' : '') })));
    const SHARE = /(twitter\.com|x\.com)\/(intent|share)|facebook\.com\/(sharer|dialog)|linkedin\.com\/(share|sharing)|wa\.me\/|api\.whatsapp\.com\/send|t\.me\/share|pinterest\.[a-z.]+\/pin\/create|reddit\.com\/submit|bsky\.app\/intent/i;
    const brokenExt = links.filter(l => l.kind === 'page' && !l.internal && !SHARE.test(l.to || '') && l.status !== null && (l.status >= 400 || l.status === 0) && l.status !== 401 && l.status !== 403 && l.status !== 429 && l.status !== 999);
    add('broken_external', 'liens', 'important', 'Liens externes cassés', 'Vous envoyez vos lecteurs vers des pages qui n’existent plus : mauvais signal de qualité.', 'Remplacez le lien par une source à jour, ou retirez-le.', brokenExt.map(l => ({ url: l.from, detail: '→ ' + l.to + ' (' + (l.status || l.error) + ')' })));
    const redirInt = links.filter(l => l.kind === 'page' && l.internal && l.redirect);
    add('redirect_links', 'liens', 'mineur', 'Liens internes vers des adresses redirigées', 'Chaque lien redirigé ajoute un détour inutile.', 'Mettez à jour le lien avec l’adresse finale.', redirInt.map(l => ({ url: l.from, detail: '→ ' + l.to })));
    const nofInt = links.filter(l => l.kind === 'page' && l.internal && l.nofollow);
    add('nofollow_internal', 'liens', 'mineur', 'Liens internes en nofollow', 'Le nofollow sur vos propres pages bloque la circulation de la valeur SEO.', 'Retirez rel="nofollow" des liens internes.', nofInt.map(l => ({ url: l.from, detail: '→ ' + l.to })));
    const generic = links.filter(l => l.kind === 'page' && l.generic);
    add('generic_anchor', 'liens', 'mineur', 'Textes de lien vagues (« cliquez ici », « en savoir plus »)', 'Le texte du lien décrit la page de destination à Google et aux IA.', 'Écrivez le sujet de la page cible dans le lien, par exemple « nos tarifs SEO ».', generic.map(l => ({ url: l.from, detail: '« ' + l.anchor + ' » → ' + l.to })));
    const emptyA = links.filter(l => l.kind === 'page' && l.empty);
    add('empty_anchor', 'liens', 'mineur', 'Liens sans texte', 'Un lien sans texte ni alt n’a aucun sens pour Google et les lecteurs d’écran.', 'Ajoutez un texte, un aria-label, ou un alt sur l’image du lien.', emptyA.map(l => ({ url: l.from, detail: '→ ' + l.to })));
    const unsafe = links.filter(l => l.kind === 'page' && !l.internal && l.blank && !l.noopener);
    add('noopener', 'liens', 'mineur', 'Liens target="_blank" sans noopener', 'Petite faille de sécurité et de performance.', 'Ajoutez rel="noopener" à ces liens.', unsafe.map(l => ({ url: l.from, detail: '→ ' + l.to })));
    const tooMany = html.filter(p => p.links.length > 300);
    add('too_many_links', 'liens', 'mineur', 'Trop de liens sur la page', 'Au-delà de 300 liens, chaque lien a moins de poids.', 'Allégez les menus et les pieds de page.', tooMany.map(p => ({ url: p.url, detail: p.links.length + ' liens' })));
    const weak = indexable.filter(p => p.inlinks === 1 && p.url !== raw.home);
    add('weak_inlinks', 'liens', 'mineur', 'Pages avec un seul lien entrant', 'Une page peu liée est perçue comme peu importante.', 'Ajoutez 2 à 5 liens depuis des pages sur des sujets proches.', weak.map(p => ({ url: p.url })));
    const jsLinks = links.filter(l => l.kind === 'js');
    add('js_links', 'liens', 'mineur', 'Liens en javascript:', 'Les robots ne suivent pas ces liens.', 'Utilisez de vrais liens href vers des adresses.', jsLinks.map(l => ({ url: l.from, detail: l.to.slice(0, 80) })));

    // ================= GEO =================
    const hiddenStream = html.filter(p => p.streamedWords >= 30);
    add('hidden_stream', 'geo', 'important', 'Contenu caché jusqu’au chargement de JavaScript', 'Le texte de ces pages arrive dans des blocs cachés, remis en place par JavaScript (chargement progressif React / Next.js). Les robots de ChatGPT, Claude ou Perplexity n’exécutent pas JavaScript : pour eux, la page paraît vide ou incomplète.', 'Envoyez le contenu principal directement dans le HTML : retirez l’écran de chargement global (loading.tsx) et, pour les robots, rendez les blocs <Suspense> sans attente.', hiddenStream.map(p => ({ url: p.url, detail: p.streamedWords + ' mots cachés' })));
    if (!raw.llms.ok) add('no_llms', 'geo', 'important', 'Pas de fichier llms.txt', 'llms.txt présente votre site aux IA en quelques lignes : qui vous êtes, vos pages clés. C’est le nouveau robots.txt des moteurs génératifs.', 'Créez ' + raw.origin + '/llms.txt : un titre, une phrase de présentation, puis la liste de vos pages importantes avec une ligne chacune.', { url: raw.origin + '/llms.txt' }, { siteWide: true });
    const blockedAI = raw.robots.ai.filter(b => !b.home && KEY_AI.includes(b.bot));
    add('ai_blocked', 'geo', 'critique', 'Des robots d’IA sont bloqués', 'Votre robots.txt interdit à ces IA de lire le site : elles ne peuvent pas vous citer.', 'Retirez les règles Disallow visant ces robots dans robots.txt (sauf choix volontaire).', blockedAI.map(b => ({ url: raw.origin + '/robots.txt', detail: b.bot })), { siteWide: true });
    const otherBlocked = raw.robots.ai.filter(b => !b.home && !KEY_AI.includes(b.bot));
    add('ai_blocked_other', 'geo', 'info', 'Autres robots bloqués', 'Ces robots (IA ou moteurs secondaires) sont bloqués. C’est souvent volontaire.', 'Vérifiez que ce blocage est voulu.', otherBlocked.map(b => ({ url: raw.origin + '/robots.txt', detail: b.bot })), { siteWide: true });
    const anyOrg = html.some(p => p.schema.hasOrg);
    if (!anyOrg) add('no_org', 'geo', 'important', 'Pas de balisage Organization', 'Ce balisage dit clairement aux IA qui vous êtes : nom, logo, réseaux, contact. C’est la base pour être reconnu comme entité.', 'Ajoutez un JSON-LD Organization sur l’accueil avec name, url, logo, sameAs (vos réseaux) et contactPoint.', { url: raw.home }, { siteWide: true });
    const noSchema = indexable.filter(p => !p.schema.types.length);
    add('no_schema', 'geo', 'important', 'Aucune donnée structurée', 'Sans Schema.org, Google et les IA doivent deviner le type de contenu.', 'Ajoutez un JSON-LD adapté : Article, Product, LocalBusiness, FAQPage, BreadcrumbList.', noSchema.map(p => ({ url: p.url })));
    const schemaErr = html.filter(p => p.schema.errors > 0);
    add('schema_errors', 'geo', 'important', 'Données structurées invalides', 'Le JSON-LD contient une erreur de syntaxe : il est ignoré.', 'Corrigez le JSON (virgule, guillemet) et testez-le avec l’outil de test des résultats enrichis de Google.', schemaErr.map(p => ({ url: p.url, detail: p.schema.errors + ' bloc(s) en erreur' })));
    const content = indexable.filter(p => p.mainWordCount >= 300);
    const noAnswer = content.filter(p => !p.geo.answerFirst);
    add('no_answer_first', 'geo', 'important', 'Pas de réponse courte en début de page', 'Les IA citent les pages qui répondent en 1 à 3 phrases dès le premier paragraphe.', 'Commencez la page par un paragraphe de 40 à 60 mots qui répond directement à la question principale.', noAnswer.map(p => ({ url: p.url })));
    const noQ = content.filter(p => p.geo.questionHeadings === 0);
    add('no_questions', 'geo', 'mineur', 'Aucun intertitre sous forme de question', 'Les gens posent des questions aux IA. Des H2 du type « Combien coûte… ? » correspondent directement à ces questions.', 'Transformez 2 ou 3 intertitres en questions que vos clients se posent, avec la réponse juste en dessous.', noQ.map(p => ({ url: p.url })));
    const faqMissing = content.filter(p => p.geo.questionHeadings >= 3 && !p.schema.hasFAQ);
    add('faq_schema', 'geo', 'mineur', 'Questions présentes sans balisage FAQ', 'La page contient plusieurs questions : le balisage FAQPage les rend lisibles directement par les moteurs.', 'Ajoutez un JSON-LD FAQPage reprenant les questions et réponses.', faqMissing.map(p => ({ url: p.url, detail: p.geo.questionHeadings + ' questions' })));
    const articles = content.filter(p => p.schema.hasArticle || /blog|article|actu|news|guide/i.test(p.url));
    const noAuthor = articles.filter(p => !p.geo.author);
    add('no_author', 'geo', 'mineur', 'Auteur non indiqué', 'Les IA et Google font plus confiance aux contenus signés par une personne identifiée (E-E-A-T).', 'Affichez l’auteur avec une courte bio, et ajoutez author dans le JSON-LD.', noAuthor.map(p => ({ url: p.url })));
    const noDate = articles.filter(p => !p.geo.dated);
    add('no_date', 'geo', 'mineur', 'Date de publication absente', 'Les IA préfèrent les sources datées et récentes.', 'Affichez la date de publication et de mise à jour, et ajoutez datePublished / dateModified.', noDate.map(p => ({ url: p.url })));
    const noStats = content.filter(p => p.geo.stats === 0 && p.geo.sources === 0);
    add('no_facts', 'geo', 'mineur', 'Ni chiffres ni sources', 'Les pages avec des données chiffrées et des sources citées sont nettement plus reprises par les IA.', 'Ajoutez 2 ou 3 chiffres précis et des liens vers vos sources.', noStats.map(p => ({ url: p.url })));
    const walls = content.filter(p => p.geo.longParagraphs > 0);
    add('long_paragraphs', 'geo', 'mineur', 'Paragraphes trop longs', 'Au-delà de 120 mots, un paragraphe est difficile à extraire pour une IA.', 'Coupez en paragraphes de 40 à 80 mots, ajoutez des listes.', walls.map(p => ({ url: p.url, detail: p.geo.longParagraphs + ' paragraphes' })));
    const noStructure = content.filter(p => p.geo.lists === 0 && p.geo.tables === 0);
    add('no_structure', 'geo', 'mineur', 'Ni liste ni tableau', 'Les listes et tableaux sont les formats que les IA reprennent le plus volontiers.', 'Présentez les étapes en liste numérotée et les comparaisons en tableau.', noStructure.map(p => ({ url: p.url })));

    // ---------- scores ----------
    const totalPages = Math.max(1, indexable.length || html.length);
    const scoreCat = (cat) => {
      let s = 100;
      for (const i of issues.filter(x => x.cat === cat)) {
        const ratio = i.siteWide ? 1 : Math.min(1, new Set(i.items.map(x => x.url)).size / totalPages);
        s -= SEV[i.sev] * (0.35 + 0.65 * ratio);
      }
      return Math.max(0, Math.round(s));
    };
    const scores = { technique: scoreCat('technique'), contenu: scoreCat('contenu'), liens: scoreCat('liens'), geo: scoreCat('geo') };
    scores.seo = Math.round(scores.technique * 0.35 + scores.contenu * 0.4 + scores.liens * 0.25);
    scores.global = Math.round(scores.seo * 0.65 + scores.geo * 0.35);
    const order = { critique: 0, important: 1, mineur: 2, info: 3 };
    issues.sort((a, b) => order[a.sev] - order[b.sev] || b.items.length - a.items.length);

    // ---------- mots du site ----------
    const kw = new Map(), bg = new Map(), kwPages = new Map();
    for (const p of indexable) {
      for (const [w, c] of p.keywords || []) { kw.set(w, (kw.get(w) || 0) + c); kwPages.set(w, (kwPages.get(w) || 0) + 1); }
      for (const [w, c] of p.bigrams || []) bg.set(w, (bg.get(w) || 0) + c);
    }
    const keywords = U.topCounts(kw, 150).map(([w, c]) => [w, c, kwPages.get(w)]);
    const bigrams = U.topCounts(bg, 60);

    // ---------- stats ----------
    const avg = (arr, f) => arr.length ? Math.round(arr.reduce((s, x) => s + (f(x) || 0), 0) / arr.length) : 0;
    const stats = {
      pages: pages.length, html: html.length, indexable: indexable.length,
      redirects: pages.filter(p => p.isRedirect).length, errors: errors4.length + errors5.length + errors0.length,
      words: html.reduce((s, p) => s + (p.mainWordCount || 0), 0), avgWords: avg(indexable, p => p.mainWordCount),
      avgTime: avg(html, p => p.timeMs), avgTtfb: avg(html, p => p.ttfbMs), avgBytes: avg(html, p => p.bytes),
      links: links.length, internalLinks: links.filter(l => l.internal).length, externalLinks: links.filter(l => l.kind === 'page' && !l.internal).length,
      uniqueExternal: raw.external.length, brokenLinks: brokenInt.length + brokenExt.length,
      images: html.reduce((s, p) => s + (p.images ? p.images.total : 0), 0),
      sitemapUrls: raw.sitemap.count, blocked: raw.blocked.length,
      issues: issues.filter(i => i.sev !== 'info').length,
      critical: issues.filter(i => i.sev === 'critique').length,
      schemaTypes: [...new Set(html.flatMap(p => p.schema.types))],
    };

    // pages allégées pour le rapport
    const issuesByUrl = new Map();
    for (const i of issues) for (const it of i.items) { if (!issuesByUrl.has(it.url)) issuesByUrl.set(it.url, []); issuesByUrl.get(it.url).push(i.id); }
    const slimPages = pages.map(p => { const c = Object.assign({}, p); delete c.shingles; c.issueIds = [...new Set(issuesByUrl.get(p.url) || [])]; c.inSitemap = sitemapUrls.has(p.url); return c; });

    const id = 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    return {
      id, version: 1, date: new Date().toISOString(), start: raw.start, home: raw.home, host: raw.startHost, origin: raw.origin,
      options: raw.options, durationMs: raw.durationMs, cancelled: raw.cancelled, truncated: raw.truncated,
      scores, stats, issues, pages: slimPages, links: links.slice(0, 250000), keywords, bigrams,
      robots: raw.robots, llms: raw.llms, variants: raw.variants,
      sitemap: { files: raw.sitemap.files, count: raw.sitemap.count },
      external: raw.external, blocked: raw.blocked, categories: CATS,
    };
  }

  VX.analyze = { buildReport, CATS };
})(window.VX = window.VX || {});
