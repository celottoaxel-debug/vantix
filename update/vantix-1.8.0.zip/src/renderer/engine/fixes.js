// VANTIX — générateur de corrections : fichiers du site, redirections, balises page par page
(function (VX) {
  'use strict';
  const U = VX.util;
  const KEY_AI = ['gptbot', 'oai-searchbot', 'chatgpt-user', 'claudebot', 'claude-searchbot', 'claude-user', 'anthropic-ai', 'perplexitybot', 'perplexity-user', 'google-extended', 'applebot-extended'];
  const SOCIAL = /(^|\.)(facebook|instagram|linkedin|x|twitter|tiktok|youtube|pinterest|threads)\.com$/i;
  const escAttr = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  const escXml = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  // Coupe proprement à la longueur voulue, sur un mot entier, sans ponctuation pendante
  function cut(s, max) {
    s = String(s || '').replace(/\s+/g, ' ').trim();
    if (s.length <= max) return s;
    let c = s.slice(0, max + 1);
    const i = c.lastIndexOf(' ');
    c = (i > max * 0.6 ? c.slice(0, i) : c.slice(0, max));
    return c.replace(/[\s,;:–—\-|·]+$/, '');
  }
  /** Raccourcit un title existant sans le réécrire : retire la marque en suffixe, puis la fin après un séparateur, puis coupe au mot. */
  function shortenTitle(title, brand, max = 60) {
    let t = String(title || '').replace(/\s+/g, ' ').trim();
    const esc = String(brand || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const suf = brand ? new RegExp('\\s*[|\\-–—·:]\\s*' + esc + '\\s*$', 'i') : null;
    if (t.length > max && suf && suf.test(t)) t = t.replace(suf, '').trim();
    while (t.length > max) {
      let at = -1;
      for (const sep of [' (', ' | ', ' — ', ' – ', ' : ', ': ', ', ', ' - ']) { const i = t.lastIndexOf(sep); if (i >= 25) { at = i; break; } }
      if (at < 0) break;
      t = t.slice(0, at).trim();
    }
    if (t.length > max) {
      t = cut(t, max);
      // ne jamais finir sur un petit mot de liaison (« … hors ligne à »)
      const STOP = /\s+(à|a|au|aux|de|du|des|d'|le|la|les|l'|en|et|ou|pour|sans|avec|sur|par|un|une|son|sa|ses|of|the|to|for|and|in|on|with|y|el|los|las|con|para|sin|del|al)$/i;
      while (STOP.test(t)) t = t.replace(STOP, '');
    }
    return t;
  }

  function sentenceCut(s, max) {
    s = String(s || '').replace(/\s+/g, ' ').trim();
    if (s.length <= max) return s;
    const part = s.slice(0, max);
    const end = Math.max(part.lastIndexOf('. '), part.lastIndexOf('! '), part.lastIndexOf('? '));
    if (end > max * 0.55) return part.slice(0, end + 1);
    return cut(s, max - 1) + '…';
  }
  const pathOf = (url) => { try { const u = new URL(url); return u.pathname + u.search; } catch { return url; } };
  const words = (s) => (s || '').toLowerCase().split(/[^\p{L}\p{N}]+/u).filter(w => w.length > 2);

  // Nom de la marque : le segment de title qui revient sur le plus de pages, sinon le nom de domaine
  function brandOf(report) {
    const seg = new Map();
    for (const p of report.pages) if (p.html && p.title) for (const s of p.title.split(/\s[|\-–—·:]\s/)) { const k = s.trim(); if (k && k.length < 40) seg.set(k, (seg.get(k) || 0) + 1); }
    const best = [...seg.entries()].sort((a, b) => b[1] - a[1])[0];
    if (best && best[1] >= 3) return best[0];
    if (/^[\d.:]+$|^localhost/.test(report.host)) return report.host;
    const label = report.host.replace(/^www\./, '').split(/[.:]/)[0];
    return label.charAt(0).toUpperCase() + label.slice(1);
  }

  function altFromSrc(src) {
    let name = '';
    try { name = decodeURIComponent(new URL(src).pathname.split('/').pop() || ''); } catch { name = String(src).split('/').pop() || ''; }
    name = name.replace(/\.[a-z0-9]+$/i, '').replace(/[-_+.]+/g, ' ').replace(/\b(\d+x\d+|\d{3,}|scaled|copy|final|v\d|min|large|small|thumb|thumbnail|img|image|dsc|dcim|photo|pic|screenshot|capture|wp|uploads?)\b/gi, ' ').replace(/\s+/g, ' ').trim();
    if (name.length < 3) return '';
    return name.charAt(0).toUpperCase() + name.slice(1);
  }

  // La page existante la plus proche d'une adresse cassée (mots communs dans le chemin)
  function bestMatch(url, candidates, home) {
    const w = new Set(words(pathOf(url)));
    let best = null, score = 0;
    for (const c of candidates) {
      const cw = words(pathOf(c));
      if (!cw.length) continue;
      const inter = cw.filter(x => w.has(x)).length;
      const s = inter / (w.size + cw.length - inter || 1);
      if (s > score) { score = s; best = c; }
    }
    return score >= 0.25 ? { url: best, score } : { url: home, score: 0 };
  }

  function buildFixes(report) {
    const brand = brandOf(report);
    const ok = report.pages.filter(p => p.html && p.status >= 200 && p.status < 300);
    const indexable = ok.filter(p => !p.noindex && (!p.canonical || p.canonical === p.url));
    const langs = new Map(); ok.forEach(p => p.lang && langs.set(p.lang, (langs.get(p.lang) || 0) + 1));
    const lang = ([...langs.entries()].sort((a, b) => b[1] - a[1])[0] || ['fr'])[0];
    const home = report.pages.find(p => p.url === report.home) || ok[0];
    const issueIds = new Map(report.issues.map(i => [i.id, new Set(i.items.map(x => x.url))]));
    const has = (id, url) => issueIds.has(id) && issueIds.get(id).has(url);
    const statusByUrl = new Map(report.pages.map(p => [p.url, p]));

    // ---------- redirections ----------
    const okUrls = indexable.map(p => p.url);
    const redirects = []; const seenFrom = new Set();
    for (const p of report.pages) {
      if (p.status >= 400 && p.status < 500 && (p.inlinks > 0 || p.inSitemap)) {
        const m = bestMatch(p.url, okUrls, report.home);
        redirects.push({ from: p.url, to: m.url, why: 'Page introuvable (' + p.status + ')' + (m.score ? '' : ', renvoyée vers l’accueil faute de page proche'), confident: m.score > 0 });
        seenFrom.add(p.url);
      }
      if (p.isRedirect && p.redirects && p.redirects.length > 1 && !seenFrom.has(p.url)) {
        redirects.push({ from: p.url, to: p.redirectTo, why: 'Chaîne de ' + p.redirects.length + ' redirections ramenée à une seule', confident: true });
      }
    }
    const redirectFormats = {
      htaccess: '# BEGIN VANTIX redirections\n' + redirects.map(r => `Redirect 301 ${pathOf(r.from)} ${r.to}`).join('\n') + '\n# END VANTIX redirections\n',
      nginx: redirects.map(r => `location = ${pathOf(r.from).split('?')[0]} { return 301 ${r.to}; }`).join('\n') + '\n',
      netlify: redirects.map(r => `${pathOf(r.from)}  ${pathOf(r.to)}  301`).join('\n') + '\n',
      vercel: JSON.stringify({ redirects: redirects.map(r => ({ source: pathOf(r.from).split('?')[0], destination: pathOf(r.to), permanent: true })) }, null, 2) + '\n',
    };
    const redirectTarget = new Map(redirects.map(r => [r.from, r.to]));

    // ---------- fichiers du site ----------
    const siteFiles = [];
    // robots.txt
    let robots;
    if (report.robots.text) {
      let agents = [], lastAgent = false; const out = [];
      for (const line of report.robots.text.split(/\r?\n/)) {
        const m = /^\s*([\w-]+)\s*:\s*(.*?)\s*$/.exec(line.replace(/#.*/, ''));
        if (m && m[1].toLowerCase() === 'user-agent') { if (!lastAgent) agents = []; agents.push(m[2].toLowerCase()); lastAgent = true; out.push(line); continue; }
        if (m) lastAgent = false;
        if (m && m[1].toLowerCase() === 'disallow' && m[2] === '/' && agents.length && agents.every(a => KEY_AI.includes(a))) { out.push('# ' + line + '   # retiré par VANTIX : laisse les IA lire le site'); continue; }
        out.push(line);
      }
      robots = out.join('\n').replace(/\s+$/, '') + '\n';
      if (!/^\s*sitemap\s*:/im.test(robots)) robots += '\nSitemap: ' + report.origin + '/sitemap.xml\n';
    } else {
      robots = `User-agent: *\nAllow: /\n\nSitemap: ${report.origin}/sitemap.xml\n`;
    }
    const robotsChanged = robots.trim() !== (report.robots.text || '').trim();
    siteFiles.push({ name: 'robots.txt', content: robots, needed: robotsChanged, why: report.robots.text ? 'Débloque les robots d’IA et déclare le sitemap.' : 'Crée le fichier qui guide les robots et pointe vers le sitemap.' });
    // sitemap.xml
    const today = new Date().toISOString().slice(0, 10);
    const smPages = indexable.filter(p => p.url.startsWith(report.origin));
    const sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
      smPages.map(p => { let lm = today; if (p.headers && p.headers.lastModified) { const d = new Date(p.headers.lastModified); if (!isNaN(d)) lm = d.toISOString().slice(0, 10); } return `  <url><loc>${escXml(p.url)}</loc><lastmod>${lm}</lastmod></url>`; }).join('\n') + '\n</urlset>\n';
    // jamais un sitemap vide, ni un sitemap qui oublierait la moitié des pages déjà déclarées
    const smNeeded = smPages.length > 0 && smPages.length >= (report.sitemap.count || 0) * 0.5 && (!report.sitemap.count || report.issues.some(i => ['sitemap_bad', 'sitemap_noindex', 'not_in_sitemap', 'no_sitemap'].includes(i.id)));
    siteFiles.push({ name: 'sitemap.xml', content: sitemap, needed: smNeeded, why: `Liste propre des ${smPages.length} pages indexables, sans erreur ni redirection.` });
    // llms.txt
    const homeDesc = (home && (home.description || (home.geo && home.geo.firstParagraph))) || '';
    const groups = new Map();
    for (const p of smPages) {
      if (p.url === report.home) continue;
      const seg = pathOf(p.url).split('/').filter(Boolean)[0] || '';
      const g = seg && smPages.filter(x => pathOf(x.url).split('/').filter(Boolean)[0] === seg).length > 2 ? seg.replace(/[-_]/g, ' ') : 'Pages principales';
      if (!groups.has(g)) groups.set(g, []);
      groups.get(g).push(p);
    }
    let llms = `# ${brand}\n\n> ${sentenceCut(homeDesc || brand + ' : site officiel.', 300)}\n`;
    for (const [g, list] of [...groups.entries()].sort((a, b) => (a[0] === 'Pages principales' ? -1 : b[0] === 'Pages principales' ? 1 : b[1].length - a[1].length))) {
      llms += `\n## ${g.charAt(0).toUpperCase() + g.slice(1)}\n\n` + list.sort((a, b) => (b.inlinks || 0) - (a.inlinks || 0)).slice(0, 25).map(p => `- [${(p.title || pathOf(p.url)).replace(/[[\]]/g, '')}](${p.url})${p.description ? ': ' + sentenceCut(p.description, 160) : ''}`).join('\n') + '\n';
    }
    siteFiles.push({ name: 'llms.txt', content: llms, needed: !report.llms.ok, why: 'Présente le site aux IA : qui vous êtes et vos pages clés.' });
    // Organization
    const sameAs = home ? [...new Set((home.links || []).filter(l => l.url && SOCIAL.test(new URL(l.url).hostname)).map(l => l.url))].slice(0, 10) : [];
    const logo = home && ((home.og && home.og.image) || (home.images && home.images.list[0] && home.images.list[0].src));
    const org = { '@context': 'https://schema.org', '@type': 'Organization', name: brand, url: report.origin + '/' };
    if (logo) org.logo = new URL(logo, report.home).href;
    if (sameAs.length) org.sameAs = sameAs;
    const orgTag = '<script type="application/ld+json">\n' + JSON.stringify(org, null, 2) + '\n</script>';
    const orgNeeded = !report.pages.some(p => p.schema && p.schema.hasOrg);

    // ---------- corrections page par page ----------
    const usedTitles = new Set(ok.map(p => (p.title || '').toLowerCase()));
    const usedDesc = new Set(ok.map(p => (p.description || '').toLowerCase()));
    const pageFixes = [];
    for (const p of ok) {
      const fx = [];
      const add = (f) => fx.push(Object.assign({ id: p.url + '#' + f.type + (f.key ? ':' + f.key : ''), url: p.url, enabled: true, auto: true }, f));
      const base = (p.h1[0] || '').trim() || (p.title || '').split(/\s[|\-–—·:]\s/)[0] || pathOf(p.url).split('/').filter(Boolean).pop()?.replace(/[-_]/g, ' ') || brand;
      if (has('no_title', p.url) || has('short_title', p.url) || has('long_title', p.url) || has('dup_title', p.url)) {
        const isHome = p.url === report.home;
        const onlyLong = has('long_title', p.url) && !has('dup_title', p.url) && p.title;
        let t = onlyLong ? shortenTitle(p.title, brand) : isHome ? cut(base, 58 - brand.length - 3) + ' | ' + brand : cut(base, 57 - brand.length) + ' | ' + brand;
        if (base.toLowerCase() === brand.toLowerCase()) t = cut(base + (p.focus ? ' : ' + p.focus.word : ''), 60);
        if (!onlyLong && t.length < 30) {
          // title trop court : on précise le sujet avec le premier sous-titre ou le début de la description (jamais avec des mots isolés du menu)
          const h2 = ((p.headings || []).find(h => h.level === 2 && h.text && h.text.length >= 12 && h.text.length <= 60) || {}).text;
          const fromDesc = p.description ? sentenceCut(p.description.split(/[.!?]/)[0], 45) : '';
          const extra = [h2, fromDesc].filter(x => x && !base.toLowerCase().includes(x.toLowerCase()))[0];
          if (extra) t = cut(base + ' : ' + extra, 57 - brand.length) + ' | ' + brand;
          if (t.length < 30 && p.title && p.title.length > t.length) t = p.title; // rien de mieux : on ne propose pas un title inventé
        }
        if (t !== p.title) { // sinon : aucune amélioration fiable à proposer
          if (usedTitles.has(t.toLowerCase()) && t.toLowerCase() !== (p.title || '').toLowerCase()) t = cut(base + ' (' + pathOf(p.url).split('/').filter(Boolean).pop() + ')', 57 - brand.length) + ' | ' + brand;
          usedTitles.add(t.toLowerCase());
          add({ type: 'title', label: 'Balise title', current: p.title || '', proposed: t, why: !p.title ? 'Title manquant' : p.title.length < 30 ? 'Title trop court' : p.title.length > 60 ? 'Title trop long' : 'Title en double' });
        }
      }
      if (p.noindex === false && (has('no_desc', p.url) || has('short_desc', p.url) || has('long_desc', p.url) || has('dup_desc', p.url))) {
        let d = p.geo && p.geo.firstParagraph && p.geo.firstParagraph.length > 60 ? p.geo.firstParagraph : (p.headings || []).filter(h => h.level > 1).slice(0, 3).map(h => h.text).join('. ');
        d = sentenceCut(d || (base + ' : ' + brand + '.'), 155);
        if (d.length < 70) d = sentenceCut((d && !/[.!?]$/.test(d) ? d + '. ' : d ? d + ' ' : '') + `${brand} vous présente ${base.charAt(0).toLowerCase() + base.slice(1)} : informations pratiques, conseils et contact.`, 155);
        if (usedDesc.has(d.toLowerCase())) d = sentenceCut(base + ' : ' + d, 155);
        usedDesc.add(d.toLowerCase());
        add({ type: 'description', label: 'Meta description', current: p.description || '', proposed: d, why: !p.description ? 'Description manquante' : p.description.length < 70 ? 'Description trop courte' : p.description.length > 160 ? 'Description trop longue' : 'Description en double' });
      }
      if (has('no_canonical', p.url) || has('canonical_external', p.url) || has('bad_canonical', p.url) || has('multi_canonical', p.url)) add({ type: 'canonical', label: 'Canonical', current: p.canonical || '', proposed: p.url, why: p.canonical ? 'Canonical incorrecte' : 'Canonical absente' });
      if (!p.lang) add({ type: 'lang', label: 'Langue de la page', current: '', proposed: lang, why: 'Attribut lang absent' });
      if (!p.viewport) add({ type: 'viewport', label: 'Balise viewport', current: '', proposed: 'width=device-width, initial-scale=1', why: 'Affichage mobile' });
      if (!p.noindex && p.og && (!p.og.title || !p.og.description || !p.og.image)) {
        const tags = [];
        const t = (fx.find(f => f.type === 'title') || {}).proposed || p.title;
        const d = (fx.find(f => f.type === 'description') || {}).proposed || p.description;
        const img = p.og.image || (p.images && p.images.list[0] && p.images.list[0].src) || (home && home.og && home.og.image) || (home && home.images && home.images.list[0] && home.images.list[0].src);
        if (!p.og.title && t) tags.push(`<meta property="og:title" content="${escAttr(t)}">`);
        if (!p.og.description && d) tags.push(`<meta property="og:description" content="${escAttr(d)}">`);
        if (!p.og.image && img) tags.push(`<meta property="og:image" content="${escAttr(new URL(img, p.url).href)}">`);
        if (!p.og.type) tags.push(`<meta property="og:type" content="${p.url === report.home ? 'website' : 'article'}">`);
        tags.push(`<meta property="og:url" content="${escAttr(p.url)}">`);
        if (!p.og.twitter) tags.push('<meta name="twitter:card" content="summary_large_image">');
        add({ type: 'head', key: 'og', label: 'Aperçu de partage (Open Graph)', current: '', proposed: tags.join('\n'), why: 'Image et texte quand le lien est partagé' });
      }
      if (p.url === report.home && orgNeeded) add({ type: 'head', key: 'org', label: 'Balisage Organization (JSON-LD)', current: '', proposed: orgTag, why: 'Fait reconnaître la marque par les IA' });
      if (p.geo && p.geo.qa && p.geo.qa.length >= 2 && !p.schema.hasFAQ) {
        const faq = { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: p.geo.qa.map(x => ({ '@type': 'Question', name: x.q, acceptedAnswer: { '@type': 'Answer', text: x.a } })) };
        add({ type: 'head', key: 'faq', label: `Balisage FAQ (${p.geo.qa.length} questions)`, current: '', proposed: '<script type="application/ld+json">\n' + JSON.stringify(faq, null, 2) + '\n</script>', why: 'Questions lisibles directement par Google et les IA' });
      }
      for (const img of (p.images && p.images.list) || []) {
        if (img.alt !== null || !img.raw) continue;
        const a = altFromSrc(img.src || img.raw);
        add({ type: 'alt', key: img.raw, label: 'Texte alternatif', current: img.raw, proposed: a, why: a ? 'Déduit du nom du fichier, à vérifier' : 'Nom de fichier peu parlant : décrivez l’image', enabled: !!a });
      }
      // liens cassés et liens vers des redirections
      for (const l of p.links || []) {
        if (l.kind !== 'page' || !l.internal) continue;
        const target = statusByUrl.get(l.url);
        let to = null, why = '';
        if (target && target.isRedirect && target.redirectTo) { to = target.redirectTo; why = 'Lien vers une adresse redirigée'; }
        else if (target && (target.status >= 400 || target.status === 0)) { to = redirectTarget.get(l.url) || bestMatch(l.url, okUrls, report.home).url; why = 'Lien cassé (' + (target.status || 'aucune réponse') + ')'; }
        if (to && !fx.some(f => f.type === 'href' && f.key === l.raw)) add({ type: 'href', key: l.raw, label: 'Lien « ' + (l.anchor || '…').slice(0, 40) + ' »', current: l.raw, proposed: /^https?:/i.test(l.raw) ? to : pathOf(to), why });
      }
      if (!p.h1.length && !p.noindex) add({ type: 'manual', key: 'h1', label: 'Titre H1', current: '', proposed: `<h1>${escAttr(base)}</h1>`, why: 'À placer en haut du contenu principal', auto: false });
      if (fx.length) pageFixes.push({ url: p.url, title: p.title, fixes: fx });
    }

    const count = pageFixes.reduce((s, x) => s + x.fixes.length, 0) + siteFiles.filter(f => f.needed).length + redirects.length;
    return { brand, lang, siteFiles, redirects, redirectFormats, pageFixes, count, orgTag };
  }

  // Applique la réécriture IA (titles / descriptions) sur les corrections proposées
  function mergeAi(fixes, results) {
    const byUrl = new Map(results.map(r => [r.url, r]));
    for (const pf of fixes.pageFixes) {
      const r = byUrl.get(pf.url); if (!r) continue;
      for (const f of pf.fixes) {
        if (f.type === 'title' && r.title) { f.proposed = cut(r.title, 62); f.ai = true; }
        if (f.type === 'description' && r.description) { f.proposed = sentenceCut(r.description, 158); f.ai = true; }
      }
    }
  }

  // Pack exporté : fichiers + guide lisible
  function packFiles(report, fixes) {
    const R = VX.report, esc = R.esc;
    const files = fixes.siteFiles.filter(f => f.needed).map(f => ({ rel: f.name, content: f.content }));
    if (fixes.redirects.length) {
      files.push({ rel: 'redirections/apache-.htaccess.txt', content: fixes.redirectFormats.htaccess });
      files.push({ rel: 'redirections/nginx.conf.txt', content: fixes.redirectFormats.nginx });
      files.push({ rel: 'redirections/_redirects (Netlify, Cloudflare Pages)', content: fixes.redirectFormats.netlify });
      files.push({ rel: 'redirections/vercel.json', content: fixes.redirectFormats.vercel });
    }
    const rows = [['Page', 'Correction', 'Actuel', 'Proposé', 'Raison']];
    for (const pf of fixes.pageFixes) for (const f of pf.fixes) if (f.enabled) rows.push([pf.url, f.label, f.current, f.proposed, f.why]);
    files.push({ rel: 'corrections-pages.csv', content: '﻿' + rows.map(r => r.map(c => /[";\n,]/.test(String(c)) ? '"' + String(c).replace(/"/g, '""') + '"' : c).join(';')).join('\r\n') });
    const snippet = (f) => f.type === 'title' ? `<title>${esc(f.proposed)}</title>` : f.type === 'description' ? `<meta name="description" content="${escAttr(f.proposed)}">` : f.type === 'canonical' ? `<link rel="canonical" href="${escAttr(f.proposed)}">` : f.type === 'lang' ? `<html lang="${escAttr(f.proposed)}">` : f.type === 'viewport' ? `<meta name="viewport" content="${f.proposed}">` : f.type === 'alt' ? `<img src="${escAttr(f.current)}" alt="${escAttr(f.proposed)}">` : f.type === 'href' ? `href="${escAttr(f.current)}"  →  href="${escAttr(f.proposed)}"` : f.proposed;
    files.push({ rel: 'LISEZMOI.html', content: `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Corrections VANTIX · ${esc(report.host)}</title><style>body{font:15px/1.6 -apple-system,Segoe UI,Arial,sans-serif;max-width:960px;margin:40px auto;padding:0 20px;background:#050507;color:#eee}h1{font-weight:300}h2{font-weight:400;margin-top:40px}pre{background:#111118;padding:12px;border-radius:8px;white-space:pre-wrap;word-break:break-all;font-size:12px}.u{color:#ffb829;font-family:monospace;word-break:break-all}.m{color:#999}</style></head><body>
<h1>Corrections pour ${esc(report.host)}</h1><p class="m">Généré par VANTIX le ${new Date().toLocaleString('fr-FR')}. ${fixes.count} corrections.</p>
<h2>1. Fichiers à déposer à la racine du site</h2><p>${fixes.siteFiles.some(f => f.needed) ? 'Copiez ' + fixes.siteFiles.filter(f => f.needed).map(f => '<b>' + f.name + '</b>').join(', ') + ' à la racine (là où se trouve la page d’accueil).' : 'Aucun fichier à remplacer : votre robots.txt, votre sitemap et votre llms.txt conviennent.'}</p>
${fixes.redirects.length ? `<h2>2. Redirections</h2><p>Choisissez le fichier du dossier <b>redirections</b> qui correspond à votre hébergeur (Apache pour la plupart des hébergements mutualisés, dont Hostinger).</p><pre>${esc(fixes.redirectFormats.htaccess)}</pre>` : ''}
<h2>3. Corrections page par page</h2>${fixes.pageFixes.map(pf => `<p class="u">${esc(pf.url)}</p>${pf.fixes.filter(f => f.enabled).map(f => `<p><b>${esc(f.label)}</b> <span class="m">· ${esc(f.why)}</span></p><pre>${esc(snippet(f))}</pre>`).join('')}`).join('')}
</body></html>` });
    return files;
  }

  // Opérations à appliquer dans les fichiers d'un dossier local
  function localOps(report, fixes, opts) {
    const pages = fixes.pageFixes.map(pf => ({ url: pf.url, path: pathOf(pf.url).split('?')[0], edits: pf.fixes.filter(f => f.enabled && f.auto && f.proposed).map(f => ({ type: f.type, key: f.key || null, value: f.proposed })) })).filter(p => p.edits.length);
    const writes = fixes.siteFiles.filter(f => f.needed && opts.siteFiles).map(f => ({ rel: f.name, content: f.content }));
    if (opts.redirects && fixes.redirects.length) {
      if (opts.redirectFormat === 'htaccess') writes.push({ rel: '.htaccess', content: fixes.redirectFormats.htaccess, mergeBlock: 'VANTIX redirections' });
      if (opts.redirectFormat === 'netlify') writes.push({ rel: '_redirects', content: fixes.redirectFormats.netlify, append: true });
    }
    return { pages, writes };
  }

  VX.fixes = { buildFixes, mergeAi, packFiles, localOps, cut, sentenceCut, shortenTitle, altFromSrc, bestMatch };
})(window.VX = window.VX || {});
