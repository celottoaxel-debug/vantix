// VANTIX — Radar IA : lecture des réponses des IA (marque citée ? à quelle place ? quelles sources ?)
(function (VX) {
  'use strict';

  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const hostOf = (u) => { try { return new URL(/^https?:/i.test(u) ? u : 'https://' + u).hostname.replace(/^www\./, '').toLowerCase(); } catch { return ''; } };
  const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  /** Les façons de nommer une entité : son nom, ses alias, son domaine et le cœur du domaine (getspotiq). */
  function termsOf(ent) {
    const out = new Set();
    for (const t of [ent.name, ...(ent.aliases || [])]) { const n = norm(t).trim(); if (n.length >= 2) out.add(n); }
    const d = hostOf(ent.domain || '');
    if (d) { out.add(d); const core = d.split('.').slice(0, -1).join('.'); if (core.length >= 4) out.add(core); }
    return [...out];
  }
  function firstIndex(text, terms) {
    let best = -1;
    for (const t of terms) {
      const re = new RegExp('(^|[^a-z0-9])' + escRe(t) + '(?=$|[^a-z0-9])', 'g');
      const m = re.exec(text);
      if (m) { const i = m.index + m[1].length; if (best < 0 || i < best) best = i; }
    }
    return best;
  }
  const domainMatches = (sourceDomain, entDomain) => { const d = hostOf(entDomain || ''); return !!d && (sourceDomain === d || sourceDomain.endsWith('.' + d)); };

  /** Analyse d'une réponse : qui est cité, dans quel ordre, et si les sources pointent vers la marque. */
  function analyzeAnswer(answer, project) {
    const text = norm(answer.text);
    const ents = [{ key: 'brand', name: project.brand, aliases: project.aliases, domain: project.site }, ...(project.competitors || []).map((c, i) => ({ key: 'c' + i, ...c }))];
    const found = ents.map((e) => ({ key: e.key, name: e.name, idx: firstIndex(text, termsOf(e)), sourced: (answer.sources || []).some((s) => domainMatches(s.domain, e.domain)) })).filter((e) => e.idx >= 0 || e.sourced);
    const ranked = found.filter((e) => e.idx >= 0).sort((a, b) => a.idx - b.idx);
    ranked.forEach((e, i) => { e.pos = i + 1; });
    const byKey = Object.fromEntries(found.map((e) => [e.key, { mentioned: e.idx >= 0, pos: e.pos || null, sourced: e.sourced }]));
    return { brand: byKey.brand || { mentioned: false, pos: null, sourced: false }, entities: byKey, named: ranked.length };
  }

  /** Synthèse d'un passage du radar. */
  function summarize(run, project) {
    const ok = run.results.filter((r) => r.ok);
    const ents = [{ key: 'brand', name: project.brand, domain: project.site, own: true }, ...(project.competitors || []).map((c, i) => ({ key: 'c' + i, name: c.name, domain: c.domain }))];
    const stats = Object.fromEntries(ents.map((e) => [e.key, { key: e.key, name: e.name, own: !!e.own, mentions: 0, posSum: 0, first: 0, sourced: 0 }]));
    const byProvider = {};
    const sources = new Map();
    const brandDomain = hostOf(project.site || '');
    const compDomains = (project.competitors || []).map((c) => hostOf(c.domain || '')).filter(Boolean);
    for (const r of ok) {
      const a = r.analysis || analyzeAnswer(r, project);
      const bp = byProvider[r.provider] || (byProvider[r.provider] = { ok: 0, mentioned: 0, posSum: 0, sourced: 0 });
      bp.ok++;
      if (a.brand.mentioned) { bp.mentioned++; bp.posSum += a.brand.pos; }
      if (a.brand.sourced) bp.sourced++;
      for (const [k, v] of Object.entries(a.entities)) {
        const s = stats[k]; if (!s) continue;
        if (v.mentioned) { s.mentions++; s.posSum += v.pos; if (v.pos === 1) s.first++; }
        if (v.sourced) s.sourced++;
      }
      const competitorsHere = Object.keys(a.entities).filter((k) => k !== 'brand' && a.entities[k].mentioned).length;
      const seen = new Set();
      for (const src of r.sources || []) {
        const d = src.domain; if (!d || seen.has(d)) continue; seen.add(d);
        const e = sources.get(d) || { domain: d, count: 0, withBrand: 0, withCompetitors: 0, withoutBrand: 0, providers: new Set(), urls: new Map(), own: !!brandDomain && (d === brandDomain || d.endsWith('.' + brandDomain)), competitor: compDomains.some((c) => d === c || d.endsWith('.' + c)) };
        e.count++; e.providers.add(r.provider);
        if (a.brand.mentioned) e.withBrand++; else e.withoutBrand++;
        if (competitorsHere) e.withCompetitors++;
        if (!e.urls.has(src.url)) e.urls.set(src.url, src.title || '');
        sources.set(d, e);
      }
    }
    const total = ok.length;
    const ranking = Object.values(stats).map((s) => ({ ...s, share: total ? Math.round((s.mentions / total) * 1000) / 10 : 0, avgPos: s.mentions ? Math.round((s.posSum / s.mentions) * 10) / 10 : null })).sort((a, b) => b.mentions - a.mentions || (a.avgPos || 99) - (b.avgPos || 99));
    const srcList = [...sources.values()].map((e) => ({
      domain: e.domain, count: e.count, withBrand: e.withBrand, withoutBrand: e.withoutBrand, withCompetitors: e.withCompetitors, own: e.own, competitor: e.competitor,
      providers: [...e.providers], urls: [...e.urls.entries()].slice(0, 8).map(([url, title]) => ({ url, title })),
      // une source est une opportunité quand les IA s'en servent pour répondre sans vous citer
      opportunity: !e.own && !e.competitor && e.withoutBrand > 0 ? e.withoutBrand * 2 + e.withCompetitors + e.providers.size : 0,
    })).sort((a, b) => b.count - a.count);
    const providers = Object.fromEntries(Object.entries(byProvider).map(([p, v]) => [p, { ok: v.ok, mentioned: v.mentioned, share: v.ok ? Math.round((v.mentioned / v.ok) * 1000) / 10 : 0, avgPos: v.mentioned ? Math.round((v.posSum / v.mentioned) * 10) / 10 : null, sourced: v.sourced }]));
    const brand = ranking.find((r) => r.own);
    return {
      answers: total, errors: run.results.length - total,
      share: brand ? brand.share : 0, avgPos: brand ? brand.avgPos : null, first: brand ? brand.first : 0, sourced: brand ? brand.sourced : 0,
      rank: ranking.findIndex((r) => r.own) + 1, ranking, providers,
      sources: srcList.slice(0, 200),
      opportunities: srcList.filter((s) => s.opportunity > 0).sort((a, b) => b.opportunity - a.opportunity).slice(0, 30),
    };
  }

  /** Lignes du tableau questions × IA. */
  function questionGrid(run) {
    const rows = new Map();
    for (const r of run.results) {
      const row = rows.get(r.question) || { question: r.question, cells: {} };
      row.cells[r.provider] = r.ok ? { ok: true, mentioned: r.analysis.brand.mentioned, pos: r.analysis.brand.pos, sourced: r.analysis.brand.sourced, named: r.analysis.named } : { ok: false, error: r.error };
      rows.set(r.question, row);
    }
    return [...rows.values()];
  }

  function parseCompetitors(text) {
    return String(text || '').split(/\n+/).map((l) => l.trim()).filter(Boolean).map((l) => {
      const [a, b] = l.split(/\s*[|;,]\s*/);
      const looksDomain = (s) => /\.[a-z]{2,}(\/|$)/i.test(s || '') && !/\s/.test(s || '');
      if (b) return looksDomain(a) && !looksDomain(b) ? { name: b, domain: hostOf(a) } : { name: a, domain: looksDomain(b) ? hostOf(b) : '' };
      return looksDomain(a) ? { name: a.replace(/^https?:\/\//, '').replace(/^www\./, '').split('.')[0].replace(/^./, (c) => c.toUpperCase()), domain: hostOf(a) } : { name: a, domain: '' };
    }).slice(0, 15);
  }

  VX.radar = { norm, hostOf, termsOf, analyzeAnswer, summarize, questionGrid, parseCompetitors };
})(window.VX = window.VX || {});
