// VANTIX — Trafic : d'où viennent les visiteurs d'un site (IA, moteurs, réseaux, sites, direct)
(function () {
  'use strict';
  const api = window.vantix, UI = window.__vxUi;
  if (!UI) return;
  const { toast, modal, esc, show, $, $$, fmt } = UI;

  // Couleur = groupe de provenance, toujours la même (palette validée sur le fond sombre de VANTIX)
  const GROUPS = [
    { key: 'IA', label: 'IA (ChatGPT, Perplexity…)', short: 'IA', color: '#3987e5' },
    { key: 'Moteurs', label: 'Moteurs de recherche', short: 'Moteurs', color: '#d95926' },
    { key: 'Réseaux sociaux', label: 'Réseaux sociaux', short: 'Réseaux', color: '#199e70' },
    { key: 'Autres sites', label: 'Autres sites', short: 'Sites', color: '#c98500' },
    { key: 'Direct', label: 'Direct', short: 'Direct', color: '#d55181' },
  ];
  const GCOLOR = Object.fromEntries(GROUPS.map((g) => [g.key, g.color]));
  const AI = ['ChatGPT', 'Perplexity', 'Gemini', 'Claude', 'Copilot', 'Autre IA'];
  const groupOf = (ch) => AI.includes(ch) ? 'IA' : ['Google', 'Bing', 'Autre moteur'].includes(ch) ? 'Moteurs' : ch === 'Réseaux sociaux' ? 'Réseaux sociaux' : ch === 'Autre site' ? 'Autres sites' : 'Direct';
  const PERIODS = [[7, '7 jours'], [30, '30 jours'], [90, '90 jours'], [365, '12 mois']];
  const store = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} } };
  const body = () => $('#trafficBody');
  const pctOf = (a, b) => (b ? Math.round((a / b) * 1000) / 10 : 0);
  const pctTxt = (v) => v.toLocaleString('fr-FR') + ' %';
  const deltaHtml = (cur, prev) => {
    if (!prev) return cur ? '<em class="up">nouveau</em>' : '';
    const d = Math.round(((cur - prev) / prev) * 100);
    return `<em class="${d >= 0 ? 'up' : 'down'}">${d >= 0 ? '▲ +' : '▼ '}${d.toLocaleString('fr-FR')} %</em>`;
  };
  const dateFr = (s, opts) => new Date(s + 'T12:00:00').toLocaleDateString('fr-FR', opts || { day: 'numeric', month: 'short' });

  let conn = null, days = store.get('vx-traffic-days', 30), last = null;

  // ---------- connexions ----------
  async function openTraffic() {
    if (!api || !api.trafficList) return toast('Disponible dans l’application de bureau.');
    show('v-traffic');
    const list = await api.trafficList();
    if (!list.length) return setup(null);
    conn = list.find((c) => conn && c.id === conn.id) || list[0];
    render(list);
  }

  function setup(existing) {
    const id = existing ? existing.id : 't' + Date.now().toString(36);
    const bytes = new Uint8Array(32); crypto.getRandomValues(bytes);
    const fresh = btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    body().innerHTML = `<div class="radar">
      <span class="label">Trafic</span>
      <h1>D’où viennent vos visiteurs ?</h1>
      <p class="lede">Reliez VANTIX à votre site pour voir, jour par jour, combien de visiteurs arrivent de ChatGPT, Perplexity, Gemini, Google, des réseaux sociaux ou d’autres sites.</p>
      <form class="rform" id="tForm" novalidate>
        <div class="grid2">
          <label class="opt"><span>Adresse du site</span><input class="field" id="tUrl" value="${esc(existing ? existing.url : 'https://getspotiq.com')}" spellcheck="false"></label>
          <label class="opt"><span>Nom affiché</span><input class="field" id="tName" value="${esc(existing ? existing.name : 'SPOTIQ')}"></label>
        </div>
        <label class="opt"><span>Clé d’accès ${existing ? '(laisser telle quelle pour garder la clé actuelle)' : ''}</span>
          <div class="urlrow" style="padding:6px 6px 6px 16px"><input id="tToken" type="text" value="${existing ? '' : esc(fresh)}" placeholder="${existing ? 'Clé enregistrée' : ''}" spellcheck="false" autocomplete="off" style="font:400 13px/1.4 var(--mono)"><button class="ghostbtn" id="tCopy" type="button">Copier</button><button class="ghostbtn" id="tGen" type="button">Nouvelle clé</button></div></label>
        <div class="card steps"><h3>Une seule fois, sur Vercel</h3><ol>
          <li>Sur GitHub, fusionnez la mise à jour <b>« Statistiques de trafic lisibles par VANTIX »</b> (demande de fusion n° 7 du dépôt spotiq).</li>
          <li>Sur <b>vercel.com</b>, ouvrez le projet <b>spotiq</b>, puis <b>Settings</b>, <b>Environment Variables</b>.</li>
          <li>Ajoutez une variable nommée <b class="mono">TRAFFIC_API_TOKEN</b> et collez la clé ci-dessus comme valeur (cochez Production). Enregistrez.</li>
          <li>Onglet <b>Deployments</b> : sur le dernier déploiement, menu <b>…</b>, puis <b>Redeploy</b>. Attendez 2 à 3 minutes.</li>
          <li>Revenez ici et cliquez sur <b>Tester et enregistrer</b>.</li>
        </ol><p class="muted" style="font-size:13px;margin:10px 0 0">Cette clé ne donne accès qu’aux chiffres de provenance (aucune donnée personnelle). Elle est chiffrée sur votre ordinateur. Ne la partagez pas.</p></div>
        <p class="err" id="tErr" role="alert"></p>
        <div class="toolbar"><button class="btn" type="submit">Tester et enregistrer</button>${existing ? '<button class="ghostbtn" id="tDel" type="button">Supprimer la connexion</button>' : ''}${existing ? '<button class="ghostbtn" id="tCancel" type="button">Annuler</button>' : ''}</div>
      </form></div>`;
    $('#tCopy').addEventListener('click', () => { const v = $('#tToken').value; if (!v) return; navigator.clipboard.writeText(v).then(() => toast('Clé copiée'), () => toast('Copie impossible')); });
    $('#tGen').addEventListener('click', () => { crypto.getRandomValues(bytes); $('#tToken').value = btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); toast('Nouvelle clé : pensez à la mettre aussi sur Vercel'); });
    const del = $('#tDel'); if (del) del.addEventListener('click', async () => { await api.trafficDelete(id); toast('Connexion supprimée'); conn = null; openTraffic(); });
    const cancel = $('#tCancel'); if (cancel) cancel.addEventListener('click', openTraffic);
    $('#tForm').addEventListener('input', () => { $('#tErr').textContent = ''; });
    $('#tForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const url = $('#tUrl').value.trim(), name = $('#tName').value.trim(), token = $('#tToken').value.trim();
      if (!url) { $('#tErr').textContent = 'Indiquez l’adresse du site.'; return; }
      if (!existing && token.length < 24) { $('#tErr').textContent = 'La clé doit faire au moins 24 caractères.'; return; }
      const btn = $('#tForm button[type=submit]'); btn.disabled = true; btn.textContent = 'Test en cours…';
      try {
        if (token) {
          const t = await api.trafficTest({ url, token });
          if (!t.ok) { $('#tErr').textContent = t.status === 401 ? 'Le site refuse cette clé : vérifiez qu’elle est identique sur Vercel, puis que le site a été redéployé.' : t.status === 503 ? 'Le site n’a pas encore la clé : ajoutez TRAFFIC_API_TOKEN sur Vercel puis redéployez.' : t.error; return; }
        }
        await api.trafficSave({ id, name, url, token: token || undefined });
        toast('Connexion enregistrée'); conn = { id, name, url }; openTraffic();
      } catch (err) { $('#tErr').textContent = err.message; } finally { btn.disabled = false; btn.textContent = 'Tester et enregistrer'; }
    });
  }

  // ---------- tableau de bord ----------
  async function render(list) {
    body().innerHTML = `<header class="rhead"><div><span class="label" id="tStatus">Trafic</span><h1>${esc(conn.name)}</h1><p class="rmeta">${esc(conn.url.replace(/^https?:\/\//, ''))} · provenance des visiteurs</p></div>
      <div class="ractions">${list.length > 1 ? `<select class="sel" id="tConn" aria-label="Site">${list.map((c) => `<option value="${esc(c.id)}" ${c.id === conn.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select>` : ''}
        <div class="seg" role="group" aria-label="Période">${PERIODS.map(([d, l]) => `<button type="button" data-days="${d}" aria-pressed="${d === days}">${l}</button>`).join('')}</div>
        <button class="ghostbtn" id="tRefresh" type="button">Actualiser</button><button class="ghostbtn" id="tEdit" type="button">Connexion</button><button class="ghostbtn" id="tAdd" type="button">Autre site</button></div></header>
      <div class="tabbody" id="tBody"><p class="empty">Chargement des chiffres…</p></div>`;
    $$('[data-days]').forEach((b) => b.addEventListener('click', () => { days = +b.dataset.days; store.set('vx-traffic-days', days); $$('[data-days]').forEach((x) => x.setAttribute('aria-pressed', String(+x.dataset.days === days))); load(); }));
    $('#tRefresh').addEventListener('click', load);
    $('#tEdit').addEventListener('click', () => setup(conn));
    $('#tAdd').addEventListener('click', () => setup(null));
    const sel = $('#tConn'); if (sel) sel.addEventListener('change', () => { conn = list.find((c) => c.id === sel.value); render(list); });
    load();
  }

  async function load() {
    const box = $('#tBody'); if (!box) return;
    box.classList.add('loading');
    const r = await api.trafficFetch({ id: conn.id, days });
    box.classList.remove('loading');
    if (!r.ok) {
      box.innerHTML = `<div class="banner warn"><p>${esc(r.error || 'Impossible de lire les statistiques.')}</p><button class="ghostbtn" type="button" id="tFix">Vérifier la connexion</button></div>`;
      $('#tFix').addEventListener('click', () => setup(conn));
      return;
    }
    last = r.data;
    $('#tStatus').textContent = (r.stale ? 'Hors ligne · chiffres du ' : 'Mis à jour le ') + new Date(r.fetchedAt).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    dashboard(box, r.data);
  }

  function dashboard(box, d) {
    const groupTotals = Object.fromEntries(GROUPS.map((g) => [g.key, { cur: 0, prev: 0 }]));
    for (const c of d.channels) { const g = groupTotals[c.group || groupOf(c.channel)]; g.cur += c.visits; g.prev += c.previous; }
    const aiChannels = AI.map((ch) => d.channels.find((c) => c.channel === ch) || { channel: ch, visits: 0, previous: 0 });
    const tile = (label, cur, prev, color, sub) => `<div class="tile"><b>${fmt(cur)}</b><span>${color ? `<i class="sw" style="background:${color}"></i>` : ''}${label}${sub ? ` <span class="nw">(${sub})</span>` : ''}</span><span class="delta">${deltaHtml(cur, prev)} <small>vs ${d.days} jours précédents</small></span></div>`;
    box.innerHTML = `
      <div class="sec"><div class="tiles">
        ${tile('visites', d.total, d.previousTotal)}
        ${tile('depuis les IA', groupTotals.IA.cur, groupTotals.IA.prev, GCOLOR.IA, pctTxt(pctOf(groupTotals.IA.cur, d.total)))}
        ${tile('depuis les moteurs', groupTotals.Moteurs.cur, groupTotals.Moteurs.prev, GCOLOR.Moteurs, pctTxt(pctOf(groupTotals.Moteurs.cur, d.total)))}
        ${tile('depuis les réseaux sociaux', groupTotals['Réseaux sociaux'].cur, groupTotals['Réseaux sociaux'].prev, GCOLOR['Réseaux sociaux'], pctTxt(pctOf(groupTotals['Réseaux sociaux'].cur, d.total)))}
        ${tile('en direct', groupTotals.Direct.cur, groupTotals.Direct.prev, GCOLOR.Direct, pctTxt(pctOf(groupTotals.Direct.cur, d.total)))}
        <div class="tile"><b>${fmt(d.pricingViews)}</b><span>vues de la page Tarifs</span></div>
      </div></div>
      <div class="sec"><div class="secrow"><h2>Visites par ${d.daily.length > 92 ? 'semaine' : 'jour'}, selon leur provenance</h2><button class="ghostbtn" id="tTable" type="button" aria-pressed="false">Voir en tableau</button></div>
        <div class="card"><div class="legend">${GROUPS.map((g) => `<span><i class="sw" style="background:${g.color}"></i>${g.label} <b>${fmt(groupTotals[g.key].cur)}</b></span>`).join('')}</div><div class="chart" id="tChart"></div><div id="tDaily" hidden></div></div></div>
      <div class="sec words"><div class="card"><h3>Toutes les provenances</h3><div id="tChannels"></div><p class="muted" style="font-size:13px;margin-top:12px">Certaines IA et applications masquent leur provenance : une partie de leurs visiteurs apparaît en « Direct ».</p></div>
        <div class="card"><h3>Visiteurs envoyés par les IA</h3><div id="tAi"></div></div></div>
      <div class="sec"><h2>Pages d’arrivée <small>${d.pages.length} pages</small></h2><div id="tPages"></div></div>
      <div class="sec words"><div class="card"><h3>Pages que les IA recommandent</h3><div id="tAiPages"></div></div><div class="card"><h3>Sites qui vous envoient des visiteurs</h3><div id="tSources"></div></div></div>`;
    botsSection(box, d.bots);
    const chartBox = $('#tChart');
    const draw = () => stackedChart(chartBox, d.daily);
    draw();
    const ro = new ResizeObserver(() => { if (document.body.contains(chartBox)) draw(); else ro.disconnect(); }); ro.observe(chartBox);
    $('#tTable').addEventListener('click', (e) => {
      const on = e.currentTarget.getAttribute('aria-pressed') !== 'true';
      e.currentTarget.setAttribute('aria-pressed', String(on)); e.currentTarget.textContent = on ? 'Voir le graphique' : 'Voir en tableau';
      chartBox.hidden = on; $('#tDaily').hidden = !on;
      if (on) $('#tDaily').innerHTML = `<div class="tablewrap" style="max-height:420px"><table><thead><tr><th>Jour</th>${GROUPS.map((g) => `<th>${g.short}</th>`).join('')}<th>Total</th></tr></thead><tbody>${[...d.daily].reverse().map((day) => { const gs = groupsOfDay(day); return `<tr><td>${dateFr(day.date, { weekday: 'short', day: 'numeric', month: 'short' })}</td>${GROUPS.map((g) => `<td class="num">${fmt(gs[g.key])}</td>`).join('')}<td class="num"><b>${fmt(day.total)}</b></td></tr>`; }).join('')}</tbody></table></div>`;
    });
    barList($('#tChannels'), d.channels.filter((c) => c.visits || c.previous).map((c) => ({ label: c.channel, value: c.visits, prev: c.previous, color: GCOLOR[c.group || groupOf(c.channel)], share: pctOf(c.visits, d.total) })));
    barList($('#tAi'), aiChannels.map((c) => ({ label: c.channel, value: c.visits, prev: c.previous, color: GCOLOR.IA, share: pctOf(c.visits, groupTotals.IA.cur) })), groupTotals.IA.cur ? '' : 'Pas encore de visiteur venu d’une IA sur cette période. Le Radar IA vous dit où travailler pour être recommandé.');
    simpleTable($('#tPages'), ['Page', 'Visites', 'Depuis les IA', 'Depuis les moteurs', 'Depuis les réseaux'], d.pages.map((p) => [`<span class="mono">${esc(p.path)}</span>`, p.visits, p.ai, p.search, p.social]), 'Aucune visite sur cette période.');
    simpleTable($('#tAiPages'), ['Page', 'Visites', 'IA'], d.aiPages.map((p) => [`<span class="mono">${esc(p.path)}</span>`, p.visits, esc(Object.entries(p.channels).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${v}`).join(', '))]), 'Aucune page encore.');
    simpleTable($('#tSources'), ['Site', 'Provenance', 'Visites'], d.sources.filter((s) => s.source !== 'direct').map((s) => [`<span class="mono">${esc(s.source)}</span>`, `<i class="sw" style="background:${GCOLOR[groupOf(s.channel)]}"></i>${esc(s.channel)}`, s.visits]), 'Aucun site référent sur cette période.');
  }

  const BOT_SERIES = [{ key: 'ia', label: 'Robots des IA', short: 'IA', color: '#3987e5' }, { key: 'moteurs', label: 'Robots des moteurs', short: 'Moteurs', color: '#d95926' }];
  const ago = (iso) => { if (!iso) return 'jamais vu'; const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000); return m < 60 ? `il y a ${Math.max(1, m)} min` : m < 1440 ? `il y a ${Math.round(m / 60)} h` : `il y a ${Math.round(m / 1440)} j`; };
  function botsSection(box, b) {
    const sec = document.createElement('div'); sec.className = 'sec'; box.appendChild(sec);
    if (!b || (!b.total && !b.previous)) {
      sec.innerHTML = `<h2>Robots qui lisent votre site</h2><div class="banner warn"><p>Aucun passage de robot enregistré pour l’instant. Il faut que la mise à jour SPOTIQ « Savoir quand ChatGPT, Claude, Perplexity et Google lisent le site » soit en ligne : les premiers passages apparaissent ensuite en quelques heures.</p></div>`;
      return;
    }
    const ai = b.byBot.filter((x) => x.family === 'IA'), se = b.byBot.filter((x) => x.family !== 'IA');
    const sum = (l, k) => l.reduce((s, x) => s + x[k], 0);
    const chatgpt = b.byBot.filter((x) => /GPT|OAI|ChatGPT/.test(x.bot)).map((x) => x.lastSeen).filter(Boolean).sort().pop();
    const claude = b.byBot.filter((x) => /Claude/.test(x.bot)).map((x) => x.lastSeen).filter(Boolean).sort().pop();
    const pplx = b.byBot.filter((x) => /Perplexity/.test(x.bot)).map((x) => x.lastSeen).filter(Boolean).sort().pop();
    const max = Math.max(1, ...b.byBot.map((x) => x.hits));
    sec.innerHTML = `<h2>Robots qui lisent votre site <small>pages lues par les IA et les moteurs</small></h2>
      <div class="tiles" style="margin-bottom:20px">
        <div class="tile"><b>${fmt(sum(ai, 'hits'))}</b><span><i class="sw" style="background:#3987e5"></i>pages lues par les IA</span><span class="delta">${deltaHtml(sum(ai, 'hits'), sum(ai, 'previous'))}</span></div>
        <div class="tile"><b>${fmt(sum(se, 'hits'))}</b><span><i class="sw" style="background:#d95926"></i>pages lues par les moteurs</span><span class="delta">${deltaHtml(sum(se, 'hits'), sum(se, 'previous'))}</span></div>
        <div class="tile"><b style="font-size:20px">${ago(chatgpt)}</b><span>dernière lecture par ChatGPT</span></div>
        <div class="tile"><b style="font-size:20px">${ago(claude)}</b><span>dernière lecture par Claude</span></div>
        <div class="tile"><b style="font-size:20px">${ago(pplx)}</b><span>dernière lecture par Perplexity</span></div>
      </div>
      <div class="card" style="margin-bottom:20px"><div class="legend">${BOT_SERIES.map((g) => `<span><i class="sw" style="background:${g.color}"></i>${g.label}</span>`).join('')}</div><div class="chart" id="tBotChart"></div></div>
      <div class="words"><div class="card"><h3>Chaque robot</h3>${b.byBot.map((x) => `<div class="wbar tb bot" title="${esc(x.bot)}"><span class="w"><i class="sw" style="background:${x.family === 'IA' ? '#3987e5' : '#d95926'}"></i>${esc(x.owner)}</span><span class="track"><i style="width:${(x.hits / max) * 100}%;background:${x.family === 'IA' ? '#3987e5' : '#d95926'}"></i></span><span class="c">${fmt(x.hits)}</span><span class="p">${esc(ago(x.lastSeen))}</span><span class="dl">${deltaHtml(x.hits, x.previous)}</span></div>`).join('')}
        <p class="muted" style="font-size:13px;margin-top:12px">« Lecture à la demande » : l’IA est venue lire la page pendant une conversation, pour répondre à quelqu’un. C’est le signe le plus direct que vous êtes utilisé comme source.</p></div>
        <div class="card"><h3>Pages les plus lues par les IA</h3><div id="tBotPages"></div></div></div>`;
    const chartEl = $('#tBotChart', sec);
    const draw = () => stackedChart(chartEl, b.daily, BOT_SERIES, (d) => ({ ia: d.ia, moteurs: d.moteurs }), 'pages lues');
    draw(); const ro = new ResizeObserver(() => { if (document.body.contains(chartEl)) draw(); else ro.disconnect(); }); ro.observe(chartEl);
    simpleTable($('#tBotPages', sec), ['Page', 'Lectures', 'Robots'], b.aiPaths.map((p) => [`<span class="mono">${esc(p.path)}</span>`, p.hits, esc(p.bots.join(', '))]), 'Aucune page lue par une IA sur cette période.');
  }

  function groupsOfDay(day) {
    const gs = Object.fromEntries(GROUPS.map((g) => [g.key, 0]));
    for (const [ch, v] of Object.entries(day.channels || {})) gs[groupOf(ch)] += v;
    return gs;
  }

  // Barres empilées par jour (par semaine au-delà de 90 jours). Survol = détail de la colonne.
  function stackedChart(el, daily, SERIES = GROUPS, split = groupsOfDay, unit = 'visites') {
    const GROUPS = SERIES;
    let buckets = daily.map((d) => { const g = split(d); return { label: d.date, end: d.date, groups: g, total: d.total != null ? d.total : GROUPS.reduce((s, x) => s + (g[x.key] || 0), 0) }; });
    if (buckets.length > 92) {
      const w = [];
      for (let i = 0; i < buckets.length; i += 7) {
        const chunk = buckets.slice(i, i + 7);
        const g = Object.fromEntries(GROUPS.map((x) => [x.key, chunk.reduce((s, c) => s + c.groups[x.key], 0)]));
        w.push({ label: chunk[0].label, end: chunk[chunk.length - 1].label, groups: g, total: chunk.reduce((s, c) => s + c.total, 0), week: true });
      }
      buckets = w;
    }
    const W = Math.max(320, el.clientWidth || 900), H = 300, L = 44, Rr = 8, T = 12, B = 30;
    const iw = W - L - Rr, ih = H - T - B, n = buckets.length;
    const max = Math.max(1, ...buckets.map((b) => b.total));
    const step = Math.pow(10, Math.floor(Math.log10(max))), nice = [1, 2, 2.5, 5, 10].map((m) => m * step).find((s) => max / s <= 4) || step * 10;
    const top = Math.ceil(max / nice) * nice;
    const y = (v) => T + ih - (v / top) * ih;
    const slot = iw / n, bw = Math.max(1, Math.min(28, slot - 2));
    let svg = `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="${unit} par jour">`;
    for (let v = 0; v <= top; v += nice) svg += `<line x1="${L}" x2="${W - Rr}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" stroke="${v ? '#1d1d25' : '#2c2c38'}"/><text x="${L - 8}" y="${(y(v) + 4).toFixed(1)}" text-anchor="end" class="ax">${fmt(v)}</text>`;
    buckets.forEach((b, i) => {
      const x = L + i * slot + (slot - bw) / 2;
      let base = T + ih;
      svg += `<g class="col" data-c="${i}">`;
      const segs = GROUPS.filter((g) => b.groups[g.key] > 0);
      segs.forEach((g, si) => {
        const h = (b.groups[g.key] / top) * ih;
        const isTop = si === segs.length - 1;
        const gap = isTop ? 0 : Math.min(2, h / 2); // 2 px de fond entre deux segments
        const yTop = base - h, hh = Math.max(0.5, h - gap);
        if (isTop) { const r = Math.min(4, bw / 2, hh); svg += `<path d="M${x},${base} V${yTop + r} Q${x},${yTop} ${x + r},${yTop} H${x + bw - r} Q${x + bw},${yTop} ${x + bw},${yTop + r} V${base} Z" fill="${g.color}" class="seg"/>`; }
        else svg += `<rect x="${x}" y="${(yTop + gap).toFixed(1)}" width="${bw}" height="${hh.toFixed(1)}" fill="${g.color}" class="seg"/>`;
        base = yTop;
      });
      svg += '</g>';
      svg += `<rect x="${L + i * slot}" y="${T}" width="${slot}" height="${ih}" fill="transparent" class="hit" data-i="${i}" tabindex="0"/>`;
    });
    const every = Math.max(1, Math.ceil(n / Math.max(2, Math.floor(iw / 90))));
    buckets.forEach((b, i) => { if (i % every === 0) svg += `<text x="${(L + i * slot + slot / 2).toFixed(1)}" y="${H - 8}" text-anchor="middle" class="ax">${dateFr(b.label)}</text>`; });
    svg += '</svg>';
    el.innerHTML = svg + '<div class="vtip" hidden></div>';
    const tip = $('.vtip', el), svgEl = $('svg', el);
    const showTip = (i, evtX) => {
      const b = buckets[i];
      tip.replaceChildren();
      const h = document.createElement('div'); h.className = 'vt-h'; h.textContent = b.week ? `Semaine du ${dateFr(b.label)} au ${dateFr(b.end)}` : dateFr(b.label, { weekday: 'long', day: 'numeric', month: 'long' }); tip.appendChild(h);
      for (const g of [...GROUPS].reverse()) {
        const row = document.createElement('div'); row.className = 'vt-r';
        const k = document.createElement('i'); k.style.background = g.color;
        const v = document.createElement('b'); v.textContent = fmt(b.groups[g.key]);
        const l = document.createElement('span'); l.textContent = g.short;
        row.append(k, v, l); tip.appendChild(row);
      }
      const t = document.createElement('div'); t.className = 'vt-t'; t.textContent = `Total ${fmt(b.total)} ${unit}`; tip.appendChild(t);
      tip.hidden = false;
      const px = (evtX != null ? evtX : L + (i + 0.5) * slot);
      tip.style.left = Math.min(W - 190, Math.max(0, px + 14)) + 'px'; tip.style.top = '8px';
      $$('.hit', svgEl).forEach((r) => r.classList.toggle('on', +r.dataset.i === i));
      $$('.col', svgEl).forEach((c) => c.classList.toggle('on', +c.dataset.c === i));
      svgEl.classList.add('hovering');
    };
    const hide = () => { tip.hidden = true; svgEl.classList.remove('hovering'); $$('.hit.on, .col.on', svgEl).forEach((r) => r.classList.remove('on')); };
    $$('.hit', svgEl).forEach((r) => {
      r.addEventListener('pointermove', (e) => { const box = el.getBoundingClientRect(); showTip(+r.dataset.i, e.clientX - box.left); });
      r.addEventListener('focus', () => showTip(+r.dataset.i));
      r.addEventListener('blur', hide);
    });
    svgEl.addEventListener('pointerleave', hide);
  }

  function barList(el, rows, emptyMsg) {
    const max = Math.max(1, ...rows.map((r) => r.value));
    el.innerHTML = rows.length && rows.some((r) => r.value || r.prev) ? rows.map((r) => `<div class="wbar tb" title="${esc(r.label)} : ${fmt(r.value)} visites (période précédente : ${fmt(r.prev)})"><span class="w"><i class="sw" style="background:${r.color}"></i>${esc(r.label)}</span><span class="track"><i style="width:${(r.value / max) * 100}%;background:${r.color}"></i></span><span class="c">${fmt(r.value)}</span><span class="p">${r.share ? pctTxt(r.share) : ''}</span><span class="dl">${deltaHtml(r.value, r.prev)}</span></div>`).join('') + (emptyMsg ? `<p class="muted" style="font-size:13px">${esc(emptyMsg)}</p>` : '') : `<p class="empty">${esc(emptyMsg || 'Aucune visite sur cette période.')}</p>`;
  }

  function simpleTable(el, head, rows, empty) {
    el.innerHTML = rows.length ? `<div class="tablewrap" style="max-height:440px"><table><thead><tr>${head.map((h, i) => `<th${i ? ' class="num"' : ''}>${h}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c, i) => `<td${i && typeof c === 'number' ? ' class="num"' : ''}>${typeof c === 'number' ? fmt(c) : c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : `<p class="empty">${esc(empty)}</p>`;
  }

  $('#trafficBtn').addEventListener('click', openTraffic);
  window.__vxTraffic = { openTraffic, stackedChart };
})();
