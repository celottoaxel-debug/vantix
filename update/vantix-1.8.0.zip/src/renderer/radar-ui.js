// VANTIX — Radar IA : interface (projets, lancement, tableau de bord, relance quotidienne)
(function () {
  'use strict';
  const VX = window.VX, R = VX.radar, api = window.vantix, UI = window.__vxUi;
  if (!UI) return;
  const { toast, modal, esc, show, $, $$, fmt } = UI;

  const PROV = [['openai', 'ChatGPT'], ['anthropic', 'Claude'], ['perplexity', 'Perplexity'], ['gemini', 'Gemini']];
  const PLABEL = Object.fromEntries(PROV);
  const KEYINFO = {
    openai: { where: 'platform.openai.com, rubrique API keys', hint: 'sk-…', re: /^sk-/ },
    anthropic: { where: 'platform.claude.com, rubrique API Keys', hint: 'sk-ant-…', re: /^sk-ant-/ },
    perplexity: { where: 'perplexity.ai, rubrique API de votre compte', hint: 'pplx-…', re: /^pplx-/ },
    gemini: { where: 'aistudio.google.com, bouton Get API key', hint: 'AIza…', re: /^AI/ },
  };
  const DEFAULT_MODELS = { openai: 'gpt-5.5', anthropic: 'claude-haiku-5-5', perplexity: 'fast', gemini: 'gemini-3.5-flash' };
  const LANGS = [['fr', 'Français'], ['en', 'Anglais'], ['es', 'Espagnol'], ['de', 'Allemand'], ['it', 'Italien'], ['pt', 'Portugais'], ['nl', 'Néerlandais']];
  const store = { get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} } };
  const models = () => ({ ...DEFAULT_MODELS, ...store.get('vx-radar-models', {}) });
  const newId = () => 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const dateFr = (d) => new Date(d).toLocaleString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const pct = (v) => (v == null ? '–' : (Math.round(v * 10) / 10).toLocaleString('fr-FR') + ' %');
  const posTxt = (p) => (p == null ? '–' : (p === 1 ? '1re' : p.toLocaleString('fr-FR') + 'e'));
  const body = () => $('#radarBody');

  let keys = {}, current = null, viewRun = null;
  const busy = new Set(); // projets en cours d'interrogation

  async function refreshKeys() { try { keys = await api.keysStatus(); } catch { keys = {}; } return keys; }

  // ---------- accueil ----------
  async function openRadar() {
    if (!api || !api.radarList) return toast('Disponible dans l’application de bureau.');
    show('v-radar'); $$('.hitem').forEach((h) => h.setAttribute('aria-current', 'false'));
    await refreshKeys();
    let list = []; try { list = await api.radarList(); } catch {}
    const nKeys = PROV.filter(([p]) => keys[p]).length;
    body().innerHTML = `<div class="radar">
      <span class="label">Radar IA</span>
      <h1>Les IA recommandent-elles votre marque ?</h1>
      <p class="lede">VANTIX pose à ChatGPT, Claude, Perplexity et Gemini les questions de vos clients, puis mesure qui est recommandé, à quelle place, et quelles sources les IA utilisent pour répondre.</p>
      <div class="sec"><div class="secrow"><h2>Vos radars</h2><button class="btn" id="rdNew" type="button">Nouveau radar</button></div>
        ${list.length ? `<div class="cards">${list.map((p) => `<button class="rcard" data-pid="${esc(p.id)}"><b>${esc(p.brand)}</b><div class="row"><span>${esc(p.site || '')}</span>${p.auto ? '<span style="color:var(--spark)">quotidien</span>' : ''}</div><div class="row"><span style="color:var(--text)">Part de voix ${pct(p.lastShare)}</span><span>${p.runs} passage${p.runs > 1 ? 's' : ''}</span></div><span class="muted" style="font-size:12px">${p.lastDate ? 'Dernier : ' + dateFr(p.lastDate) : 'Jamais lancé'}${busy.has(p.id) ? ' · en cours…' : ''}</span></button>`).join('')}</div>` : '<p class="empty">Créez votre premier radar : votre marque, vos concurrents et les questions que posent vos clients.</p>'}
      </div>
      <div class="sec"><h2>Les IA interrogées <small>${nKeys} sur 4 prêtes</small></h2>
        <div class="keys">${PROV.map(([p, l]) => `<div class="keyrow"><span class="dot ${keys[p] ? 'on' : ''}"></span><b>${l}</b><span class="muted">${keys[p] ? 'Clé enregistrée · modèle ' + esc(models()[p]) : 'Pas de clé'}</span><button class="ghostbtn" type="button" data-key="${p}">${keys[p] ? 'Modifier' : 'Ajouter la clé'}</button></div>`).join('')}</div>
        <p class="muted" style="font-size:13px;margin-top:12px">Chaque clé est chiffrée par votre système et ne sert qu’à interroger l’IA concernée. Comptez en général 1 à 3 centimes par question et par IA (recherche web comprise), facturés par chaque fournisseur sur votre propre compte.</p>
      </div></div>`;
    $('#rdNew').addEventListener('click', () => editProject(null));
    $$('[data-pid]', body()).forEach((b) => b.addEventListener('click', async () => { try { openProject(await api.radarLoad(b.dataset.pid)); } catch { toast('Impossible d’ouvrir ce radar.'); } }));
    $$('[data-key]', body()).forEach((b) => b.addEventListener('click', () => keyModal(b.dataset.key, openRadar)));
  }

  function keyModal(p, after) {
    const info = KEYINFO[p], has = keys[p], m0 = models()[p];
    modal(`<h2>Clé ${PLABEL[p]}</h2>
      <p>Créez une clé sur <b>${esc(info.where)}</b>, puis collez-la ici. Elle est chiffrée par votre système.</p>
      <input type="password" id="kKey" placeholder="${has ? 'Clé enregistrée : laisser vide pour la garder' : esc(info.hint)}" autocomplete="off" spellcheck="false" aria-label="Clé API">
      <label class="opt"><span>Modèle (réglage avancé, à changer seulement si le fournisseur l’a renommé)</span><input type="text" id="kModel" class="field" value="${esc(m0)}" spellcheck="false"></label>
      <div class="acts">${has ? '<button class="ghostbtn" id="kDel" type="button">Supprimer la clé</button>' : ''}<button class="ghostbtn" data-close type="button">Fermer</button><button class="btn" id="kSave" type="button">Enregistrer</button></div>`, (m, close) => {
      const del = $('#kDel', m);
      if (del) del.addEventListener('click', async () => { await api.setProviderKey(p, ''); await refreshKeys(); toast('Clé supprimée'); close(); after && after(); });
      $('#kSave', m).addEventListener('click', async () => {
        const k = $('#kKey', m).value.trim(), mod = $('#kModel', m).value.trim();
        const all = store.get('vx-radar-models', {}); if (mod && mod !== DEFAULT_MODELS[p]) all[p] = mod; else delete all[p]; store.set('vx-radar-models', all);
        try {
          if (k) {
            if (!info.re.test(k) && !confirm('Cette clé ne ressemble pas à une clé ' + PLABEL[p] + '. L’enregistrer quand même ?')) return;
            await api.setProviderKey(p, k); toast('Clé ' + PLABEL[p] + ' enregistrée');
          }
          await refreshKeys(); close(); after && after();
        } catch (e) { toast(e.message); }
      });
    });
  }

  // ---------- création / modification ----------
  function editProject(p) {
    const isNew = !p;
    p = p || { id: newId(), brand: '', site: '', aliases: [], description: '', competitors: [], questions: [], lang: 'fr', providers: PROV.map(([k]) => k).filter((k) => keys[k]), auto: false, runs: [] };
    body().innerHTML = `<div class="radar">
      <span class="label">${isNew ? 'Nouveau radar' : 'Modifier le radar'}</span>
      <h1>${isNew ? 'Quelle marque surveiller ?' : esc(p.brand)}</h1>
      <form class="rform" id="rdForm" novalidate>
        <div class="grid2">
          <label class="opt"><span>Nom de la marque</span><input class="field" id="fBrand" value="${esc(p.brand)}" placeholder="SPOTIQ" required></label>
          <label class="opt"><span>Site</span><input class="field" id="fSite" value="${esc(p.site)}" placeholder="getspotiq.com" spellcheck="false"></label>
          <label class="opt"><span>Autres noms de la marque (séparés par des virgules)</span><input class="field" id="fAliases" value="${esc((p.aliases || []).join(', '))}" placeholder="Spot IQ, l’appli Spotiq"></label>
          <label class="opt"><span>Langue des questions</span><select class="field" id="fLang">${LANGS.map(([k, l]) => `<option value="${k}" ${p.lang === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
        </div>
        <label class="opt"><span>Activité, en une phrase (sert à proposer des questions)</span><input class="field" id="fDesc" value="${esc(p.description || '')}" placeholder="Application pour trouver les bonnes adresses et organiser ses voyages"></label>
        <label class="opt"><span>Concurrents, un par ligne : « Nom | site »</span><textarea class="field" id="fComp" rows="5" spellcheck="false" placeholder="Wanderlog | wanderlog.com&#10;Tripadvisor | tripadvisor.fr&#10;Polarsteps | polarsteps.com">${esc((p.competitors || []).map((c) => c.name + (c.domain ? ' | ' + c.domain : '')).join('\n'))}</textarea></label>
        <label class="opt"><span>Questions posées aux IA, une par ligne (50 au maximum)</span><textarea class="field" id="fQs" rows="9" placeholder="Quelle est la meilleure appli pour organiser un voyage ?&#10;Que faire à Lisbonne en 3 jours ?&#10;Une alternative gratuite à Wanderlog ?">${esc((p.questions || []).join('\n'))}</textarea></label>
        <div class="toolbar"><button class="ghostbtn" id="fSuggest" type="button">${keys.anthropic ? 'Proposer 15 questions avec Claude' : 'Proposer des questions (clé Claude nécessaire)'}</button><span class="muted" id="fCount" style="font-size:13px"></span></div>
        <div class="opt"><span>IA à interroger</span><div class="provs">${PROV.map(([k, l]) => `<label class="chk"><input type="checkbox" value="${k}" ${p.providers.includes(k) && keys[k] ? 'checked' : ''} ${keys[k] ? '' : 'disabled'}><span>${l}${keys[k] ? '' : ` <button class="linkbtn" type="button" data-addkey="${k}">ajouter la clé</button>`}</span></label>`).join('')}</div></div>
        <label class="chk"><input type="checkbox" id="fAuto" ${p.auto ? 'checked' : ''}><span>Relancer automatiquement chaque jour (quand VANTIX est ouvert)</span></label>
        <p class="err" id="fErr" role="alert"></p>
        <div class="toolbar"><button class="btn" type="submit">${isNew ? 'Créer et lancer' : 'Enregistrer et lancer'}</button><button class="ghostbtn" id="fSaveOnly" type="button">Enregistrer sans lancer</button><button class="ghostbtn" id="fCancel" type="button">Annuler</button></div>
      </form></div>`;
    const f = $('#rdForm');
    const qs = () => $('#fQs').value.split('\n').map((s) => s.trim()).filter(Boolean);
    const provs = () => $$('.provs input:checked', f).map((i) => i.value);
    const count = () => { const n = qs().length, k = provs().length; $('#fCount').textContent = n ? `${n} question${n > 1 ? 's' : ''} × ${k} IA = ${n * k} appels, environ ${(n * k * 0.02).toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} € par passage (estimation)` : ''; };
    f.addEventListener('input', () => { $('#fErr').textContent = ''; });
    $('#fQs').addEventListener('input', count); $$('.provs input', f).forEach((i) => i.addEventListener('change', count)); count();
    $$('[data-addkey]', f).forEach((b) => b.addEventListener('click', (e) => { e.preventDefault(); keyModal(b.dataset.addkey, () => editProject(collect())); }));
    const collect = () => ({
      ...p, brand: $('#fBrand').value.trim(), site: R.hostOf($('#fSite').value.trim()) || $('#fSite').value.trim(),
      aliases: $('#fAliases').value.split(',').map((s) => s.trim()).filter(Boolean), lang: $('#fLang').value, description: $('#fDesc').value.trim(),
      competitors: R.parseCompetitors($('#fComp').value), questions: [...new Set(qs())].slice(0, 50), providers: provs(), auto: $('#fAuto').checked,
    });
    const validate = (np) => {
      if (!np.brand) return 'Indiquez le nom de votre marque.';
      if (!np.questions.length) return 'Ajoutez au moins une question.';
      if (!np.providers.length) return 'Choisissez au moins une IA (ajoutez une clé si besoin).';
      return '';
    };
    $('#fSuggest').addEventListener('click', async (e) => {
      const b = e.currentTarget;
      if (!keys.anthropic) return keyModal('anthropic', () => editProject(collect()));
      const np = collect(); if (!np.brand) { $('#fErr').textContent = 'Indiquez d’abord le nom de la marque.'; return; }
      b.disabled = true; b.textContent = 'Claude réfléchit…';
      try {
        const list = await api.radarSuggest({ brand: np.brand, site: np.site, description: np.description, competitors: np.competitors.map((c) => c.name), lang: np.lang, n: 15 });
        const cur = qs(); $('#fQs').value = [...new Set([...cur, ...list])].join('\n'); count();
        toast(list.length + ' questions ajoutées : relisez-les');
      } catch (err) { toast(err.message); }
      b.disabled = false; b.textContent = 'Proposer 15 questions avec Claude';
    });
    $('#fCancel').addEventListener('click', () => (isNew ? openRadar() : openProject(p)));
    $('#fSaveOnly').addEventListener('click', async () => { const np = collect(); const err = validate(np); if (err) { $('#fErr').textContent = err; return; } await api.radarSave(np); toast('Radar enregistré'); openProject(np); });
    f.addEventListener('submit', async (e) => { e.preventDefault(); const np = collect(); const err = validate(np); if (err) { $('#fErr').textContent = err; return; } await api.radarSave(np); runProject(np); });
    setTimeout(() => (isNew ? $('#fBrand') : $('#fQs')).focus(), 50);
  }

  // ---------- interrogation ----------
  async function runProject(p, { silent = false } = {}) {
    if (busy.has(p.id)) { if (!silent) toast('Ce radar est déjà en cours.'); return; }
    await refreshKeys();
    const providers = (p.providers || []).filter((k) => keys[k]);
    if (!providers.length) { if (!silent) toast('Aucune IA disponible : ajoutez une clé.'); return; }
    busy.add(p.id);
    const total = providers.length * p.questions.length;
    const st = { done: 0, cancelled: false, results: [], t0: Date.now() };
    const ui = () => {
      if (silent || current !== p || $('#rdRun') === null) return;
      $('#rdDone').textContent = fmt(st.done); $('#rdLeft').textContent = fmt(total - st.done);
      $('#rdBar').style.width = (st.done / total) * 100 + '%';
      const cited = st.results.filter((r) => r.ok && r.analysis.brand.mentioned).length, okN = st.results.filter((r) => r.ok).length;
      $('#rdShare').textContent = okN ? pct((cited / okN) * 100) : '–';
    };
    current = p;
    if (!silent) {
      show('v-radar');
      body().innerHTML = `<div class="run" id="rdRun"><span class="label">Radar IA en cours</span><h1>${esc(p.brand)}</h1>
        <div class="runnums"><div><b id="rdDone">0</b><span>réponses</span></div><div><b id="rdLeft">${fmt(total)}</b><span>en attente</span></div><div><b id="rdShare">–</b><span>part de voix provisoire</span></div></div>
        <div class="bar"><i id="rdBar"></i></div><div class="log" id="rdLog" aria-live="polite"></div>
        <button class="ghostbtn" id="rdStop" type="button">Arrêter et voir les résultats</button></div>`;
      $('#rdStop').addEventListener('click', () => { st.cancelled = true; $('#rdStop').textContent = 'Arrêt après les réponses en cours…'; });
    }
    const log = (m) => { if (silent) return; const l = $('#rdLog'); if (!l) return; const d = document.createElement('div'); d.textContent = new Date().toLocaleTimeString('fr-FR') + '  ' + m; l.appendChild(d); while (l.childNodes.length > 200) l.firstChild.remove(); l.scrollTop = l.scrollHeight; };
    const mod = models();
    await Promise.all(providers.map(async (prov) => {
      for (let i = 0; i < p.questions.length; i++) {
        if (st.cancelled) return;
        const q = p.questions[i];
        const r = await api.radarAsk({ provider: prov, model: mod[prov], question: q, lang: p.lang });
        r.question = q; r.provider = prov;
        if (r.ok) { r.analysis = R.analyzeAnswer(r, p); log(`${PLABEL[prov]} · ${r.analysis.brand.mentioned ? 'vous cite en ' + posTxt(r.analysis.brand.pos) + ' position' : 'ne vous cite pas'} · ${q}`); }
        else log(`${PLABEL[prov]} · erreur : ${r.error}`);
        st.results.push(r); st.done++; ui();
        // clé refusée, crédit épuisé ou modèle inconnu : inutile de continuer avec cette IA
        if (!r.ok && (r.status === 400 || r.status === 401 || r.status === 402 || r.status === 403 || r.status === 404)) {
          for (let j = i + 1; j < p.questions.length; j++) st.results.push({ ok: false, provider: prov, question: p.questions[j], error: 'non interrogée : ' + r.error });
          st.done += p.questions.length - i - 1; ui();
          return;
        }
      }
    }));
    const results = st.results.map((r) => (r.ok ? { ok: true, provider: r.provider, model: r.model, question: r.question, text: (r.text || '').slice(0, 4000), sources: (r.sources || []).slice(0, 20), ms: r.ms, analysis: r.analysis } : { ok: false, provider: r.provider, question: r.question, error: r.error }));
    const run = { date: new Date().toISOString(), cancelled: st.cancelled, durationMs: Date.now() - st.t0, results };
    run.summary = R.summarize(run, p);
    p.runs = [...(p.runs || []), run];
    // on garde le détail des 10 derniers passages, la synthèse des autres
    p.runs.forEach((x, i) => { if (i < p.runs.length - 10 && x.results) { x.results = null; x.summary.sources = x.summary.sources.slice(0, 40); } });
    try { await api.radarSave(p); } catch { toast('Le radar n’a pas pu être enregistré.'); }
    busy.delete(p.id);
    const okN = results.filter((r) => r.ok).length;
    if (!okN) toast('Aucune IA n’a répondu : vérifiez vos clés.');
    else toast(`${p.brand} : part de voix ${pct(run.summary.share)} sur ${okN} réponses`);
    if (!silent || (current === p && !$('#v-radar').hidden)) openProject(p);
  }

  // ---------- tableau de bord ----------
  function trendSvg(runs) {
    const pts = runs.filter((r) => r.summary).map((r) => ({ d: new Date(r.date), v: r.summary.share }));
    if (pts.length < 2) return '';
    const W = 1100, H = 190, P = 30, max = Math.max(10, ...pts.map((p) => p.v));
    const x = (i) => P + (i / (pts.length - 1)) * (W - P * 2), y = (v) => H - P - (v / max) * (H - P * 2);
    const line = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.v).toFixed(1)}`).join(' ');
    return `<svg class="trend" viewBox="0 0 ${W} ${H}" role="img" aria-label="Évolution de la part de voix"><line x1="${P}" x2="${W - P}" y1="${H - P}" y2="${H - P}" stroke="var(--line-2)"/><path d="${line}" fill="none" stroke="var(--iris)" stroke-width="2.5" stroke-linejoin="round"/>${pts.map((p, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(p.v).toFixed(1)}" r="3.5" fill="var(--spark)"><title>${p.d.toLocaleDateString('fr-FR')} : ${pct(p.v)}</title></circle>`).join('')}<text x="${P}" y="${H - 8}" fill="var(--text-3)" font-size="11" font-family="var(--mono)">${pts[0].d.toLocaleDateString('fr-FR')}</text><text x="${W - P}" y="${H - 8}" fill="var(--text-3)" font-size="11" font-family="var(--mono)" text-anchor="end">${pts[pts.length - 1].d.toLocaleDateString('fr-FR')}</text><text x="${P}" y="16" fill="var(--text-3)" font-size="11" font-family="var(--mono)">max ${pct(max)}</text></svg>`;
  }

  function openProject(p, runIndex) {
    current = p; show('v-radar');
    const runs = p.runs || [];
    const run = runs[runIndex == null ? runs.length - 1 : runIndex];
    viewRun = run;
    const head = `<header class="rhead"><div><span class="label">${run ? 'Passage du ' + dateFr(run.date) + (run.cancelled ? ' · arrêté avant la fin' : '') : 'Radar IA'}</span><h1>${esc(p.brand)}</h1><p class="rmeta">${esc(p.site || '')} · ${p.questions.length} questions · ${(p.providers || []).map((k) => PLABEL[k]).join(', ')}${p.auto ? ' · relancé chaque jour' : ''}</p></div>
      <div class="ractions">${runs.length > 1 ? `<select class="sel" id="rdRunSel" aria-label="Passage">${runs.map((r, i) => `<option value="${i}" ${r === run ? 'selected' : ''}>${dateFr(r.date)} · ${pct(r.summary && r.summary.share)}</option>`).reverse().join('')}</select>` : ''}
      <button class="ghostbtn" id="rdBack" type="button">Tous les radars</button><button class="ghostbtn" id="rdEdit" type="button">Modifier</button>${run && run.results ? '<button class="ghostbtn" id="rdCsv" type="button">Exporter (CSV)</button>' : ''}<button class="ghostbtn" id="rdDel" type="button">Supprimer</button><button class="btn" id="rdRunBtn" type="button">${busy.has(p.id) ? 'En cours…' : run ? 'Relancer' : 'Lancer'}</button></div></header>`;
    if (!run) {
      body().innerHTML = head + `<div class="tabbody"><p class="empty">Ce radar n’a pas encore été lancé.</p></div>`;
      return bindHead(p);
    }
    const s = run.summary, ranking = s.ranking, maxShare = Math.max(1, ...ranking.map((r) => r.share));
    const prev = runs[runs.indexOf(run) - 1];
    const delta = prev && prev.summary ? Math.round((s.share - prev.summary.share) * 10) / 10 : null;
    const grid = run.results ? R.questionGrid(run) : [];
    const provs = PROV.filter(([k]) => s.providers[k] || grid.some((g) => g.cells[k]));
    body().innerHTML = head + `<div class="tabbody">
      <div class="sec"><div class="tiles">
        <div class="tile ${s.share >= 30 ? 'good' : s.share < 10 ? 'bad' : ''}"><b>${pct(s.share)}</b><span>part de voix : réponses qui vous citent${delta != null ? ` · <em style="color:${delta >= 0 ? 'var(--ok)' : 'var(--crit)'}">${delta >= 0 ? '+' : ''}${delta.toLocaleString('fr-FR')} pt</em>` : ''}</span></div>
        <div class="tile"><b>${s.rank ? s.rank + '<span class="muted" style="font-size:16px"> / ' + ranking.length + '</span>' : '–'}</b><span>votre rang face aux concurrents</span></div>
        <div class="tile"><b>${posTxt(s.avgPos)}</b><span>position moyenne quand vous êtes cité</span></div>
        <div class="tile"><b>${fmt(s.first)}</b><span>réponses où vous êtes cité en premier</span></div>
        <div class="tile"><b>${fmt(s.sourced)}</b><span>réponses qui utilisent votre site comme source</span></div>
        <div class="tile ${s.errors > s.answers ? 'bad' : ''}"><b>${fmt(s.answers)}</b><span>réponses analysées${s.errors ? ` · ${s.errors} en erreur` : ''}</span></div>
      </div></div>
      ${runs.length > 1 ? `<div class="sec"><h2>Évolution de votre part de voix</h2><div class="card">${trendSvg(runs)}</div></div>` : ''}
      <div class="sec words"><div class="card"><h3>Qui les IA recommandent</h3>${ranking.map((r) => `<div class="wbar rk"><span class="w" style="${r.own ? 'color:var(--spark)' : ''}">${esc(r.name)}${r.own ? ' (vous)' : ''}</span><span class="track"><i style="width:${(r.share / maxShare) * 100}%;${r.own ? 'background:linear-gradient(90deg,var(--spark),#ffd27a)' : ''}"></i></span><span class="c">${pct(r.share)}</span><span class="p">${r.avgPos ? 'pos. ' + r.avgPos.toLocaleString('fr-FR') : ''}</span></div>`).join('')}
        <p class="muted" style="font-size:13px;margin-top:12px">Part des réponses qui citent chaque marque, et sa place moyenne dans la réponse.</p></div>
        <div class="card"><h3>Par IA</h3>${provs.map(([k, l]) => { const v = s.providers[k]; return `<div class="wbar"><span class="w">${l}</span><span class="track"><i style="width:${v ? v.share : 0}%"></i></span><span class="c">${v ? pct(v.share) : 'erreur'}</span><span class="p">${v && v.avgPos ? 'pos. ' + v.avgPos.toLocaleString('fr-FR') : ''}</span></div>`; }).join('')}
        <p class="muted" style="font-size:13px;margin-top:12px">Chaque IA a ses propres sources : être absent de l’une d’elles se corrige souvent sur quelques sites précis (voir ci-dessous).</p></div></div>
      <div class="sec"><h2>Où obtenir une mention <small>sources utilisées par les IA quand elles ne vous citent pas</small></h2>
        ${s.opportunities.length ? `<div class="tablewrap"><table><thead><tr><th>Site</th><th>Utilisé sans vous citer</th><th>Avec un concurrent cité</th><th>IA</th><th>Pages citées</th></tr></thead><tbody>${s.opportunities.slice(0, 20).map((o) => `<tr><td class="url">${esc(o.domain)}</td><td class="num">${o.withoutBrand}</td><td class="num">${o.withCompetitors}</td><td>${o.providers.map((k) => PLABEL[k]).join(', ')}</td><td class="url">${o.urls.slice(0, 3).map((u) => `<button class="linkbtn" type="button" data-ext="${esc(u.url)}">${esc((u.title || u.url).slice(0, 70))}</button>`).join('<br>')}</td></tr>`).join('')}</tbody></table></div>
        <p class="muted" style="font-size:13px;margin-top:12px">Ces pages nourrissent les réponses des IA. Y être mentionné (article invité, comparatif, fiche, réponse sur un forum) est le moyen le plus direct d’apparaître dans leurs recommandations.</p>` : '<p class="empty">Aucune source à cibler pour l’instant.</p>'}
      </div>
      ${grid.length ? `<div class="sec"><h2>Question par question <small>cliquez sur une case pour lire la réponse</small></h2><div class="tablewrap"><table class="qgrid"><thead><tr><th>Question</th>${provs.map(([, l]) => `<th>${l}</th>`).join('')}</tr></thead><tbody>${grid.map((g, gi) => `<tr><td>${esc(g.question)}</td>${provs.map(([k]) => { const c = g.cells[k]; if (!c) return '<td></td>'; return `<td><button type="button" class="cell ${!c.ok ? 'err' : c.mentioned ? 'yes' : 'no'}" data-q="${gi}" data-p="${k}">${!c.ok ? 'erreur' : c.mentioned ? 'cité · ' + posTxt(c.pos) : 'absent'}${c.ok && c.sourced ? ' · source' : ''}</button></td>`; }).join('')}</tr>`).join('')}</tbody></table></div></div>` : ''}
      <div class="sec"><h2>Toutes les sources citées <small>${s.sources.length} sites</small></h2>
        <div class="tablewrap"><table><thead><tr><th>Site</th><th>Citations</th><th>Réponses qui vous citent</th><th>IA</th><th></th></tr></thead><tbody>${s.sources.slice(0, 60).map((o) => `<tr><td class="url">${esc(o.domain)}</td><td class="num">${o.count}</td><td class="num">${o.withBrand}</td><td>${o.providers.map((k) => PLABEL[k]).join(', ')}</td><td>${o.own ? '<span style="color:var(--ok)">votre site</span>' : o.competitor ? '<span style="color:var(--crit)">concurrent</span>' : ''}</td></tr>`).join('')}</tbody></table></div></div>
    </div>`;
    bindHead(p);
    $$('[data-ext]', body()).forEach((b) => b.addEventListener('click', () => api.openExternal(b.dataset.ext)));
    $$('.cell', body()).forEach((b) => b.addEventListener('click', () => answerModal(p, grid[+b.dataset.q].question, b.dataset.p)));
  }

  function bindHead(p) {
    $('#rdBack').addEventListener('click', openRadar);
    $('#rdEdit').addEventListener('click', () => editProject(p));
    $('#rdRunBtn').addEventListener('click', () => runProject(p));
    const sel = $('#rdRunSel'); if (sel) sel.addEventListener('change', () => openProject(p, +sel.value));
    $('#rdDel').addEventListener('click', () => modal(`<h2>Supprimer ce radar ?</h2><p>Le radar ${esc(p.brand)} et tout son historique seront effacés de cet ordinateur.</p><div class="acts"><button class="ghostbtn" data-close type="button">Annuler</button><button class="btn" id="mDelOk" type="button">Supprimer</button></div>`, (m, close) => {
      $('#mDelOk', m).addEventListener('click', async () => { await api.radarDelete(p.id); close(); toast('Radar supprimé'); openRadar(); });
    }));
    const csv = $('#rdCsv'); if (csv) csv.addEventListener('click', () => exportCsv(p));
  }

  function answerModal(p, question, prov) {
    const r = viewRun.results.find((x) => x.question === question && x.provider === prov);
    if (!r) return;
    const comps = (p.competitors || []).map((c, i) => ({ c, v: r.ok && r.analysis.entities['c' + i] })).filter((x) => x.v && x.v.mentioned).sort((a, b) => a.v.pos - b.v.pos);
    modal(`<span class="label">${PLABEL[prov]}${r.model ? ' · ' + esc(r.model) : ''}</span><h2 style="font-size:22px">${esc(question)}</h2>
      ${r.ok ? `<p>${r.analysis.brand.mentioned ? `<b style="color:var(--ok)">${esc(p.brand)} est cité en ${posTxt(r.analysis.brand.pos)} position.</b>` : `<b style="color:var(--crit)">${esc(p.brand)} n’est pas cité.</b>`}${comps.length ? ' Concurrents cités : ' + comps.map((x) => esc(x.c.name) + ' (' + posTxt(x.v.pos) + ')').join(', ') + '.' : ''}</p>
      <div class="answer">${esc(r.text)}</div>
      ${r.sources.length ? `<p class="muted" style="font-size:13px">Sources (${r.sources.length})</p><ul>${r.sources.map((s) => `<li><button class="linkbtn" type="button" data-ext="${esc(s.url)}">${esc(s.domain)}</button> <span class="muted">${esc((s.title || '').slice(0, 90))}</span></li>`).join('')}</ul>` : '<p class="muted" style="font-size:13px">Aucune source citée.</p>'}` : `<p class="err">${esc(r.error)}</p>`}
      <div class="acts"><button class="btn" data-close type="button">Fermer</button></div>`, (m) => {
      $('.modal-card').classList.add('wide');
      $$('[data-ext]', m).forEach((b) => b.addEventListener('click', () => api.openExternal(b.dataset.ext)));
    });
  }

  async function exportCsv(p) {
    const run = viewRun; if (!run || !run.results) return;
    const rows = [['Date', 'Question', 'IA', 'Modèle', 'Marque citée', 'Position', 'Votre site en source', 'Concurrents cités', 'Sources', 'Erreur']];
    for (const r of run.results) {
      const comps = r.ok ? (p.competitors || []).map((c, i) => (r.analysis.entities['c' + i] || {}).mentioned ? c.name : null).filter(Boolean).join(', ') : '';
      rows.push([run.date, r.question, PLABEL[r.provider], r.model || '', r.ok ? (r.analysis.brand.mentioned ? 'oui' : 'non') : '', r.ok && r.analysis.brand.pos || '', r.ok ? (r.analysis.brand.sourced ? 'oui' : 'non') : '', comps, r.ok ? r.sources.map((s) => s.domain).join(' ') : '', r.ok ? '' : r.error]);
    }
    const content = '﻿' + rows.map((r) => r.map((c) => /[";\n,]/.test(String(c)) ? '"' + String(c).replace(/"/g, '""') + '"' : c).join(';')).join('\r\n');
    try { await api.exportFile({ defaultName: `radar-ia-${(p.brand || 'marque').toLowerCase().replace(/[^a-z0-9]+/g, '-')}-${run.date.slice(0, 10)}.csv`, content, filters: [{ name: 'CSV', extensions: ['csv'] }] }); } catch (e) { toast(e.message); }
  }

  // ---------- relance quotidienne (quand l'application est ouverte) ----------
  async function autoTick() {
    if (!api || !api.radarList) return;
    let list = []; try { list = await api.radarList(); } catch { return; }
    for (const it of list) {
      if (!it.auto || busy.has(it.id)) continue;
      if (it.lastDate && Date.now() - new Date(it.lastDate).getTime() < 20 * 3600 * 1000) continue;
      try { const p = await api.radarLoad(it.id); await runProject(p, { silent: true }); } catch {}
    }
  }
  setTimeout(autoTick, 15000);
  setInterval(autoTick, 30 * 60 * 1000);

  $('#radarBtn').addEventListener('click', openRadar);
  window.__vxRadar = { openRadar, openProject, runProject, editProject }; // utilisé par les tests
})();
