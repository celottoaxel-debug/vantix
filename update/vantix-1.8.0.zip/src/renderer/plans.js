// VANTIX — les formules et ce qu'elles comprennent (mêmes valeurs que la version web : web/public/plans.js)
// keywords : mots-clés suivis chaque jour ; daily : consignes du jour ; sites : sites suivis
(function (VX) {
  'use strict';
  const DEFS = {
    decouverte: { id: 'decouverte', name: 'Découverte', price: 0, sites: 1, keywords: 100, daily: 1 },
    solo: { id: 'solo', name: 'Solo', price: 29, sites: 1, keywords: 500, daily: 3 },
    pro: { id: 'pro', name: 'Pro', price: 79, sites: 5, keywords: 5000, daily: 10 },
    agence: { id: 'agence', name: 'Agence', price: 199, sites: 25, keywords: 10000, daily: 30 },
  };
  const ORDER = ['decouverte', 'solo', 'pro', 'agence'];
  let current = 'agence';
  const listeners = [];
  VX.plans = {
    DEFS, ORDER,
    get: () => DEFS[current],
    set(id) { if (!DEFS[id]) return; current = id; try { window.vantix.storeSet('plan', { id }); } catch {} listeners.forEach((f) => f(DEFS[current])); },
    onChange(f) { listeners.push(f); },
    /** sélecteur de formule (l'application de bureau n'est pas encore reliée aux comptes en ligne) */
    picker(id) { return `<select class="field planpick" id="${id}" aria-label="Formule">${ORDER.map((k) => `<option value="${k}" ${k === current ? 'selected' : ''}>${DEFS[k].name}${DEFS[k].price ? ' · ' + DEFS[k].price + ' €' : ' · gratuit'}</option>`).join('')}</select>`; },
    ready: (async () => { try { const s = await window.vantix.storeGet('plan'); if (s && DEFS[s.id]) current = s.id; } catch {} })(),
  };
})(window.VX = window.VX || {});
