// VANTIX — outils de croissance : rafraîchir un article, FAQ tirée des vraies questions, plan d'attaque d'un concurrent, avant / après
(function () {
  'use strict';
  const VX = window.VX, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T || !VX.geo) return;
  const G = VX.geo;
  const { $, $$, esc, toast, fmt } = UI;
  const fullUrl = (u) => (/^https?:\/\//i.test(u) ? u : 'https://' + String(u || '').trim());
  const hostOf = (u) => { try { return new URL(fullUrl(u)).hostname.replace(/^www\./, ''); } catch { return ''; } };
  const YEAR = new Date().getFullYear();
  const dateFr = (d) => new Date(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
  const overlap = (a, b) => { if (!a.size) return 0; let n = 0; for (const w of a) if (b.has(w)) n++; return n / a.size; };

  async function suggest(q, lang = 'fr') {
    const r = await api.fetchPage({ url: `https://suggestqueries.google.com/complete/search?client=firefox&ie=utf-8&oe=utf-8&hl=${lang}&q=${encodeURIComponent(q)}` });
    try { const j = JSON.parse(r.body || '[]'); return Array.isArray(j[1]) ? j[1].map(String) : []; } catch { return []; }
  }
  const QWORD = /^(comment|pourquoi|quand|quel|quelle|quels|quelles|o[uù]|combien|que |qu['’]|est-ce|faut-il|peut-on|doit-on|c['’]est quoi|how|what|why|when|where|which|who|can|is |are |do |does |should)/i;
  const isQuestion = (s) => /\?\s*$/.test(s) || QWORD.test(String(s).trim());

  // =====================================================================================
  // 6. RAFRAÎCHIR UN ARTICLE : les pages qui s'essoufflent, et leur mise à jour prête à copier
  // =====================================================================================
  function staleYears(text) { return [...new Set((String(text).match(/\b20[0-3]\d\b/g) || []).map(Number))].filter((y) => y < YEAR && y >= YEAR - 8).sort(); }
  function rankStale(pages, gsc) {
    const gp = new Map(((gsc && gsc.data && gsc.data.pages) || []).map((r) => [r.key.replace(/\/$/, ''), r]));
    const med = T.median(pages.map((p) => p.words)) || 600;
    return pages.filter((p) => !p.noindex && p.words >= 150).map((p) => {
      const g = gp.get(p.url.replace(/\/$/, ''));
      const head = [p.title, p.h1, p.description, p.firstParagraph].join(' ');
      const years = staleYears(head);
      const reasons = []; let score = 0;
      if (years.length) { reasons.push(`date dépassée (${years.join(', ')})`); score += 30; }
      if (g && g.position >= 4 && g.position <= 20 && g.impressions >= 50) { reasons.push(`position ${String(g.position).replace('.', ',')} sur Google : à portée du haut de page`); score += 25 + Math.min(20, g.impressions / 200); }
      if (g && g.impressions >= 200 && g.ctr < 1.5) { reasons.push(`peu de clics (${String(g.ctr).replace('.', ',')} % de clics pour ${fmt(g.impressions)} affichages)`); score += 15; }
      if (p.words < med * 0.6) { reasons.push(`plus courte que vos autres pages (${fmt(p.words)} mots)`); score += 10; }
      if (!p.answerFirst) { reasons.push('pas de réponse directe en début de page'); score += 8; }
      if (!p.faq) { reasons.push('pas de FAQ'); score += 5; }
      if (!p.dated) { reasons.push('pas de date de mise à jour visible'); score += 5; }
      return { ...p, gsc: g || null, years, reasons, score: Math.round(score) };
    }).filter((p) => p.score >= 15).sort((a, b) => b.score - a.score);
  }
  async function openRefresh(el) {
    const saved = await T.load('refresh'), gsc = await T.load('gsc');
    el.innerHTML = `<div class="radar"><span class="label">Rafraîchir un article</span><h1>Les pages qui s’essoufflent, et leur mise à jour</h1>
      <p class="lede">VANTIX repère les articles datés, à portée du haut de Google ou peu cliqués, puis prépare leur mise à jour : questions à ajouter, chiffres à actualiser, sections manquantes.</p>
      <form class="rform" id="rfForm" novalidate><div class="grid2"><label class="opt"><span>Votre site</span><input class="field" id="rfSite" value="${esc(saved ? saved.site : '')}" placeholder="getspotiq.com" spellcheck="false"></label>
      <label class="opt"><span>Ou une seule page à mettre à jour</span><input class="field" id="rfUrl" placeholder="https://getspotiq.com/blog/…" spellcheck="false"></label></div>
      <p class="muted" style="font-size:13px;margin:0">${gsc ? `Vos données Search Console (import du ${esc(dateFr(gsc.date))}) sont utilisées pour repérer les pages à portée du haut de Google.` : 'Astuce : importez votre export Search Console (outil Search Console) pour repérer aussi les pages proches du haut de Google.'}</p>
      <p class="err" id="rfErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Trouver les pages à rafraîchir</button></div></form><div id="rfOut"></div></div>`;
    if (saved && saved.list) showStale($('#rfOut', el), saved);
    $('#rfForm', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const site = $('#rfSite', el).value.trim(), url = $('#rfUrl', el).value.trim();
      if (url) return prepareUpdate($('#rfOut', el), fullUrl(url));
      if (!T.origin(site)) { $('#rfErr', el).textContent = 'Indiquez votre site ou une page.'; return; }
      const out = $('#rfOut', el); const pg = T.progress(out, 'Lecture du site'); pg.title(hostOf(site));
      try {
        const res = await T.sitePages(site, { max: 60, log: pg.log, isStopped: () => pg.stopped, onPage: (n, t, u) => { pg.bar(n / t); pg.cur(u); } });
        const rec = { date: new Date().toISOString(), site: res.origin, list: rankStale(res.pages, gsc).slice(0, 30) };
        await T.save('refresh', rec); showStale(out, rec);
      } catch (x) { out.innerHTML = `<p class="err">${esc(x.message)}</p>`; }
    });
  }
  function showStale(out, rec) {
    out.innerHTML = `<div class="sec"><h2>À rafraîchir en priorité <small>${fmt(rec.list.length)} · ${esc(dateFr(rec.date))}</small></h2>${rec.list.length ? rec.list.map((p, i) => `<div class="card pass"><div class="passhead"><b class="rank">${i + 1}</b><div><h3>${esc(p.h1 || p.title || p.url)}</h3><p class="muted">${esc(p.url)}</p><p>${esc(p.reasons.join(' · '))}</p></div><button class="ghostbtn" type="button" data-up="${i}">Préparer la mise à jour</button></div></div>`).join('') : '<p class="empty">Aucune page ne semble dépassée. Revenez dans un mois.</p>'}</div>`;
    $$('[data-up]', out).forEach((b) => b.addEventListener('click', () => prepareUpdate(out, rec.list[+b.dataset.up].url)));
  }
  async function prepareUpdate(out, url) {
    out.innerHTML = '<p class="muted">Lecture de la page et recherche des questions…</p>';
    try {
      const res = await api.fetchPage({ url });
      if (!res.ok || !res.body) throw new Error('Page illisible : ' + (res.error || res.status));
      const page = VX.parse.analyzePage(res, { depth: 0, startHost: new URL(res.finalUrl || url).hostname, includeSubdomains: false });
      const pt = G.pageText(res.body, url);
      const topic = (page.h1[0] || page.title || '').replace(/\s*[|–-].*$/, '').replace(/\b20\d\d\b/g, '').trim();
      const heads = T.terms(page.headings.map((h) => h.text).join(' '));
      const lang = (page.lang || 'fr').slice(0, 2);
      const qs = new Set();
      for (const pre of (lang === 'en' ? ['how', 'what', 'why', 'best'] : ['comment', 'pourquoi', 'quel', 'combien', 'est-ce que'])) for (const s of await suggest(pre + ' ' + topic, lang)) qs.add(s);
      for (const s of await suggest(topic, lang)) qs.add(s);
      const gsc = await T.load('gsc');
      const tt = T.terms(topic + ' ' + page.title);
      const gq = ((gsc && gsc.data && gsc.data.queries) || []).filter((q) => overlap(T.terms(q.key), tt) >= 0.6).sort((a, b) => b.impressions - a.impressions).slice(0, 25);
      const missing = [...gq.map((q) => ({ q: q.key, from: `Search Console · ${fmt(q.impressions)} affichages, position ${String(q.position).replace('.', ',')}` })), ...[...qs].map((q) => ({ q, from: 'recherches Google' }))]
        .filter((x) => overlap(T.terms(x.q), heads) < 0.6).filter((x, i, a) => a.findIndex((y) => y.q === x.q) === i).slice(0, 20);
      const years = staleYears(pt.text);
      const sc = VX.content && VX.content.scoreArticle ? null : null; void sc;
      const checks = [
        [years.length === 0, years.length ? `Actualiser les mentions d’années passées : ${years.join(', ')} (titre, chiffres, prix, « en ${years[years.length - 1]} »)` : 'Aucune année dépassée dans le texte'],
        [!!page.geo.answerFirst, 'Ouvrir par la réponse directe (2 phrases) avant tout le reste'],
        [!!(page.schema.hasFAQ), 'Ajouter une FAQ (avec son balisage FAQPage) à partir des questions ci-dessous'],
        [!!page.geo.dated, `Afficher « Mis à jour le ${new Date().toLocaleDateString('fr-FR')} » en haut de l’article`],
        [page.geo.sources > 0, 'Citer au moins une source récente (étude, chiffre officiel)'],
        [page.geo.tables > 0 || page.geo.lists > 1, 'Ajouter un tableau ou une liste récapitulative (les IA les reprennent volontiers)'],
      ];
      out.innerHTML = `<div class="sec"><h2>${esc(page.h1[0] || page.title)}</h2><p class="muted">${esc(url)} · ${fmt(page.mainWordCount)} mots</p></div>
        <div class="sec words"><div class="card"><h3>À faire</h3><ul class="checks2">${checks.map(([ok, t]) => `<li class="${ok ? 'ok' : 'ko'}"><span class="ic">${ok ? '✓' : '✕'}</span><div><b>${esc(t)}</b></div></li>`).join('')}</ul></div>
        <div class="card"><h3>Questions à traiter <small class="muted">${fmt(missing.length)}</small></h3>${missing.length ? `<ul class="minilist">${missing.map((m) => `<li><b>${esc(m.q)}</b><br><span class="muted" style="font-size:12px">${esc(m.from)}</span></li>`).join('')}</ul>` : '<p class="empty">L’article couvre déjà les questions courantes.</p>'}</div></div>
        <div class="sec"><h2>La mise à jour rédigée</h2><p class="muted">Une IA rédige la nouvelle introduction, les sections à ajouter et la FAQ, à partir de votre article. Elle n’invente pas de chiffres : ils sont signalés « à compléter ».</p><div class="toolbar"><button class="btn" id="rfAi" type="button">Rédiger la mise à jour</button><button class="ghostbtn" id="rfBack" type="button">Revenir à la liste</button></div><div id="rfAiOut"></div></div>`;
      $('#rfBack', out).addEventListener('click', async () => { const rec = await T.load('refresh'); if (rec) showStale(out, rec); else out.innerHTML = ''; });
      $('#rfAi', out).addEventListener('click', async () => {
        const box = $('#rfAiOut', out), btn = $('#rfAi', out);
        if (!(await G.aiReady())) { box.innerHTML = '<p class="muted">Ajoutez une clé Claude ou ChatGPT dans le Radar IA pour la rédaction automatique.</p>'; return; }
        btn.disabled = true; btn.textContent = 'Rédaction…';
        const r = await api.aiText({ maxTokens: 5000, prompt: `Tu mets à jour un article existant pour ${YEAR}, pour Google et pour les assistants IA. Langue : ${lang}.
Produis en Markdown :
1. « ## Nouvelle introduction » : 2 phrases qui répondent directement au sujet, puis 2 à 3 phrases de contexte ;
2. « ## Sections à ajouter » : pour chaque question non traitée ci-dessous qui mérite une section, un intertitre en forme de question et 80 à 150 mots ;
3. « ## FAQ » : 5 questions et réponses de 40 à 70 mots, réponse directe d'abord ;
4. « ## À vérifier » : la liste des chiffres, prix ou dates du texte actuel qui sont probablement dépassés.
Règles : reste fidèle à l'article, n'invente aucun fait ; si un chiffre manque, écris [à compléter : …]. Pas de superlatifs.

Questions non traitées :
${missing.map((m) => '- ' + m.q).join('\n') || '(aucune)'}

Article actuel :
${pt.text.slice(0, 30000)}` });
        btn.disabled = false; btn.textContent = 'Rédiger à nouveau';
        if (!r.ok) { box.innerHTML = `<p class="err">${esc(r.error)}</p>`; return; }
        box.innerHTML = `<pre class="code wrap">${esc(r.text)}</pre><div class="toolbar"><button class="ghostbtn" id="rfCopy" type="button">Copier</button><button class="ghostbtn" id="rfSave" type="button">Enregistrer en Markdown</button></div>`;
        $('#rfCopy', box).addEventListener('click', () => G.copy(r.text));
        $('#rfSave', box).addEventListener('click', () => api.exportFile({ defaultName: 'mise-a-jour-' + (new URL(url).pathname.split('/').filter(Boolean).pop() || 'accueil') + '.md', content: r.text, filters: [{ name: 'Markdown', extensions: ['md'] }] }).catch((x) => toast(x.message)));
      });
    } catch (x) { out.innerHTML = `<p class="err">${esc(x.message)}</p>`; }
  }

  // =====================================================================================
  // 7. FAQ TIRÉE DES VRAIES QUESTIONS
  // =====================================================================================
  const PREFIX = {
    fr: ['comment', 'pourquoi', 'quel', 'quelle', 'combien', 'est-ce que', 'faut-il', 'peut-on', 'quand', 'où', 'c\'est quoi'],
    en: ['how', 'why', 'what', 'which', 'how much', 'can', 'is', 'when', 'where', 'should'],
    es: ['cómo', 'por qué', 'qué', 'cuál', 'cuánto', 'cuándo', 'dónde', 'se puede'],
  };
  async function collectQuestions(topic, lang, log) {
    const found = new Map();
    const add = (q, from, w) => { const k = q.trim().toLowerCase().replace(/\s+/g, ' ').replace(/\s*\?$/, ''); if (k.length < 8 || k.length > 140) return; const e = found.get(k) || { q: q.trim().replace(/\s*\?$/, '') + ' ?', from: new Set(), w: 0 }; e.from.add(from); e.w += w; found.set(k, e); };
    for (const pre of PREFIX[lang] || PREFIX.fr) { const list = await suggest(pre + ' ' + topic, lang); list.forEach((s, i) => add(s, 'Google', 10 - i)); }
    log && log(`Google : ${found.size} questions`);
    const gsc = await T.load('gsc');
    const tt = T.terms(topic);
    for (const q of ((gsc && gsc.data && gsc.data.queries) || [])) if (isQuestion(q.key) && overlap(tt, T.terms(q.key)) >= 0.5) add(q.key, 'Search Console', 20 + Math.min(30, q.impressions / 50));
    try {
      const r = await api.fetchPage({ url: `https://www.reddit.com/search.json?q=${encodeURIComponent(topic)}&limit=50&sort=relevance&t=year`, timeoutMs: 15000 });
      const j = JSON.parse(r.body || '{}');
      for (const c of ((j.data || {}).children || [])) { const t = (c.data || {}).title || ''; if (isQuestion(t) && overlap(tt, T.terms(t)) >= 0.3) add(t, 'Reddit', 6 + Math.min(10, ((c.data || {}).num_comments || 0) / 10)); }
      log && log('Reddit : lu');
    } catch { log && log('Reddit : indisponible'); }
    return [...found.values()].map((e) => ({ ...e, from: [...e.from] })).sort((a, b) => b.w - a.w).slice(0, 40);
  }
  function faqHtml(items, lang) {
    const ld = { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: items.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })) };
    return `<section class="faq" lang="${lang}">\n  <h2>${lang === 'en' ? 'Frequently asked questions' : lang === 'es' ? 'Preguntas frecuentes' : 'Questions fréquentes'}</h2>\n${items.map((f) => `  <h3>${esc(f.q)}</h3>\n  <p>${esc(f.a)}</p>`).join('\n')}\n</section>\n<script type="application/ld+json">\n${JSON.stringify(ld, null, 2)}\n</script>`;
  }
  async function openFaq(el) {
    const saved = await T.load('faqgen');
    el.innerHTML = `<div class="radar"><span class="label">FAQ réelles</span><h1>Une FAQ faite des questions que les gens posent vraiment</h1>
      <p class="lede">VANTIX récupère les questions tapées sur Google, posées sur Reddit et présentes dans votre Search Console, puis vous prépare la FAQ avec son balisage, prête à coller. Gratuit.</p>
      <form class="rform" id="fqForm" novalidate><div class="grid2"><label class="opt"><span>Sujet</span><input class="field" id="fqTopic" value="${esc(saved ? saved.topic : '')}" placeholder="week-end à lisbonne"></label>
      <label class="opt"><span>Langue</span><select class="field" id="fqLang"><option value="fr">Français</option><option value="en">Anglais</option><option value="es">Espagnol</option></select></label></div>
      <label class="opt"><span>Page qui servira de base aux réponses (facultatif)</span><input class="field" id="fqUrl" value="${esc(saved ? saved.url || '' : '')}" placeholder="https://monsite.fr/lisbonne" spellcheck="false"></label>
      <p class="err" id="fqErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Trouver les questions</button></div></form><div id="fqOut"></div></div>`;
    if (saved) { $('#fqLang', el).value = saved.lang || 'fr'; if (saved.items) showFaq($('#fqOut', el), saved); }
    $('#fqForm', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const topic = $('#fqTopic', el).value.trim(), lang = $('#fqLang', el).value, url = $('#fqUrl', el).value.trim();
      if (!topic) { $('#fqErr', el).textContent = 'Indiquez un sujet.'; return; }
      const out = $('#fqOut', el); const pg = T.progress(out, 'Recherche des questions'); pg.title(topic); pg.bar(0.3);
      try { const qs = await collectQuestions(topic, lang, pg.log); const rec = { date: new Date().toISOString(), topic, lang, url, questions: qs, items: null }; await T.save('faqgen', rec); showFaq(out, rec); }
      catch (x) { out.innerHTML = `<p class="err">${esc(x.message)}</p>`; }
    });
  }
  function showFaq(out, rec) {
    if (!rec.questions.length) { out.innerHTML = '<p class="empty">Aucune question trouvée : essayez un sujet plus court (2 ou 3 mots).</p>'; return; }
    const chosen = new Set(rec.items ? rec.items.map((i) => i.q) : rec.questions.slice(0, 8).map((q) => q.q));
    out.innerHTML = `<div class="sec"><h2>Questions trouvées <small>${fmt(rec.questions.length)}</small></h2><p class="muted">Cochez celles à garder (6 à 10 suffisent).</p>
      <div class="qlist">${rec.questions.map((q, i) => `<label class="chk"><input type="checkbox" data-q="${i}" ${chosen.has(q.q) ? 'checked' : ''}><span>${esc(q.q)} <small class="muted">${esc(q.from.join(', '))}</small></span></label>`).join('')}</div>
      <div class="toolbar" style="margin-top:14px"><button class="btn" id="fqGo" type="button">Préparer la FAQ</button></div></div><div id="fqRes"></div>`;
    if (rec.items) renderFaq($('#fqRes', out), rec);
    $('#fqGo', out).addEventListener('click', async () => {
      const picked = $$('[data-q]', out).filter((c) => c.checked).map((c) => rec.questions[+c.dataset.q].q);
      if (!picked.length) { toast('Cochez au moins une question.'); return; }
      const btn = $('#fqGo', out); btn.disabled = true; btn.textContent = 'Rédaction des réponses…';
      let items = picked.map((q) => ({ q, a: '' }));
      if (await G.aiReady()) {
        let base = '';
        if (rec.url) { const r = await api.fetchPage({ url: fullUrl(rec.url) }); if (r.ok && r.body) base = G.pageText(r.body, rec.url).text.slice(0, 25000); }
        const r = await api.aiText({ json: true, maxTokens: 4000, prompt: `Rédige les réponses d'une FAQ en ${rec.lang}. Chaque réponse : 40 à 80 mots, la réponse directe dans la première phrase, des faits précis, ton neutre.
${base ? 'Appuie-toi uniquement sur le contenu de la page ci-dessous ; si elle ne permet pas de répondre, écris [à compléter : …].' : 'Si une information précise (prix, horaire, chiffre) est incertaine, écris [à compléter : …] plutôt que de l’inventer.'}
Réponds uniquement en JSON : [{"q":"…","a":"…"}] dans le même ordre.

Questions :
${picked.map((q) => '- ' + q).join('\n')}
${base ? '\nPage :\n' + base : ''}` });
        if (r.ok && Array.isArray(r.json)) items = picked.map((q, i) => ({ q, a: String((r.json[i] || {}).a || '') })); else toast(r.error || 'Réponses à rédiger vous-même');
      }
      items = items.map((f) => ({ ...f, a: f.a || '[Réponse à rédiger : la réponse directe en une phrase, puis un ou deux faits précis.]' }));
      rec.items = items; await T.save('faqgen', rec);
      btn.disabled = false; btn.textContent = 'Préparer à nouveau'; renderFaq($('#fqRes', out), rec);
    });
  }
  function renderFaq(box, rec) {
    box.innerHTML = `<div class="sec"><h2>Votre FAQ</h2><p class="muted">Relisez et corrigez les réponses : le code se met à jour.</p>${rec.items.map((f, i) => `<div class="card"><b>${esc(f.q)}</b><textarea class="field" rows="3" data-a="${i}" style="margin-top:8px">${esc(f.a)}</textarea></div>`).join('')}
      <h3 style="margin-top:20px">Code à coller dans la page</h3><pre class="code" id="fqCode"></pre><div class="toolbar"><button class="btn" id="fqCopy" type="button">Copier le code</button><button class="ghostbtn" id="fqSave" type="button">Enregistrer le fichier</button></div></div>`;
    const code = () => faqHtml(rec.items, rec.lang);
    const refresh = () => { $('#fqCode', box).textContent = code(); };
    refresh();
    $$('[data-a]', box).forEach((t) => t.addEventListener('input', () => { rec.items[+t.dataset.a].a = t.value.trim(); refresh(); clearTimeout(t._s); t._s = setTimeout(() => T.save('faqgen', rec), 800); }));
    $('#fqCopy', box).addEventListener('click', () => G.copy(code()));
    $('#fqSave', box).addEventListener('click', () => api.exportFile({ defaultName: 'faq-' + rec.topic.replace(/[^\w]+/g, '-').toLowerCase() + '.html', content: code(), filters: [{ name: 'HTML', extensions: ['html'] }] }).catch((x) => toast(x.message)));
  }

  // =====================================================================================
  // 8. PLAN D'ATTAQUE : les sujets d'un concurrent que vous n'avez pas, et comment les dépasser
  // =====================================================================================
  function strength(p) { return Math.round(p.words / 150 + (p.faq ? 4 : 0) + (p.article ? 2 : 0) + Math.min(8, p.h2.length) + Math.min(5, p.internalLinks / 10) + (p.sources ? 2 : 0) + (p.tables ? 2 : 0)); }
  function attackPlan(rival, own) {
    const ownSets = own.pages.map((p) => ({ p, s: T.terms([p.title, p.h1].join(' ')) }));
    const gaps = [], fights = [];
    for (const p of rival.pages) {
      if (p.noindex || p.words < 250) continue;
      const s = T.terms([p.h1 || p.title].join(' ')); if (s.size < 2) continue;
      let best = null, bo = 0; for (const o of ownSets) { const v = overlap(s, o.s); if (v > bo) { bo = v; best = o.p; } }
      const weak = [];
      if (!p.faq) weak.push('pas de FAQ'); if (!p.answerFirst) weak.push('pas de réponse directe en ouverture'); if (!p.sources) weak.push('aucune source citée');
      if (!p.tables && !(p.lists > 1)) weak.push('ni tableau ni liste'); if (!p.dated) weak.push('pas de date'); if (!p.author) weak.push('pas d’auteur');
      const item = { url: p.url, topic: p.h1 || p.title, words: p.words, h2: p.h2, strength: strength(p), weak, target: Math.max(800, Math.round((p.words * 1.25) / 100) * 100) };
      if (bo >= 0.5) fights.push({ ...item, own: best, ownWords: best.words }); else gaps.push(item);
    }
    gaps.sort((a, b) => b.strength - a.strength); fights.sort((a, b) => (b.words - b.ownWords) - (a.words - a.ownWords));
    const stat = (pages) => ({ pages: pages.length, words: T.median(pages.map((p) => p.words)) || 0, faq: T.share(pages, (p) => p.faq), schema: T.share(pages, (p) => p.schema.length > 0), answer: T.share(pages, (p) => p.answerFirst), dated: T.share(pages, (p) => p.dated) });
    return { gaps: gaps.slice(0, 40), fights: fights.filter((f) => f.words > f.ownWords * 1.2).slice(0, 20), rival: stat(rival.pages), own: stat(own.pages) };
  }
  function briefMd(g, host) {
    return `# ${g.topic}\n\nPage à dépasser : ${g.url} (${g.words} mots)\nObjectif : ${g.target} mots minimum.\n\n## Ouverture\nLa réponse directe en 2 phrases, puis le contexte.\n\n## Plan (sections du concurrent à couvrir, en mieux)\n${g.h2.slice(0, 15).map((h) => '- ' + h).join('\n') || '- (le concurrent n’a pas d’intertitres : structurez en 5 à 8 questions)'}\n\n## Ce qui vous fera passer devant\n${g.weak.map((w) => '- Le concurrent : ' + w + ' → faites-le.').join('\n') || '- Le concurrent est complet : apportez une donnée inédite, un exemple concret ou un outil.'}\n- Une FAQ de 5 questions avec balisage FAQPage.\n- Des liens depuis 3 pages de ${host} qui traitent de sujets proches.\n`;
  }
  async function openAttack(el) {
    const saved = await T.load('attack');
    el.innerHTML = `<div class="radar"><span class="label">Plan d’attaque</span><h1>Prenez la place d’un concurrent</h1>
      <p class="lede">VANTIX lit le site d’un concurrent et le vôtre, trouve les sujets qu’il couvre et pas vous, repère ses points faibles, et vous donne le plan pour faire mieux, sujet par sujet.</p>
      <form class="rform" id="atForm" novalidate><div class="grid2"><label class="opt"><span>Votre site</span><input class="field" id="atOwn" value="${esc(saved ? saved.own : '')}" placeholder="getspotiq.com" spellcheck="false"></label>
      <label class="opt"><span>Le concurrent</span><input class="field" id="atRival" value="${esc(saved ? saved.rival : '')}" placeholder="concurrent.com" spellcheck="false"></label></div>
      <p class="err" id="atErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Préparer le plan</button></div></form><div id="atOut"></div></div>`;
    if (saved && saved.plan) showAttack($('#atOut', el), saved);
    $('#atForm', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const own = $('#atOwn', el).value.trim(), rival = $('#atRival', el).value.trim();
      if (!T.origin(own) || !T.origin(rival)) { $('#atErr', el).textContent = 'Indiquez votre site et celui du concurrent.'; return; }
      const out = $('#atOut', el); const pg = T.progress(out, 'Lecture des deux sites');
      try {
        pg.title(hostOf(rival));
        const r = await T.sitePages(rival, { max: 70, log: pg.log, isStopped: () => pg.stopped, onPage: (n, t, u) => { pg.bar((n / t) * 0.6); pg.cur(u); } });
        pg.title(hostOf(own));
        const o = await T.sitePages(own, { max: 70, log: pg.log, isStopped: () => pg.stopped, onPage: (n, t, u) => { pg.bar(0.6 + (n / t) * 0.4); pg.cur(u); } });
        const rec = { date: new Date().toISOString(), own: o.host, rival: r.host, plan: attackPlan(r, o) };
        await T.save('attack', rec); showAttack(out, rec);
      } catch (x) { out.innerHTML = `<p class="err">${esc(x.message)}</p>`; }
    });
  }
  function showAttack(out, rec) {
    const P = rec.plan, row = (l, a, b, unit = ' %') => `<tr><td>${l}</td><td class="num">${fmt(a)}${unit}</td><td class="num">${fmt(b)}${unit}</td></tr>`;
    out.innerHTML = `<div class="sec"><h2>${esc(rec.rival)} face à ${esc(rec.own)}</h2><div class="tablewrap"><table><thead><tr><th></th><th>${esc(rec.rival)}</th><th>${esc(rec.own)}</th></tr></thead><tbody>
      ${row('Pages lues', P.rival.pages, P.own.pages, '')}${row('Mots par page (médiane)', P.rival.words, P.own.words, '')}${row('Pages avec FAQ', P.rival.faq, P.own.faq)}${row('Pages avec données structurées', P.rival.schema, P.own.schema)}${row('Réponse directe en ouverture', P.rival.answer, P.own.answer)}${row('Pages datées', P.rival.dated, P.own.dated)}</tbody></table></div></div>
      <div class="sec"><h2>Sujets qu’il couvre et pas vous <small>${fmt(P.gaps.length)}</small></h2>${P.gaps.length ? P.gaps.map((g, i) => `<div class="card pass"><div class="passhead"><b class="rank">${i + 1}</b><div><h3>${esc(g.topic)}</h3><p class="muted">${T.ext(g.url, g.url)} · ${fmt(g.words)} mots</p><p>${g.weak.length ? 'Ses faiblesses : ' + esc(g.weak.join(', ')) : 'Page complète : misez sur une donnée inédite.'} · Visez ${fmt(g.target)} mots.</p></div><button class="ghostbtn" type="button" data-brief="${i}">Voir le brief</button></div></div>`).join('') : '<p class="empty">Vous couvrez déjà ses sujets.</p>'}</div>
      ${P.fights.length ? `<div class="sec"><h2>Sujets communs où il va plus loin</h2>${T.table(['Son article', 'Mots', 'Votre page', 'Mots'], P.fights.map((f) => [T.ext(f.url, f.topic), f.words, T.ext(f.own.url, f.own.h1 || f.own.title || f.own.url), f.ownWords]))}</div>` : ''}
      <div class="toolbar"><button class="ghostbtn" id="atMd" type="button">Enregistrer tous les briefs (Markdown)</button></div>`;
    T.bindExt(out);
    $$('[data-brief]', out).forEach((b) => b.addEventListener('click', () => { const g = P.gaps[+b.dataset.brief]; const box = document.createElement('pre'); box.className = 'code wrap'; box.textContent = briefMd(g, rec.own); b.closest('.card').appendChild(box); b.remove(); }));
    $('#atMd', out).addEventListener('click', () => api.exportFile({ defaultName: `plan-attaque-${rec.rival}.md`, content: P.gaps.map((g) => briefMd(g, rec.own)).join('\n---\n\n'), filters: [{ name: 'Markdown', extensions: ['md'] }] }).catch((x) => toast(x.message)));
  }

  // =====================================================================================
  // 9. AVANT / APRÈS : la preuve des progrès, pour vous ou pour un client
  // =====================================================================================
  function diffReports(a, b) {
    const cats = ['global', 'seo', 'geo', 'technique', 'contenu', 'liens'].filter((k) => a.scores[k] != null && b.scores[k] != null).map((k) => ({ k, before: a.scores[k], after: b.scores[k] }));
    const ia = new Map(a.issues.filter((i) => i.sev !== 'info').map((i) => [i.id || i.title, i])), ib = new Map(b.issues.filter((i) => i.sev !== 'info').map((i) => [i.id || i.title, i]));
    const fixed = [], better = [], fresh = [];
    for (const [k, i] of ia) { const j = ib.get(k); if (!j) fixed.push({ title: i.title, sev: i.sev, n: i.items.length }); else if (j.items.length < i.items.length) better.push({ title: i.title, sev: i.sev, before: i.items.length, after: j.items.length }); }
    for (const [k, j] of ib) if (!ia.has(k)) fresh.push({ title: j.title, sev: j.sev, n: j.items.length });
    const st = ['indexable', 'words', 'brokenLinks', 'avgTime', 'critical'].map((k) => ({ k, before: a.stats[k], after: b.stats[k] }));
    return { cats, fixed, better, fresh, stats: st };
  }
  const CAT = { global: 'Score global', seo: 'SEO', geo: 'Visibilité IA', technique: 'Technique', contenu: 'Contenu', liens: 'Liens' };
  const STAT = { indexable: ['Pages indexables', 1], words: ['Mots analysés', 1], brokenLinks: ['Liens cassés', -1], avgTime: ['Temps de réponse (ms)', -1], critical: ['Problèmes critiques', -1] };
  async function openBeforeAfter(el) {
    const reps = await api.listReports().catch(() => []);
    const hosts = [...new Set(reps.map((r) => r.host))].filter((h) => reps.filter((r) => r.host === h).length >= 2);
    el.innerHTML = `<div class="radar"><span class="label">Avant / après</span><h1>La preuve de vos progrès</h1>
      <p class="lede">Comparez deux analyses d’un même site : scores, problèmes résolus, visibilité dans les IA. En un clic, un PDF à envoyer à votre client (ou à garder pour vous).</p>
      ${hosts.length ? `<div class="grid2" style="max-width:820px"><label class="opt"><span>Site</span><select class="field" id="baHost">${hosts.map((h) => `<option>${esc(h)}</option>`).join('')}</select></label><div class="grid2"><label class="opt"><span>Avant</span><select class="field" id="baA"></select></label><label class="opt"><span>Après</span><select class="field" id="baB"></select></label></div></div><div id="baOut"></div>`
      : '<div class="card"><p>Il faut au moins deux analyses du même site. Lancez une analyse maintenant, appliquez les corrections, puis relancez-en une dans quelques jours.</p></div>'}</div>`;
    if (!hosts.length) return;
    const fill = () => {
      const list = reps.filter((r) => r.host === $('#baHost', el).value).sort((x, y) => x.date.localeCompare(y.date));
      const opts = list.map((r) => `<option value="${esc(r.id)}">${esc(dateFr(r.date))} · ${r.scores.global}/100</option>`).join('');
      $('#baA', el).innerHTML = opts; $('#baB', el).innerHTML = opts; $('#baA', el).selectedIndex = 0; $('#baB', el).selectedIndex = list.length - 1; go();
    };
    const go = async () => {
      const [a, b] = await Promise.all([api.loadReport($('#baA', el).value), api.loadReport($('#baB', el).value)]);
      const d = diffReports(a, b);
      let radar = null;
      try { const rl = await api.radarList(); const hit = rl.find((p) => hostOf(p.site) === b.host.replace(/^www\./, '')); if (hit) { const p = await api.radarLoad(hit.id); const runs = (p.runs || []).filter((r) => r.summary); if (runs.length >= 2) radar = { brand: p.brand, before: runs[0].summary, after: runs[runs.length - 1].summary, from: runs[0].date, to: runs[runs.length - 1].date }; } } catch {}
      showBA($('#baOut', el), a, b, d, radar);
    };
    $('#baHost', el).addEventListener('change', fill); $('#baA', el).addEventListener('change', go); $('#baB', el).addEventListener('change', go); fill();
  }
  const sign = (v) => (v > 0 ? '+' : '') + fmt(v);
  function showBA(out, a, b, d, radar) {
    const g = d.cats.find((c) => c.k === 'global');
    out.innerHTML = `<div class="sec"><div class="scorehead"><div class="bigscore" style="color:${g.after >= g.before ? 'var(--ok)' : 'var(--crit)'}">${sign(g.after - g.before)}<small>pts</small></div><div><h2 style="margin:0">${esc(b.host)} : ${g.before} → ${g.after}/100</h2><p class="muted" style="margin:6px 0 0">Du ${esc(dateFr(a.date))} au ${esc(dateFr(b.date))} · ${fmt(d.fixed.length)} problème${d.fixed.length > 1 ? 's' : ''} résolu${d.fixed.length > 1 ? 's' : ''}, ${fmt(d.better.length)} en amélioration.</p></div></div></div>
      <div class="sec"><div class="tiles">${d.cats.filter((c) => c.k !== 'global').map((c) => `<div class="tile ${c.after > c.before ? 'good' : c.after < c.before ? 'bad' : ''}"><b>${c.before} → ${c.after}</b><span>${CAT[c.k]}</span></div>`).join('')}${radar ? `<div class="tile ${radar.after.share >= radar.before.share ? 'good' : 'bad'}"><b>${String(radar.before.share).replace('.', ',')} → ${String(radar.after.share).replace('.', ',')} %</b><span>cité par les IA</span></div>` : ''}</div></div>
      <div class="sec words"><div class="card"><h3>Résolus</h3>${d.fixed.length ? `<ul class="minilist">${d.fixed.map((f) => `<li>✓ ${esc(f.title)} <span class="muted">(${fmt(f.n)})</span></li>`).join('')}</ul>` : '<p class="empty">Aucun.</p>'}${d.better.length ? `<h3 style="margin-top:14px">En amélioration</h3><ul class="minilist">${d.better.map((f) => `<li>${esc(f.title)} <span class="muted">${fmt(f.before)} → ${fmt(f.after)}</span></li>`).join('')}</ul>` : ''}</div>
      <div class="card"><h3>Chiffres clés</h3>${T.table(['', 'Avant', 'Après'], d.stats.filter((s) => s.before != null).map((s) => [STAT[s.k][0], s.before, s.after]))}${d.fresh.length ? `<h3 style="margin-top:14px">Nouveaux points à surveiller</h3><ul class="minilist">${d.fresh.map((f) => `<li>${esc(f.title)} <span class="muted">(${fmt(f.n)})</span></li>`).join('')}</ul>` : ''}</div></div>
      <div class="toolbar"><button class="btn" id="baPdf" type="button">Exporter le PDF avant / après</button></div>`;
    $('#baPdf', out).addEventListener('click', async () => {
      const brand = (await T.load('brand')) || {};
      const col = /^#[0-9a-f]{6}$/i.test(brand.color || '') ? brand.color : '#ff6363';
      const html = baPdf(a, b, d, radar, brand.agency || 'VANTIX', col, brand.logo);
      try { await api.printPdf(html, `avant-apres-${b.host}.pdf`); } catch (x) { toast(x.message); }
    });
  }
  function baPdf(a, b, d, radar, agency, col, logo) {
    const g = d.cats.find((c) => c.k === 'global');
    const bar = (v, c) => `<div style="height:8px;border-radius:8px;background:#ececf1"><div style="width:${v}%;height:8px;border-radius:8px;background:${c}"></div></div>`;
    return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Avant / après ${esc(b.host)}</title><style>@page{size:A4;margin:0}*{box-sizing:border-box}body{margin:0;font:11pt/1.5 -apple-system,'Segoe UI',Roboto,Arial,sans-serif;color:#15151a;-webkit-print-color-adjust:exact;print-color-adjust:exact}.page{width:210mm;min-height:297mm;padding:18mm;page-break-after:always;position:relative}.page:last-child{page-break-after:auto}h1{font-size:30pt;font-weight:300;margin:0 0 4mm}h2{font-size:16pt;font-weight:400;color:${col};margin:8mm 0 4mm}.k{font-size:9pt;letter-spacing:.14em;text-transform:uppercase;color:#777}.big{font-size:64pt;font-weight:200;color:${col};line-height:1;margin:6mm 0}.row{display:grid;grid-template-columns:40mm 1fr 1fr 18mm;gap:4mm;align-items:center;margin:2.5mm 0;font-size:10pt}table{width:100%;border-collapse:collapse;font-size:10pt}td,th{padding:2mm;border-bottom:1px solid #ececf1;text-align:left}li{margin:1.2mm 0}.foot{position:absolute;left:18mm;right:18mm;bottom:9mm;font-size:8pt;color:#888;display:flex;justify-content:space-between}.logo{max-height:14mm;max-width:60mm}</style></head><body>
<section class="page">${logo ? `<img class="logo" src="${esc(logo)}" alt="">` : `<div class="k">${esc(agency)}</div>`}<p class="k" style="margin-top:14mm">Rapport de progression</p><h1>${esc(b.host)}</h1><p>Du ${esc(dateFr(a.date))} au ${esc(dateFr(b.date))}</p>
<div class="big">${g.before} → ${g.after}<span style="font-size:20pt;color:#999">/100</span></div><p>${g.after >= g.before ? `Le score global progresse de <b>${g.after - g.before} points</b>.` : `Le score global recule de ${g.before - g.after} points.`} ${fmt(d.fixed.length)} problèmes ont été entièrement résolus et ${fmt(d.better.length)} sont en nette amélioration.</p>
${radar ? `<h2>Visibilité dans les IA</h2><p>${esc(radar.brand)} est cité dans <b>${String(radar.after.share).replace('.', ',')} %</b> des réponses de ChatGPT, Claude, Perplexity et Gemini, contre ${String(radar.before.share).replace('.', ',')} % au ${esc(dateFr(radar.from))}.</p>` : ''}
<h2>Scores par domaine</h2>${d.cats.filter((c) => c.k !== 'global').map((c) => `<div class="row"><span>${CAT[c.k]}</span>${bar(c.before, '#c9c9d3')}${bar(c.after, col)}<b>${c.before} → ${c.after}</b></div>`).join('')}<p style="font-size:8.5pt;color:#888">Barre grise : avant · barre colorée : après</p>
<div class="foot"><span>${esc(agency)}</span><span>${esc(b.host)}</span></div></section>
<section class="page"><h2>Problèmes résolus</h2><ul>${d.fixed.map((f) => `<li>${esc(f.title)} (${fmt(f.n)} éléments)</li>`).join('') || '<li>—</li>'}</ul>
${d.better.length ? `<h2>En amélioration</h2><ul>${d.better.map((f) => `<li>${esc(f.title)} : ${fmt(f.before)} → ${fmt(f.after)}</li>`).join('')}</ul>` : ''}
<h2>Chiffres clés</h2><table><tr><th></th><th>Avant</th><th>Après</th></tr>${d.stats.filter((s) => s.before != null).map((s) => `<tr><td>${STAT[s.k][0]}</td><td>${fmt(s.before)}</td><td>${fmt(s.after)}</td></tr>`).join('')}</table>
${d.fresh.length ? `<h2>Prochaines étapes</h2><ul>${d.fresh.slice(0, 8).map((f) => `<li>${esc(f.title)}</li>`).join('')}</ul>` : ''}
<div class="foot"><span>${esc(agency)}</span><span>${esc(b.host)}</span></div></section></body></html>`;
  }

  T.register({ id: 'refresh', label: 'Rafraîchir un article', group: 'Contenu', icon: 'M20 11a8 8 0 0 0-14.9-3.9M4 4v4h4m-4 5a8 8 0 0 0 14.9 3.9M20 20v-4h-4', open: openRefresh });
  T.register({ id: 'faqgen', label: 'FAQ réelles', group: 'Contenu', icon: 'M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3m.1 4h.01M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z', open: openFaq });
  T.register({ id: 'attack', label: 'Plan d’attaque', group: 'Analyser', icon: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zm0-4a6 6 0 1 0 0-12 6 6 0 0 0 0 12zm0-4a2 2 0 1 0 0-4 2 2 0 0 0 0 4z', open: openAttack });
  T.register({ id: 'beforeafter', label: 'Avant / après', group: 'Agence', icon: 'M3 3v18h18M7 15l4-4 3 3 6-6', open: openBeforeAfter });

  VX.growth = { staleYears, rankStale, collectQuestions, faqHtml, attackPlan, briefMd, diffReports, isQuestion };
})();
