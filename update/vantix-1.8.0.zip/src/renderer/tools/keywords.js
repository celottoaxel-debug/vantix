// VANTIX — suivi quotidien des mots-clés : positions Google jour par jour via Search Console (gratuit),
// quota selon la formule (Découverte 100, Solo 500, Pro 5 000, Agence 10 000), alertes et historique.
(function () {
  'use strict';
  const VX = window.VX, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T || !VX.plans) return;
  const P = VX.plans;
  const { $, $$, esc, toast, fmt, modal } = UI;
  const INDEX = 'kwindex', KEEP_DAYS = 120;
  const COL = { top3: '#199e70', top10: '#3987e5', top20: '#c98500', rest: '#6a6b6c' };

  // ---------- dates (Search Console compte en jours calendaires) ----------
  const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const addDays = (s, n) => { const d = new Date(s + 'T12:00:00'); d.setDate(d.getDate() + n); return ymd(d); };
  const today = () => ymd(new Date());
  const dayFr = (s) => new Date(s + 'T12:00:00').toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' });
  const norm = (k) => String(k || '').toLowerCase().normalize('NFC').replace(/\s+/g, ' ').trim();
  const pos1 = (v) => (v == null ? '–' : String(Math.round(v * 10) / 10).replace('.', ','));

  // ---------- stockage ----------
  const loadIndex = async () => (await T.load(INDEX)) || { projects: [] };
  const saveIndex = (ix) => T.save(INDEX, ix);
  const loadProj = async (id) => (await T.load('kw-' + id)) || null;
  async function saveProj(p) {
    // on ne garde que les derniers jours
    const min = addDays(today(), -KEEP_DAYS);
    for (const d of Object.keys(p.days || {})) if (d < min) delete p.days[d];
    await T.save('kw-' + p.id, p);
    const ix = await loadIndex(); const e = ix.projects.find((x) => x.id === p.id);
    const meta = { id: p.id, host: p.host, siteUrl: p.siteUrl, count: p.keywords.length, lastSync: p.lastSync || null, lastDay: p.lastDay || null };
    if (e) Object.assign(e, meta); else ix.projects.push(meta);
    await saveIndex(ix);
  }
  const usedQuota = (ix, exceptId) => ix.projects.filter((x) => x.id !== exceptId).reduce((s, x) => s + (x.count || 0), 0);

  // ---------- calculs ----------
  /** Valeurs d'un mot-clé : position actuelle, évolutions, meilleure position, série. */
  function kwStats(p) {
    const days = Object.keys(p.days || {}).sort();
    const last = days[days.length - 1] || null;
    const since28 = last ? addDays(last, -27) : null;
    return p.keywords.map((kw) => {
      const series = [];
      let clicks = 0, impr = 0;
      for (const d of days) { const v = p.days[d][kw.id]; if (v) { series.push([d, v[0]]); if (d >= since28) { clicks += v[1]; impr += v[2]; } } }
      const lastPt = series[series.length - 1];
      const cur = lastPt && last && lastPt[0] >= addDays(last, -6) ? lastPt[1] : null;
      const at = (n) => { if (!lastPt) return null; const target = addDays(lastPt[0], -n); let best = null; for (const [d, v] of series) if (d <= target) best = v; return best; };
      const prev = series.length >= 2 ? series[series.length - 2][1] : null;
      const d1 = cur != null && prev != null ? Math.round((prev - cur) * 10) / 10 : null;
      const p7 = at(7), p30 = at(30);
      return { id: kw.id, k: kw.k, added: kw.added, cur, curDay: lastPt ? lastPt[0] : null, d1, d7: cur != null && p7 != null ? Math.round((p7 - cur) * 10) / 10 : null, d30: cur != null && p30 != null ? Math.round((p30 - cur) * 10) / 10 : null, best: series.length ? Math.min(...series.map((x) => x[1])) : null, series: series.slice(-30), clicks, impr, page: (p.pages || {})[kw.k] || '' };
    });
  }
  function distribution(p, n = 60) {
    const days = Object.keys(p.days || {}).sort().slice(-n);
    return days.map((d) => { const o = { d, top3: 0, top10: 0, top20: 0, rest: 0 }; for (const v of Object.values(p.days[d])) { const x = v[0]; if (x <= 3) o.top3++; else if (x <= 10) o.top10++; else if (x <= 20) o.top20++; else o.rest++; } return o; });
  }
  /** Mouvements notables entre les deux derniers jours connus. */
  function movesOf(p) {
    const st = kwStats(p);
    const up = [], down = [], enter10 = [], leave10 = [];
    for (const s of st) {
      if (s.cur == null || s.d1 == null) continue;
      const before = s.cur + s.d1;
      if (before > 10 && s.cur <= 10) enter10.push(s); else if (before <= 10 && s.cur > 10) leave10.push(s);
      if (s.d1 >= 5) up.push(s); else if (s.d1 <= -5) down.push(s);
    }
    return { up, down, enter10, leave10 };
  }

  // ---------- synchronisation avec Search Console ----------
  async function sync(p, { log = () => {}, bar = () => {}, isStopped = () => false } = {}) {
    const tracked = new Map(p.keywords.map((k) => [k.k, k.id]));
    const end = addDays(today(), -1);
    const have = Object.keys(p.days || {}).sort();
    // un mot-clé ajouté récemment récupère aussi ses 90 derniers jours
    const backfill = p.keywords.some((k) => !k.filled);
    let start = have.length && !backfill ? addDays(p.lastDay || have[have.length - 1], -3) : addDays(end, -89);
    if (start < addDays(end, -89)) start = addDays(end, -89);
    const dates = []; for (let d = start; d <= end; d = addDays(d, 1)) dates.push(d);
    p.days = p.days || {};
    let done = 0, lastWithData = p.lastDay || null;
    const one = async (d) => {
      if (isStopped()) return;
      const r = await api.gscQuery({ siteUrl: p.siteUrl, body: { startDate: d, endDate: d, dimensions: ['query'], type: 'web', dataState: 'all' }, max: 100000 });
      if (!r.ok) throw Object.assign(new Error(r.error), { expired: r.expired });
      const day = {};
      for (const row of r.rows) { const id = tracked.get(norm(row.keys[0])); if (id) day[id] = [Math.round(row.position * 10) / 10, row.clicks, row.impressions]; }
      if (r.rows.length) { p.days[d] = Object.assign(p.days[d] || {}, day); if (!lastWithData || d > lastWithData) lastWithData = d; }
      done++; bar(done / (dates.length + 1)); log(`${dayFr(d)} : ${fmt(Object.keys(day).length)} mots-clés suivis trouvés sur ${fmt(r.rows.length)} recherches`);
    };
    for (let i = 0; i < dates.length; i += 3) await Promise.all(dates.slice(i, i + 3).map(one));
    // page qui se positionne, et suggestions de mots-clés (28 derniers jours)
    const from = addDays(end, -27);
    const rp = await api.gscQuery({ siteUrl: p.siteUrl, body: { startDate: from, endDate: end, dimensions: ['query', 'page'], type: 'web' }, max: 100000 });
    if (rp.ok) {
      const best = {}; const agg = new Map();
      for (const row of rp.rows) {
        const k = norm(row.keys[0]);
        if (tracked.has(k)) { if (!best[k] || row.impressions > best[k].i) best[k] = { u: row.keys[1], i: row.impressions }; }
        else { const a = agg.get(k) || { k, clicks: 0, impr: 0, posW: 0 }; a.clicks += row.clicks; a.impr += row.impressions; a.posW += row.position * row.impressions; agg.set(k, a); }
      }
      p.pages = Object.fromEntries(Object.entries(best).map(([k, v]) => [k, v.u]));
      p.suggestions = [...agg.values()].sort((a, b) => b.impr - a.impr).slice(0, 1000).map((a) => ({ k: a.k, clicks: a.clicks, impr: a.impr, pos: Math.round((a.posW / Math.max(1, a.impr)) * 10) / 10 }));
    }
    bar(1);
    if (!isStopped()) for (const k of p.keywords) k.filled = true;
    p.lastSync = new Date().toISOString(); p.lastDay = lastWithData;
    const mv = movesOf(p);
    const alert = { date: p.lastSync, day: p.lastDay, up: mv.up.length, down: mv.down.length, enter10: mv.enter10.map((s) => s.k).slice(0, 20), leave10: mv.leave10.map((s) => s.k).slice(0, 20), bigUp: mv.up.slice(0, 10).map((s) => [s.k, s.cur, s.d1]), bigDown: mv.down.slice(0, 10).map((s) => [s.k, s.cur, s.d1]) };
    p.alerts = [alert, ...(p.alerts || [])].slice(0, 30);
    await saveProj(p);
    return mv;
  }

  // synchronisation automatique, une fois par jour, tant que VANTIX est ouvert
  let auto = false;
  async function autoTick() {
    if (auto) return; auto = true;
    try {
      const st = await api.gscStatus().catch(() => ({})); if (!st.connected) return;
      const ix = await loadIndex();
      for (const e of ix.projects) {
        if (e.lastSync && ymd(new Date(e.lastSync)) === today()) continue;
        const p = await loadProj(e.id); if (!p || !p.keywords.length) continue;
        try {
          const mv = await sync(p);
          const parts = [];
          if (mv.enter10.length) parts.push(`${mv.enter10.length} entre${mv.enter10.length > 1 ? 'nt' : ''} dans le top 10`);
          if (mv.leave10.length) parts.push(`${mv.leave10.length} sor${mv.leave10.length > 1 ? 'tent' : 't'} du top 10`);
          if (mv.up.length) parts.push(`${mv.up.length} en forte hausse`);
          if (mv.down.length) parts.push(`${mv.down.length} en forte baisse`);
          if (parts.length) api.notify(`VANTIX · mots-clés de ${p.host}`, parts.join(' · '));
        } catch (x) { if (x.expired) api.notify('VANTIX', 'La connexion à la Search Console a expiré : reconnectez-la dans « Suivi des mots-clés ».'); }
      }
    } finally { auto = false; }
  }
  setTimeout(() => autoTick().catch(() => {}), 60 * 1000);
  setInterval(() => autoTick().catch(() => {}), 30 * 60 * 1000);

  // =====================================================================================
  // INTERFACE
  // =====================================================================================
  let root = null;
  async function open(el) { root = el; await P.ready; const st = await api.gscStatus().catch(() => ({})); if (!st.configured) return setup(el); if (!st.connected) return connect(el, st); home(el); }

  function quotaBar(used, plan) {
    const pct = Math.min(100, (used / plan.keywords) * 100);
    return `<div class="quota"><div class="qtop"><span><b>${fmt(used)}</b> / ${fmt(plan.keywords)} mots-clés suivis chaque jour</span>${P.picker('kwPlan')}</div><div class="bar"><i style="width:${pct}%"></i></div></div>`;
  }
  function bindPlan(el, again) { const s = $('#kwPlan', el); if (s) s.addEventListener('change', () => { P.set(s.value); toast('Formule ' + P.get().name); again(); }); }

  function setup(el) {
    el.innerHTML = `<div class="radar"><span class="label">Suivi des mots-clés</span><h1>Vos positions Google, chaque jour</h1>
      <p class="lede">VANTIX relève chaque jour la position de vos mots-clés dans Google, directement depuis votre Search Console. Gratuit, et ce sont les vraies données de Google.</p>
      <div class="sec words"><div class="card"><h3>Une seule fois : créer l’accès Google de VANTIX</h3><ol class="steps2">
        <li>Ouvrez <b>console.cloud.google.com</b>, créez un projet « VANTIX ».</li>
        <li>Menu <b>API et services → Bibliothèque</b> : activez <b>Google Search Console API</b>.</li>
        <li><b>Écran de consentement OAuth</b> : type « Externe », nom « VANTIX », votre e-mail ; ajoutez le champ d’application <b>webmasters.readonly</b>, puis votre adresse dans les utilisateurs test (ou publiez l’application).</li>
        <li><b>Identifiants → Créer → ID client OAuth</b>, type <b>Application de bureau</b>.</li>
        <li>Copiez l’ID client et le code secret ci-contre.</li></ol>
        <p class="muted" style="font-size:13px">Pour que tous vos clients en profitent sans rien faire, l’ID client pourra ensuite être livré avec l’application.</p></div>
      <div class="card"><h3>Identifiants Google</h3><form id="kwCfg" class="rform" style="padding:0;background:none;box-shadow:none" novalidate>
        <label class="opt"><span>ID client</span><input class="field" id="kwId" placeholder="123…apps.googleusercontent.com" spellcheck="false" autocomplete="off"></label>
        <label class="opt"><span>Code secret du client</span><input class="field" id="kwSecret" type="password" placeholder="GOCSPX-…" autocomplete="off" spellcheck="false"></label>
        <p class="err" id="kwErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Enregistrer</button></div>
        <p class="muted" style="font-size:12px">Chiffrés par votre système, ils ne quittent jamais votre ordinateur.</p></form></div></div></div>`;
    $('#kwCfg', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      try { await api.gscSetClient({ clientId: $('#kwId', el).value, clientSecret: $('#kwSecret', el).value }); toast('Identifiants enregistrés'); open(el); } catch (x) { $('#kwErr', el).textContent = String(x.message || x).replace(/^Error invoking remote method[^:]*: (Error: )?/, ''); }
    });
  }
  function connect(el, st) {
    el.innerHTML = `<div class="radar"><span class="label">Suivi des mots-clés</span><h1>Reliez votre Search Console</h1>
      <p class="lede">Un clic : Google vous demande l’autorisation de lire vos statistiques (lecture seule), puis VANTIX relève vos positions chaque jour.</p>
      <div class="toolbar"><button class="btn" id="kwConn" type="button">Connecter ma Search Console</button>${st.bundled ? '' : '<button class="ghostbtn" id="kwReset" type="button">Changer les identifiants Google</button>'}</div><p class="err" id="kwErr"></p></div>`;
    $('#kwConn', el).addEventListener('click', async () => {
      const b = $('#kwConn', el); b.disabled = true; b.textContent = 'Terminez la connexion dans votre navigateur…';
      try { await api.gscConnect(); toast('Search Console connectée'); open(el); } catch (x) { $('#kwErr', el).textContent = String(x.message || x).replace(/^Error invoking remote method[^:]*: (Error: )?/, ''); b.disabled = false; b.textContent = 'Connecter ma Search Console'; }
    });
    const r = $('#kwReset', el); if (r) r.addEventListener('click', async () => { await api.gscSetClient({ clientId: '' }); open(el); });
  }

  async function home(el) {
    const ix = await loadIndex(), plan = P.get();
    const used = usedQuota(ix);
    el.innerHTML = `<div class="radar"><span class="label">Suivi des mots-clés</span><h1>Vos positions Google, chaque jour</h1>
      <p class="lede">Positions relevées chaque jour dans votre Search Console. Les données de Google arrivent avec 2 à 3 jours de décalage ; un mot-clé apparaît dès que votre site est affiché pour cette recherche.</p>
      ${quotaBar(used, plan)}
      <div class="sec"><div class="rhead2"><h2>Sites suivis <small>${fmt(ix.projects.length)} / ${fmt(plan.sites)}</small></h2><div class="toolbar" style="margin:0"><button class="btn" id="kwNew" type="button">Suivre un site</button><button class="ghostbtn" id="kwOut" type="button">Déconnecter Google</button></div></div>
      ${ix.projects.length ? `<div class="cards">${ix.projects.map((p) => `<button class="rcard" data-kp="${esc(p.id)}"><b>${esc(p.host)}</b><div class="row"><span>${fmt(p.count)} mots-clés</span></div><span class="muted" style="font-size:12px">${p.lastSync ? 'Relevé le ' + new Date(p.lastSync).toLocaleString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) + (p.lastDay ? ' · données du ' + dayFr(p.lastDay) : '') : 'Jamais relevé'}</span></button>`).join('')}</div>` : '<p class="empty">Choisissez un site de votre Search Console pour commencer.</p>'}</div></div>`;
    bindPlan(el, () => home(el));
    $$('[data-kp]', el).forEach((b) => b.addEventListener('click', () => project(el, b.dataset.kp)));
    $('#kwOut', el).addEventListener('click', async () => { await api.gscDisconnect(); toast('Search Console déconnectée'); open(el); });
    $('#kwNew', el).addEventListener('click', async () => {
      if (ix.projects.length >= plan.sites) { toast(`Votre formule ${plan.name} comprend ${plan.sites} site${plan.sites > 1 ? 's' : ''}.`); return; }
      const r = await api.gscSites();
      if (!r.ok) { toast(r.error); if (r.expired) open(el); return; }
      const free = r.sites.filter((s) => !ix.projects.some((p) => p.siteUrl === s.siteUrl));
      modal(`<h2>Quel site suivre ?</h2>${free.length ? `<label class="opt"><span>Propriété Search Console</span><select class="field" id="kwSite">${free.map((s) => `<option value="${esc(s.siteUrl)}">${esc(s.siteUrl.replace(/^sc-domain:/, 'domaine : '))}</option>`).join('')}</select></label><div class="toolbar" style="margin-top:14px"><button class="btn" id="kwAdd" type="button">Suivre ce site</button><button class="ghostbtn" data-close type="button">Annuler</button></div>` : '<p>Aucun autre site dans votre Search Console. Ajoutez-y votre site puis revenez.</p><div class="toolbar"><button class="ghostbtn" data-close type="button">Fermer</button></div>'}`, (m, close) => {
        const b = $('#kwAdd', m); if (!b) return;
        b.addEventListener('click', async () => {
          const siteUrl = $('#kwSite', m).value;
          const host = siteUrl.replace(/^sc-domain:/, '').replace(/^https?:\/\//, '').replace(/\/$/, '').replace(/^www\./, '');
          const p = { id: 'k' + Date.now().toString(36), siteUrl, host, keywords: [], days: {}, created: new Date().toISOString(), seq: 0 };
          await saveProj(p); close(); project(el, p.id, { suggest: true });
        });
      });
    });
  }

  // ---------- tableau de bord d'un site ----------
  const state = { filter: 'all', q: '', sort: 'cur', dir: 1, limit: 300 };
  async function project(el, id, opts = {}) {
    const p = await loadProj(id); if (!p) return home(el);
    const plan = P.get(), ix = await loadIndex();
    const st = kwStats(p);
    const withPos = st.filter((s) => s.cur != null);
    const avg = withPos.length ? withPos.reduce((s, x) => s + x.cur, 0) / withPos.length : null;
    const dist = distribution(p);
    const alert = (p.alerts || [])[0];
    el.innerHTML = `<div class="radar"><span class="label">Suivi des mots-clés</span><div class="rhead2"><h1>${esc(p.host)}</h1><div class="toolbar" style="margin:0"><button class="ghostbtn" id="kwBack" type="button">Tous les sites</button></div></div>
      <p class="muted">${p.lastSync ? `Relevé le ${new Date(p.lastSync).toLocaleString('fr-FR', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}${p.lastDay ? ` · dernières données Google : ${dayFr(p.lastDay)}` : ''} · relevé automatique chaque jour` : 'Pas encore relevé.'}</p>
      ${quotaBar(usedQuota(ix), plan)}
      <div class="toolbar"><button class="btn" id="kwAddK" type="button">Ajouter des mots-clés</button><button class="ghostbtn" id="kwSug" type="button">Suggestions</button><button class="ghostbtn" id="kwSync" type="button">Actualiser</button><button class="ghostbtn" id="kwCsv" type="button">Exporter</button><button class="ghostbtn" id="kwDel" type="button">Arrêter le suivi</button></div>
      <div id="kwRun"></div>
      ${p.keywords.length ? `<div class="tiles"><div class="tile"><b>${fmt(p.keywords.length)}</b><span>mots-clés suivis</span></div><div class="tile"><b>${pos1(avg)}</b><span>position moyenne</span></div><div class="tile good"><b>${fmt(withPos.filter((s) => s.cur <= 3).length)}</b><span>dans le top 3</span></div><div class="tile"><b>${fmt(withPos.filter((s) => s.cur <= 10).length)}</b><span>en première page</span></div><div class="tile good"><b>${fmt(st.filter((s) => s.d7 > 0).length)}</b><span>en hausse sur 7 jours</span></div><div class="tile bad"><b>${fmt(st.filter((s) => s.d7 < 0).length)}</b><span>en baisse sur 7 jours</span></div></div>
      ${alert && (alert.enter10.length || alert.leave10.length || alert.bigUp.length || alert.bigDown.length) ? `<div class="sec"><h2>Ce qui a bougé <small>${alert.day ? dayFr(alert.day) : ''}</small></h2><div class="chips">${alert.enter10.slice(0, 8).map((k) => `<span class="kchip" style="color:var(--ok)">↑ top 10 : ${esc(k)}</span>`).join('')}${alert.leave10.slice(0, 8).map((k) => `<span class="kchip" style="color:var(--crit)">↓ sort du top 10 : ${esc(k)}</span>`).join('')}${alert.bigUp.slice(0, 6).map(([k, c, d]) => `<span class="kchip" style="color:var(--ok)">${esc(k)} +${pos1(d)}</span>`).join('')}${alert.bigDown.slice(0, 6).map(([k, c, d]) => `<span class="kchip" style="color:var(--crit)">${esc(k)} ${pos1(d)}</span>`).join('')}</div></div>` : ''}
      ${dist.length > 1 ? `<div class="sec"><h2>Répartition des positions</h2><div class="card">${distChart(dist)}</div></div>` : ''}
      <div class="sec"><div class="chips" id="kwFilters">${[['all', 'Tous'], ['top3', 'Top 3'], ['top10', 'Top 10'], ['near', 'Positions 4 à 20'], ['up', 'En hausse'], ['down', 'En baisse'], ['none', 'Sans affichage']].map(([k, l]) => `<button class="kchip ${state.filter === k ? 'on' : ''}" type="button" data-f="${k}">${l}</button>`).join('')}<input class="field" id="kwSearch" placeholder="Chercher un mot-clé" value="${esc(state.q)}" style="max-width:260px;margin-left:auto"></div><div id="kwTable"></div></div>`
      : '<div class="sec"><p class="empty">Ajoutez vos mots-clés, ou choisissez-les parmi les recherches pour lesquelles Google affiche déjà votre site (Suggestions).</p></div>'}</div>`;
    $('#kwBack', el).addEventListener('click', () => home(el));
    bindPlan(el, () => project(el, id));
    $('#kwAddK', el).addEventListener('click', () => addModal(el, p));
    $('#kwSug', el).addEventListener('click', () => suggestModal(el, p));
    $('#kwSync', el).addEventListener('click', () => runSync(el, p));
    $('#kwCsv', el).addEventListener('click', () => exportCsv(p, st));
    $('#kwDel', el).addEventListener('click', () => modal(`<h2>Arrêter le suivi de ${esc(p.host)} ?</h2><p>L’historique des positions de ce site sera effacé de VANTIX (vos données Search Console ne sont pas touchées).</p><div class="toolbar"><button class="btn" id="kwDelOk" type="button">Arrêter le suivi</button><button class="ghostbtn" data-close type="button">Annuler</button></div>`, (m, close) => $('#kwDelOk', m).addEventListener('click', async () => { await T.save('kw-' + p.id, null); const ix2 = await loadIndex(); ix2.projects = ix2.projects.filter((x) => x.id !== p.id); await saveIndex(ix2); close(); home(el); })));
    if (p.keywords.length) {
      $$('[data-f]', el).forEach((b) => b.addEventListener('click', () => { state.filter = b.dataset.f; state.limit = 300; $$('[data-f]', el).forEach((x) => x.classList.toggle('on', x === b)); table(el, p, st); }));
      $('#kwSearch', el).addEventListener('input', (e) => { state.q = e.target.value; state.limit = 300; table(el, p, st); });
      table(el, p, st);
    }
    if (opts.suggest && !p.keywords.length) runSync(el, p, () => suggestModal(el, p));
  }

  function distChart(dist) {
    const W = 900, H = 190, pad = 28, bw = (W - pad) / dist.length;
    const max = Math.max(1, ...dist.map((d) => d.top3 + d.top10 + d.top20 + d.rest));
    const y = (v) => H - 22 - (v / max) * (H - 40);
    const bars = dist.map((d, i) => { let acc = 0; return ['rest', 'top20', 'top10', 'top3'].map((k) => { const h = (d[k] / max) * (H - 40); const r = `<rect x="${(pad + i * bw + 1).toFixed(1)}" y="${(H - 22 - acc - h).toFixed(1)}" width="${Math.max(1, bw - 2).toFixed(1)}" height="${h.toFixed(1)}" fill="${COL[k]}"><title>${dayFr(d.d)} · ${d[k]} ${k === 'top3' ? 'dans le top 3' : k === 'top10' ? 'en positions 4 à 10' : k === 'top20' ? 'en positions 11 à 20' : 'au-delà'}</title></rect>`; acc += h; return r; }).join(''); }).join('');
    const ticks = dist.filter((_, i) => i % Math.ceil(dist.length / 6) === 0).map((d) => `<text x="${(pad + dist.indexOf(d) * bw).toFixed(1)}" y="${H - 6}" fill="var(--text-3)" font-size="11" font-family="var(--mono)">${dayFr(d.d)}</text>`).join('');
    return `<div class="legend">${[['top3', 'Top 3'], ['top10', '4 à 10'], ['top20', '11 à 20'], ['rest', 'Au-delà']].map(([k, l]) => `<span><i style="background:${COL[k]}"></i>${l}</span>`).join('')}</div><svg viewBox="0 0 ${W} ${H}" class="kwchart" role="img" aria-label="Nombre de mots-clés par tranche de position, jour par jour"><line x1="${pad}" x2="${W}" y1="${y(max)}" y2="${y(max)}" stroke="var(--line)"/><text x="0" y="${y(max) + 4}" fill="var(--text-3)" font-size="11" font-family="var(--mono)">${max}</text>${bars}${ticks}</svg>`;
  }
  function spark(series) {
    if (series.length < 2) return '';
    const W = 90, H = 24, xs = series.map((_, i) => (i / (series.length - 1)) * W);
    const vals = series.map((s) => s[1]); const mn = Math.min(...vals), mx = Math.max(...vals), span = Math.max(1, mx - mn);
    const pts = vals.map((v, i) => `${xs[i].toFixed(1)},${(2 + ((v - mn) / span) * (H - 4)).toFixed(1)}`).join(' ');
    const up = vals[vals.length - 1] <= vals[0];
    return `<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" aria-hidden="true"><polyline points="${pts}" fill="none" stroke="${up ? 'var(--ok)' : 'var(--crit)'}" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
  }
  const delta = (v) => (v == null ? '<span class="muted">–</span>' : v > 0 ? `<span style="color:var(--ok)">+${pos1(v)}</span>` : v < 0 ? `<span style="color:var(--crit)">${pos1(v)}</span>` : '<span class="muted">=</span>');
  function table(el, p, st) {
    const F = { all: () => true, top3: (s) => s.cur != null && s.cur <= 3, top10: (s) => s.cur != null && s.cur <= 10, near: (s) => s.cur != null && s.cur > 3 && s.cur <= 20, up: (s) => s.d7 > 0, down: (s) => s.d7 < 0, none: (s) => s.cur == null };
    const q = norm(state.q);
    const rows = st.filter(F[state.filter]).filter((s) => !q || s.k.includes(q));
    const key = state.sort, dir = state.dir;
    rows.sort((a, b) => { const va = a[key], vb = b[key]; if (va == null && vb == null) return a.k.localeCompare(b.k); if (va == null) return 1; if (vb == null) return -1; return typeof va === 'string' ? va.localeCompare(vb) * dir : (va - vb) * dir; });
    const H = [['k', 'Mot-clé'], ['cur', 'Position'], ['d1', '1 j'], ['d7', '7 j'], ['d30', '30 j'], ['best', 'Meilleure'], [null, '30 derniers jours'], ['clicks', 'Clics 28 j'], ['impr', 'Affichages 28 j'], [null, 'Page']];
    $('#kwTable', el).innerHTML = rows.length ? `<div class="tablewrap" style="max-height:none"><table class="kwtable"><thead><tr>${H.map(([k, l]) => `<th>${k ? `<button class="sortbtn" type="button" data-s="${k}">${l}${state.sort === k ? (dir > 0 ? ' ↑' : ' ↓') : ''}</button>` : l}</th>`).join('')}<th></th></tr></thead><tbody>
      ${rows.slice(0, state.limit).map((s) => `<tr><td><button class="linkbtn plain" type="button" data-kw="${esc(s.id)}">${esc(s.k)}</button></td><td class="num"><b>${pos1(s.cur)}</b></td><td class="num">${delta(s.d1)}</td><td class="num">${delta(s.d7)}</td><td class="num">${delta(s.d30)}</td><td class="num">${pos1(s.best)}</td><td>${spark(s.series)}</td><td class="num">${fmt(s.clicks)}</td><td class="num">${fmt(s.impr)}</td><td class="pagecell">${s.page ? esc(s.page.replace(/^https?:\/\/[^/]+/, '') || '/') : ''}</td><td><button class="iconbtn" type="button" data-rm="${esc(s.id)}" aria-label="Retirer ${esc(s.k)}">×</button></td></tr>`).join('')}</tbody></table></div>
      ${rows.length > state.limit ? `<div class="toolbar" style="margin-top:12px"><button class="ghostbtn" id="kwMore" type="button">Afficher ${fmt(Math.min(500, rows.length - state.limit))} de plus (${fmt(rows.length - state.limit)} restants)</button></div>` : ''}`
      : '<p class="empty">Aucun mot-clé ne correspond.</p>';
    $$('[data-s]', el).forEach((b) => b.addEventListener('click', () => { const k = b.dataset.s; if (state.sort === k) state.dir = -state.dir; else { state.sort = k; state.dir = k === 'clicks' || k === 'impr' || k === 'd1' || k === 'd7' || k === 'd30' ? -1 : 1; } table(el, p, st); }));
    const more = $('#kwMore', el); if (more) more.addEventListener('click', () => { state.limit += 500; table(el, p, st); });
    $$('[data-kw]', el).forEach((b) => b.addEventListener('click', () => detail(p, st.find((s) => s.id === b.dataset.kw))));
    $$('[data-rm]', el).forEach((b) => b.addEventListener('click', async () => { p.keywords = p.keywords.filter((k) => k.id !== b.dataset.rm); for (const d of Object.values(p.days)) delete d[b.dataset.rm]; await saveProj(p); project(el, p.id); }));
  }
  function detail(p, s) {
    const days = Object.keys(p.days).sort();
    const pts = days.map((d) => [d, (p.days[d][s.id] || [])[0]]).filter((x) => x[1] != null);
    const W = 640, H = 220, pad = 34;
    const mx = Math.max(10, ...pts.map((x) => x[1])), x = (i) => pad + (i / Math.max(1, pts.length - 1)) * (W - pad - 8), y = (v) => 12 + ((v - 1) / (mx - 1)) * (H - 40);
    const grid = [1, 3, 10, 20, 50, 100].filter((v) => v <= mx).map((v) => `<line x1="${pad}" x2="${W}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)"/><text x="0" y="${y(v) + 4}" fill="var(--text-3)" font-size="11" font-family="var(--mono)">${v}</text>`).join('');
    modal(`<h2>${esc(s.k)}</h2><p class="muted">Position ${pos1(s.cur)} · meilleure ${pos1(s.best)} · ${fmt(s.clicks)} clics et ${fmt(s.impr)} affichages sur 28 jours${s.page ? ' · ' + esc(s.page) : ''}</p>
      ${pts.length > 1 ? `<svg viewBox="0 0 ${W} ${H}" class="kwchart" role="img" aria-label="Position jour par jour (plus haut = mieux)">${grid}<polyline points="${pts.map((pt, i) => `${x(i).toFixed(1)},${y(pt[1]).toFixed(1)}`).join(' ')}" fill="none" stroke="var(--info)" stroke-width="2" stroke-linejoin="round"/>${pts.map((pt, i) => `<circle cx="${x(i).toFixed(1)}" cy="${y(pt[1]).toFixed(1)}" r="5" fill="transparent"><title>${dayFr(pt[0])} : position ${pos1(pt[1])}</title></circle>`).join('')}<text x="${pad}" y="${H - 4}" fill="var(--text-3)" font-size="11" font-family="var(--mono)">${dayFr(pts[0][0])}</text><text x="${W}" y="${H - 4}" fill="var(--text-3)" font-size="11" font-family="var(--mono)" text-anchor="end">${dayFr(pts[pts.length - 1][0])}</text></svg>` : '<p class="empty">Pas encore assez de jours avec des affichages pour tracer une courbe.</p>'}
      <div class="toolbar"><button class="ghostbtn" data-close type="button">Fermer</button></div>`);
  }
  async function addKeywords(p, list) {
    const ix = await loadIndex(), plan = P.get();
    const room = plan.keywords - usedQuota(ix, p.id) - p.keywords.length;
    const have = new Set(p.keywords.map((k) => k.k));
    const fresh = [...new Set(list.map(norm).filter((k) => k && k.length <= 200 && !have.has(k)))];
    const take = fresh.slice(0, Math.max(0, room));
    p.seq = p.seq || p.keywords.length;
    for (const k of take) p.keywords.push({ id: (p.seq++).toString(36), k, added: today() });
    await saveProj(p);
    return { added: take.length, refused: fresh.length - take.length, plan };
  }
  function addModal(el, p) {
    loadIndex().then((ix) => {
      const plan = P.get(), room = plan.keywords - usedQuota(ix, p.id) - p.keywords.length;
      modal(`<h2>Ajouter des mots-clés</h2><p class="muted">Un par ligne. Il vous reste <b>${fmt(Math.max(0, room))}</b> mots-clés dans la formule ${esc(plan.name)}.</p><textarea class="field" id="kwList" rows="10" placeholder="que faire à lisbonne&#10;week-end à porto pas cher&#10;application voyage"></textarea><p class="muted" id="kwCount" style="font-size:13px"></p><div class="toolbar"><button class="btn" id="kwSave" type="button">Ajouter</button><button class="ghostbtn" data-close type="button">Annuler</button></div>`, (m, close) => {
        const ta = $('#kwList', m), count = () => { const n = new Set(ta.value.split('\n').map(norm).filter(Boolean)).size; $('#kwCount', m).textContent = n ? `${fmt(n)} mot${n > 1 ? 's' : ''}-clé${n > 1 ? 's' : ''}${n > room ? ` : seuls les ${fmt(Math.max(0, room))} premiers seront ajoutés` : ''}` : ''; };
        ta.addEventListener('input', count);
        $('#kwSave', m).addEventListener('click', async () => {
          const r = await addKeywords(p, ta.value.split('\n')); close();
          toast(`${fmt(r.added)} mot${r.added > 1 ? 's' : ''}-clé${r.added > 1 ? 's' : ''} ajouté${r.added > 1 ? 's' : ''}${r.refused ? ` · ${fmt(r.refused)} au-delà du quota ${r.plan.name}` : ''}`);
          runSync(el, p);
        });
      });
    });
  }
  function suggestModal(el, p) {
    const sug = (p.suggestions || []).filter((s) => !p.keywords.some((k) => k.k === s.k));
    if (!sug.length) { toast(p.lastSync ? 'Aucune suggestion : Google n’affiche pas encore votre site pour d’autres recherches.' : 'Actualisez d’abord pour récupérer les suggestions.'); return; }
    loadIndex().then((ix) => {
      const plan = P.get(), room = Math.max(0, plan.keywords - usedQuota(ix, p.id) - p.keywords.length);
      const pre = Math.min(room, 50);
      modal(`<h2>Suggestions de la Search Console</h2><p class="muted">Les recherches pour lesquelles Google affiche déjà votre site (28 derniers jours). Il vous reste ${fmt(room)} mots-clés.</p>
        <div class="toolbar"><button class="ghostbtn" id="sgTop" type="button">Cocher les ${fmt(Math.min(room, sug.length, 100))} premières</button><button class="ghostbtn" id="sgNone" type="button">Tout décocher</button></div>
        <div class="tablewrap" style="max-height:52vh"><table><thead><tr><th></th><th>Recherche</th><th>Affichages</th><th>Clics</th><th>Position</th></tr></thead><tbody>${sug.slice(0, 1000).map((s, i) => `<tr><td><input type="checkbox" data-sg="${i}" ${i < pre ? 'checked' : ''}></td><td>${esc(s.k)}</td><td class="num">${fmt(s.impr)}</td><td class="num">${fmt(s.clicks)}</td><td class="num">${pos1(s.pos)}</td></tr>`).join('')}</tbody></table></div>
        <div class="toolbar" style="margin-top:12px"><button class="btn" id="sgAdd" type="button">Suivre la sélection</button><button class="ghostbtn" data-close type="button">Fermer</button></div>`, (m, close) => {
        $('#sgTop', m).addEventListener('click', () => $$('[data-sg]', m).forEach((c, i) => { c.checked = i < Math.min(room, 100); }));
        $('#sgNone', m).addEventListener('click', () => $$('[data-sg]', m).forEach((c) => { c.checked = false; }));
        $('#sgAdd', m).addEventListener('click', async () => {
          const picked = $$('[data-sg]', m).filter((c) => c.checked).map((c) => sug[+c.dataset.sg].k);
          const r = await addKeywords(p, picked); close();
          toast(`${fmt(r.added)} ajouté${r.added > 1 ? 's' : ''}${r.refused ? ` · ${fmt(r.refused)} au-delà du quota ${r.plan.name}` : ''}`);
          runSync(el, p);
        });
      });
    });
  }
  async function runSync(el, p, then) {
    const box = $('#kwRun', el); if (!box) return;
    const btn = $('#kwSync', el); if (btn) btn.disabled = true;
    const pg = T.progress(box, 'Relevé des positions'); pg.title(p.host);
    try { await sync(p, { log: pg.log, bar: pg.bar, isStopped: () => pg.stopped }); toast('Positions à jour'); if (root === el) project(el, p.id); if (then) then(); }
    catch (x) { box.innerHTML = `<div class="card"><p class="err">${esc(x.message)}</p></div>`; if (x.expired) setTimeout(() => open(el), 1500); }
    finally { if (btn) btn.disabled = false; }
  }
  function exportCsv(p, st) {
    const cell = (v) => { const s = v == null ? '' : String(v); return /[";\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    const days = Object.keys(p.days).sort().slice(-30);
    const rows = [['Mot-clé', 'Position', 'Évolution 1 j', 'Évolution 7 j', 'Évolution 30 j', 'Meilleure', 'Clics 28 j', 'Affichages 28 j', 'Page', ...days], ...st.map((s) => [s.k, s.cur, s.d1, s.d7, s.d30, s.best, s.clicks, s.impr, s.page, ...days.map((d) => (p.days[d][s.id] || [])[0])])];
    api.exportFile({ defaultName: `positions-${p.host}-${today()}.csv`, content: '﻿' + rows.map((r) => r.map((v) => cell(typeof v === 'number' ? String(v).replace('.', ',') : v)).join(';')).join('\r\n'), filters: [{ name: 'CSV', extensions: ['csv'] }] }).catch((x) => toast(x.message));
  }

  T.register({ id: 'keywords', label: 'Suivi des mots-clés', group: 'Analyser', icon: 'M3 17l6-6 4 4 8-8M15 7h6v6', open });
  VX.keywords = { kwStats, distribution, movesOf, norm, loadIndex, loadProj, addDays, ymd };
})();
