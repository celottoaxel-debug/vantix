// VANTIX — consignes du jour : chaque matin, les actions les plus utiles, tirées de vos analyses, de vos mots-clés
// et du Radar IA. Leur nombre dépend de la formule (Découverte 1, Solo 3, Pro 10, Agence 30). Tout est calculé ici, gratuitement.
(function () {
  'use strict';
  const VX = window.VX, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T || !VX.plans) return;
  const P = VX.plans;
  const { $, $$, esc, toast, fmt } = UI;
  const STORE = 'daily';
  const ymd = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const today = () => ymd(new Date());
  const ago = (iso) => (Date.now() - new Date(iso).getTime()) / 86400000;
  const hostOf = (u) => { try { return new URL(/^https?:/i.test(u) ? u : 'https://' + u).host.replace(/^www\./, ''); } catch { return String(u || '').replace(/^www\./, ''); } };
  const SEVW = { critique: 30, important: 18, mineur: 8 };
  const TYPE = { fix: 'Correction', keyword: 'Mot-clé', drop: 'Alerte', ia: 'Visibilité IA', content: 'Contenu', audit: 'Analyse' };

  /** Toutes les actions possibles aujourd'hui, avec un poids (plus il est haut, plus c'est utile). */
  async function candidates() {
    const out = [];
    const add = (c) => out.push(c);
    // 1. analyses : les problèmes les plus graves de chaque site
    const reps = await api.listReports().catch(() => []);
    const latest = new Map(); for (const r of reps) if (!latest.has(r.host)) latest.set(r.host, r);
    for (const meta of latest.values()) {
      if (ago(meta.date) > 14) add({ key: 'audit:' + meta.host + ':' + today().slice(0, 7), type: 'audit', site: meta.host, w: 22, title: `Relancer l’analyse de ${meta.host}`, how: `La dernière date d’il y a ${Math.round(ago(meta.date))} jours : relancez-la pour voir l’effet de vos corrections et repérer les nouveaux problèmes.`, act: { kind: 'new', url: 'https://' + meta.host } });
      let r; try { r = await api.loadReport(meta.id); } catch { continue; }
      for (const i of (r.issues || []).filter((x) => SEVW[x.sev])) {
        add({ key: `issue:${meta.host}:${i.id}`, type: 'fix', site: meta.host, w: SEVW[i.sev] + Math.min(12, i.items.length), title: `${i.title} (${fmt(i.items.length)})`, how: i.fix, why: i.why, example: (i.items[0] || {}).url || '', act: { kind: 'report', id: meta.id } });
      }
    }
    if (!latest.size) add({ key: 'first-audit', type: 'audit', site: '', w: 60, title: 'Lancer la première analyse de votre site', how: 'Indiquez l’adresse de votre site : VANTIX vérifie le SEO, la visibilité dans les IA et prépare les corrections.', act: { kind: 'new' } });
    // 2. mots-clés : ceux à portée du haut de Google, et les chutes
    if (VX.keywords) {
      const K = VX.keywords; const ix = await K.loadIndex();
      for (const e of ix.projects) {
        const p = await K.loadProj(e.id); if (!p) continue;
        for (const s of K.kwStats(p)) {
          if (s.cur == null) continue;
          if (s.d7 != null && s.d7 <= -5) add({ key: `drop:${e.id}:${s.id}:${s.curDay}`, type: 'drop', site: p.host, w: 34 + Math.min(10, s.impr / 100), title: `« ${s.k} » a perdu ${String(-s.d7).replace('.', ',')} places en 7 jours`, how: `Position ${String(s.cur).replace('.', ',')} aujourd’hui. Vérifiez la page${s.page ? ' ' + s.page : ''} : contenu modifié, page plus lente, ou concurrent plus complet ? Mettez-la à jour (outil Rafraîchir un article).`, act: { kind: 'tool', id: 'refresh', url: s.page } });
          else if (s.cur > 3 && s.cur <= 15 && s.impr >= 20) add({ key: `kw:${e.id}:${s.id}:${Math.round(s.cur)}`, type: 'keyword', site: p.host, w: 20 + Math.min(20, s.impr / 50) + (s.cur <= 10 ? 4 : 0), title: `Faire monter « ${s.k} » (position ${String(s.cur).replace('.', ',')}) dans le top 3`, how: `${fmt(s.impr)} affichages en 28 jours : chaque place gagnée apporte des visites. Sur ${s.page || 'la page concernée'}, reprenez la recherche exacte dans le titre et un intertitre, répondez-y dès le premier paragraphe et ajoutez un lien depuis 2 de vos pages proches.`, act: { kind: 'tool', id: 'optimizer' } });
        }
      }
    }
    // 3. Radar IA : sources à conquérir, recommandations perdues, erreurs des IA
    let radars = []; try { radars = await api.radarList(); } catch {}
    if (!radars.length) add({ key: 'radar-create', type: 'ia', site: '', w: 26, title: 'Créer votre Radar IA', how: 'Découvrez si ChatGPT, Claude, Perplexity et Gemini recommandent votre marque, et face à quels concurrents.', act: { kind: 'radar' } });
    for (const meta of radars.slice(0, 25)) {
      let p; try { p = await api.radarLoad(meta.id); } catch { continue; }
      const run = [...(p.runs || [])].reverse().find((x) => x.summary); if (!run) continue;
      for (const o of (run.summary.opportunities || []).slice(0, 6)) add({ key: `src:${p.id}:${o.domain}`, type: 'ia', site: hostOf(p.site), w: 16 + Math.min(14, o.opportunity), title: `Être cité sur ${o.domain}`, how: `Les IA s’appuient sur ce site pour répondre à vos clients, sans vous citer. Ouvrez « Où être cité » : le message à envoyer est prêt.`, act: { kind: 'tool', id: 'aisources' } });
      if (ago(run.date) > 10) add({ key: `radar-run:${p.id}:${today().slice(0, 7)}`, type: 'ia', site: hostOf(p.site), w: 18, title: `Relancer le Radar IA de ${p.brand}`, how: 'Le dernier passage date de plus de 10 jours : voyez si les IA vous recommandent davantage.', act: { kind: 'radar' } });
    }
    const facts = await T.load('brandfacts');
    if (facts) for (const c of (facts.claims || []).filter((x) => x.verdict === 'faux' && x.gravite === 'grave').slice(0, 5)) add({ key: `fact:${facts.host}:${c.claim}`.slice(0, 200), type: 'ia', site: facts.host, w: 32, title: `Corriger ce que l’IA dit de faux : « ${c.claim} »`, how: `${c.truth ? 'Sur votre site : ' + c.truth + '. ' : ''}Publiez la page « faits officiels » préparée par l’outil Erreurs des IA et ajoutez le bloc à votre llms.txt.`, act: { kind: 'tool', id: 'brandfacts' } });
    // 4. contenu : articles à rafraîchir, questions sans réponse
    const ref = await T.load('refresh');
    if (ref) for (const pg of (ref.list || []).slice(0, 8)) add({ key: `refresh:${pg.url}`, type: 'content', site: hostOf(pg.url), w: 12 + Math.min(14, pg.score / 4), title: `Rafraîchir « ${pg.h1 || pg.title || pg.url} »`, how: pg.reasons.join(' · ') + '. L’outil Rafraîchir un article rédige la mise à jour.', act: { kind: 'tool', id: 'refresh', url: pg.url } });
    const gsc = await T.load('gsc');
    if (gsc && gsc.data && VX.gsc) { const a = VX.gsc.analyze(gsc.data); for (const q of a.questions.slice(0, 6)) add({ key: `q:${q.key}`, type: 'content', site: '', w: 12 + Math.min(10, q.impressions / 100), title: `Répondre à « ${q.key} »`, how: `${fmt(q.impressions)} affichages sur Google pour cette question : ajoutez-la à la FAQ de la page concernée (outil FAQ réelles), avec une réponse directe de 2 à 3 phrases.`, act: { kind: 'tool', id: 'faqgen' } }); }
    // 5. de quoi toujours avoir des consignes utiles
    const evergreen = [
      ['ev-citation', 'Tester un passage clé avec le Simulateur de citation', 'Prenez le paragraphe le plus important de votre page d’accueil : VANTIX vous dit s’il a des chances d’être repris par les IA et propose une version plus citable.', 'citation'],
      ['ev-faq', 'Ajouter une FAQ faite de vraies questions', 'Choisissez un sujet de votre site : VANTIX récupère les questions posées sur Google et Reddit et prépare la FAQ avec son balisage.', 'faqgen'],
      ['ev-attack', 'Étudier un concurrent', 'Le Plan d’attaque vous montre les sujets qu’il couvre et pas vous, et comment le dépasser.', 'attack'],
      ['ev-plan', 'Choisir le prochain article à écrire', 'Le Plan de contenu classe les sujets que les gens recherchent vraiment.', 'plan'],
      ['ev-speed', 'Vérifier la vitesse de vos pages principales', 'Une page lente perd des positions sur Google et des visiteurs.', 'speed'],
      ['ev-facts', 'Vérifier ce que les IA disent de votre marque', 'Les IA inventent parfois des prix ou des fonctionnalités : l’outil Erreurs des IA compare leurs réponses à votre site.', 'brandfacts'],
    ];
    evergreen.forEach(([k, t, h, id], i) => add({ key: k + ':' + today().slice(0, 7), type: 'content', site: '', w: 6 - i * 0.5, title: t, how: h, act: { kind: 'tool', id } }));
    return out;
  }

  /** Choisit les N consignes du jour : les plus utiles, en variant les types et les sites. */
  function pick(cands, n, st) {
    const blocked = new Set([...(st.done || []).filter((d) => ago(d.at) < 60).map((d) => d.key), ...(st.skipped || []).filter((d) => ago(d.at) < 3).map((d) => d.key)]);
    const pool = cands.filter((c) => !blocked.has(c.key)).sort((a, b) => b.w - a.w);
    const chosen = [], perType = {}, perSite = {};
    const cap = Math.max(1, Math.ceil(n / 3));
    for (const c of pool) { if (chosen.length >= n) break; if ((perType[c.type] || 0) >= cap || (c.site && (perSite[c.site] || 0) >= Math.max(2, Math.ceil(n / 4)))) continue; chosen.push(c); perType[c.type] = (perType[c.type] || 0) + 1; if (c.site) perSite[c.site] = (perSite[c.site] || 0) + 1; }
    for (const c of pool) { if (chosen.length >= n) break; if (!chosen.includes(c)) chosen.push(c); }
    return chosen;
  }
  async function ensureToday(force = false) {
    await P.ready;
    const st = (await T.load(STORE)) || { date: null, items: [], done: [], skipped: [], streak: 0, lastDoneDay: null };
    const plan = P.get();
    if (!force && st.date === today() && st.plan === plan.id) return st;
    const cands = await candidates();
    const keep = st.date === today() ? st.items.filter((x) => x.status === 'done') : [];
    const fresh = pick(cands.filter((c) => !keep.some((k) => k.key === c.key)), Math.max(0, plan.daily - keep.length), st);
    st.items = [...keep, ...fresh.map((c) => ({ ...c, status: 'todo' }))];
    st.date = today(); st.plan = plan.id; st.pool = cands.length;
    await T.save(STORE, st);
    return st;
  }
  async function mark(st, key, status) {
    const it = st.items.find((x) => x.key === key); if (!it) return;
    it.status = status;
    if (status === 'done') {
      st.done = [{ key, at: new Date().toISOString() }, ...(st.done || [])].slice(0, 2000);
      if (st.lastDoneDay !== today()) { const y = new Date(); y.setDate(y.getDate() - 1); st.streak = st.lastDoneDay === ymd(y) ? (st.streak || 0) + 1 : 1; st.lastDoneDay = today(); }
    }
    if (status === 'skipped') {
      st.skipped = [{ key, at: new Date().toISOString() }, ...(st.skipped || [])].slice(0, 500);
      // on remplace par la consigne suivante
      const cands = await candidates();
      const [next] = pick(cands.filter((c) => !st.items.some((x) => x.key === c.key)), 1, st);
      st.items = st.items.filter((x) => x.key !== key); if (next) st.items.push({ ...next, status: 'todo' });
    }
    await T.save(STORE, st);
  }
  function act(a) {
    if (!a) return;
    if (a.kind === 'tool') { T.open(a.id); if (a.url) setTimeout(() => { const f = $('#rfUrl') || $('#opUrl') || $('#ciUrl'); if (f) f.value = a.url; }, 300); }
    else if (a.kind === 'radar') { const b = $('#radarBtn'); if (b) b.click(); }
    else if (a.kind === 'new') { const b = $('#newBtn'); if (b) b.click(); if (a.url) setTimeout(() => { const f = $('#url'); if (f) f.value = a.url; }, 200); }
    else if (a.kind === 'report') { const h = $(`#history [data-id="${a.id}"]`); if (h) { h.click(); setTimeout(() => { const t = $('#tabs button[data-tab=fixes]'); if (t) t.click(); }, 300); } else toast('Analyse introuvable : relancez-la.'); }
  }

  async function open(el) {
    el.innerHTML = '<p class="muted" style="padding:40px">Préparation de vos consignes…</p>';
    const st = await ensureToday(); render(el, st);
  }
  function render(el, st) {
    const plan = P.get();
    const done = st.items.filter((x) => x.status === 'done').length, total = st.items.length;
    const dateTxt = new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
    el.innerHTML = `<div class="radar"><span class="label">Consignes du jour · ${esc(dateTxt)}</span><div class="rhead2"><h1>${done >= total && total ? 'Tout est fait pour aujourd’hui' : `${fmt(total - done)} action${total - done > 1 ? 's' : ''} pour progresser aujourd’hui`}</h1>${P.picker('dlPlan')}</div>
      <p class="lede">Chaque matin, VANTIX choisit les actions qui vous feront gagner le plus de visibilité sur Google et dans les IA, à partir de vos analyses, de vos mots-clés et de votre Radar IA. Formule ${esc(plan.name)} : jusqu’à ${fmt(plan.daily)} consigne${plan.daily > 1 ? 's' : ''} par jour${total < plan.daily ? ` (VANTIX a trouvé ${fmt(total)} actions vraiment utiles aujourd’hui : plus vous ajoutez de sites, de mots-clés et d’analyses, plus la liste s’allonge)` : ''}.</p>
      <div class="tiles"><div class="tile"><b>${fmt(done)} / ${fmt(total)}</b><span>faites aujourd’hui</span></div><div class="tile ${st.streak > 1 ? 'good' : ''}"><b>${fmt(st.lastDoneDay === today() || st.lastDoneDay === ymd(new Date(Date.now() - 86400000)) ? st.streak || 0 : 0)} j</b><span>jours d’affilée</span></div><div class="tile"><b>${fmt((st.done || []).length)}</b><span>actions faites en tout</span></div></div>
      <div class="bar" style="margin:18px 0 6px"><i style="width:${total ? (done / total) * 100 : 0}%"></i></div>
      <div class="sec">${st.items.map((it, i) => `<div class="card pass task ${it.status === 'done' ? 'isdone' : ''}"><div class="passhead"><b class="rank">${i + 1}</b><div><h3>${esc(it.title)} <span class="tag">${esc(TYPE[it.type] || '')}</span>${it.site ? ` <span class="tag">${esc(it.site)}</span>` : ''}</h3><p>${esc(it.how || '')}</p>${it.example ? `<p class="muted">Exemple : ${esc(it.example)}</p>` : ''}</div>
        <div class="taskbtns">${it.status === 'done' ? '<span class="muted">✓ Fait</span>' : `<button class="btn" type="button" data-done="${i}">C’est fait</button><button class="ghostbtn" type="button" data-go="${i}">Ouvrir</button><button class="ghostbtn" type="button" data-skip="${i}">Plus tard</button>`}</div></div></div>`).join('') || '<p class="empty">Aucune consigne : lancez une analyse de votre site pour commencer.</p>'}</div>
      <div class="toolbar"><button class="ghostbtn" id="dlRedo" type="button">Recalculer les consignes</button></div></div>`;
    $$('[data-done]', el).forEach((b) => b.addEventListener('click', async () => { await mark(st, st.items[+b.dataset.done].key, 'done'); render(el, st); }));
    $$('[data-skip]', el).forEach((b) => b.addEventListener('click', async () => { await mark(st, st.items[+b.dataset.skip].key, 'skipped'); render(el, st); }));
    $$('[data-go]', el).forEach((b) => b.addEventListener('click', () => act(st.items[+b.dataset.go].act)));
    $('#dlPlan', el).addEventListener('change', async (e) => { P.set(e.target.value); const s2 = await ensureToday(true); render(el, s2); });
    $('#dlRedo', el).addEventListener('click', async () => { const s2 = await ensureToday(true); render(el, s2); toast('Consignes recalculées'); });
  }

  // chaque matin (dès 8 h, ou à l'ouverture de VANTIX), les consignes sont prêtes et une notification les annonce
  async function morning() {
    if (new Date().getHours() < 8) return;
    const prev = await T.load(STORE);
    if (prev && prev.notified === today()) return;
    const st = await ensureToday();
    const n = st.items.filter((x) => x.status !== 'done').length;
    st.notified = today(); await T.save(STORE, st);
    if (n) api.notify('VANTIX · consignes du jour', `${n} action${n > 1 ? 's' : ''} pour progresser aujourd’hui : ${st.items[0].title}`);
  }
  setTimeout(() => morning().catch(() => {}), 20 * 1000);
  setInterval(() => morning().catch(() => {}), 20 * 60 * 1000);

  T.register({ id: 'daily', label: 'Consignes du jour', group: 'Aujourd’hui', icon: 'M9 11l3 3 8-8M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9', open });
  VX.daily = { candidates, pick, ensureToday };
})();
