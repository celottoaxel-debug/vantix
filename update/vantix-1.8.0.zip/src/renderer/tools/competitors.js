// VANTIX — Analyse des concurrents : sujets manquants, mots qu'ils utilisent, recette de leurs pages, points faibles
(function () {
  'use strict';
  const VX = window.VX, U = VX.util, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T) return;
  const { $, $$, esc, toast, fmt } = UI;

  // ---------- analyse (exportée pour les tests) ----------
  /** Jetons de sujet d'une page : title + H1, sans les mots répétés sur tout le site (nom de marque, suffixes). */
  function topicSets(site) {
    const raw = site.pages.map((p) => T.terms(p.h1 || String(p.title).split(/\s[|–—·-]\s/)[0]));
    const df = new Map();
    for (const s of raw) for (const w of s) df.set(w, (df.get(w) || 0) + 1);
    const n = raw.length, brand = new Set(T.terms(site.host.split('.')[0]));
    return raw.map((s) => new Set([...s].filter((w) => !brand.has(w) && !(n >= 6 && df.get(w) / n > 0.4))));
  }
  const overlap = (a, b) => { if (!a.size || !b.size) return 0; let i = 0; for (const x of a) if (b.has(x)) i++; return Math.max(i / (a.size + b.size - i), i / Math.min(a.size, b.size) * 0.75); };

  function compare(own, comps) {
    const ownSets = topicSets(own);
    // 1. sujets couverts par les concurrents et pas par vous, regroupés quand plusieurs concurrents les traitent
    const gaps = [];
    for (const c of comps) {
      const sets = topicSets(c);
      c.pages.forEach((p, i) => {
        const s = sets[i]; if (s.size < 2) return;
        const best = ownSets.reduce((m, o) => Math.max(m, overlap(s, o)), 0);
        if (best < 0.45) gaps.push({ site: c.host, page: p, set: s });
      });
    }
    const clusters = [];
    for (const g of gaps) {
      let home = clusters.find((cl) => overlap(cl.set, g.set) >= 0.5);
      if (!home) { home = { set: new Set(g.set), items: [] }; clusters.push(home); }
      home.items.push(g);
    }
    const topics = clusters.map((cl) => {
      const sites = [...new Set(cl.items.map((i) => i.site))];
      const lead = [...cl.items].sort((a, b) => (a.page.h1 || a.page.title).length - (b.page.h1 || b.page.title).length)[0];
      return { label: lead.page.h1 || lead.page.title, sites, pages: cl.items.map((i) => ({ site: i.site, url: i.page.url, title: i.page.h1 || i.page.title, words: i.page.words })), score: sites.length * 3 + cl.items.length + Math.min(3, T.median(cl.items.map((i) => i.page.words)) / 800) };
    }).sort((a, b) => b.score - a.score).slice(0, 80);

    // 2. mots fréquents chez les concurrents, absents chez vous
    const ownWords = new Set();
    for (const p of own.pages) for (const [w] of p.keywords) ownWords.add(w);
    for (const p of own.pages) for (const w of T.terms(p.title + ' ' + p.h1 + ' ' + p.h2.join(' '))) ownWords.add(w);
    const brandWords = new Set(comps.flatMap((c) => [...T.terms(c.host.split('.')[0])]).concat([...T.terms(own.host.split('.')[0])]));
    const kw = new Map();
    for (const c of comps) for (const p of c.pages) for (const [w, n] of p.keywords) {
      if (ownWords.has(w) || brandWords.has(w) || w.length < 4) continue;
      const e = kw.get(w) || { word: w, pages: 0, uses: 0, sites: new Set() }; e.pages++; e.uses += n; e.sites.add(c.host); kw.set(w, e);
    }
    const words = [...kw.values()].filter((e) => e.sites.size >= Math.min(2, comps.length) && e.pages >= 3).map((e) => ({ word: e.word, pages: e.pages, uses: e.uses, sites: [...e.sites] })).sort((a, b) => b.sites.length - a.sites.length || b.pages - a.pages).slice(0, 60);

    // 3. la « recette » de chaque site
    const recipe = (s) => {
      const P = s.pages;
      return {
        host: s.host, own: s === own, pages: P.length, sitemap: s.sitemapCount,
        words: T.median(P.map((p) => p.words)), h2: T.median(P.map((p) => p.h2.length)),
        faq: T.share(P, (p) => p.faq), questions: T.share(P, (p) => p.questions > 0), article: T.share(P, (p) => p.article),
        answerFirst: T.share(P, (p) => p.answerFirst), sources: T.share(P, (p) => p.sources > 0), dated: T.share(P, (p) => p.dated),
        author: T.share(P, (p) => p.author), tables: T.share(P, (p) => p.tables > 0), time: T.median(P.map((p) => p.timeMs)),
        slow: T.share(P, (p) => p.timeMs > 1500), hidden: T.share(P, (p) => p.streamed >= 30), noDesc: T.share(P, (p) => !p.description),
        aiBlocked: s.aiAccess.filter((a) => ['GPTBot', 'OAI-SearchBot', 'ClaudeBot', 'PerplexityBot', 'Google-Extended'].includes(a.bot) && !a.home).map((a) => a.bot),
        llms: s.llms, internal: T.median(P.map((p) => p.internalLinks)),
      };
    };
    const recipes = [own, ...comps].map(recipe);

    // 4. points faibles des concurrents (là où vous pouvez faire mieux)
    const weak = recipes.filter((r) => !r.own).map((r) => {
      const w = [];
      if (r.aiBlocked.length) w.push(`bloque ${r.aiBlocked.join(', ')} dans robots.txt : ces IA ne peuvent pas le citer`);
      if (r.hidden >= 30) w.push(`${r.hidden} % des pages cachent leur contenu derrière JavaScript (invisible pour les robots d'IA)`);
      if (!r.llms) w.push('pas de fichier llms.txt');
      if (r.slow >= 30) w.push(`${r.slow} % des pages mettent plus de 1,5 s à répondre`);
      if (r.faq < 20) w.push(`FAQ sur seulement ${r.faq} % des pages`);
      if (r.answerFirst < 40) w.push(`la réponse n'arrive pas dès le début sur ${100 - r.answerFirst} % des pages`);
      if (r.sources < 30) w.push(`peu de sources citées (${r.sources} % des pages)`);
      if (r.dated < 40) w.push(`${100 - r.dated} % des pages sans date visible`);
      if (r.noDesc >= 20) w.push(`${r.noDesc} % des pages sans meta description`);
      return { host: r.host, items: w };
    });

    // 5. ce que les concurrents font mieux que vous
    const me = recipes[0], others = recipes.slice(1);
    const avg = (k) => Math.round(others.reduce((s, r) => s + (r[k] || 0), 0) / Math.max(1, others.length));
    const better = [];
    if (avg('words') > (me.words || 0) * 1.3) better.push(`Leurs pages sont plus longues : ${fmt(avg('words'))} mots en médiane contre ${fmt(me.words || 0)} chez vous.`);
    if (avg('faq') > me.faq + 15) better.push(`${avg('faq')} % de leurs pages ont une FAQ, contre ${me.faq} % chez vous.`);
    if (avg('questions') > me.questions + 15) better.push(`Ils posent les questions des internautes en intertitres (${avg('questions')} % des pages, vous ${me.questions} %).`);
    if (avg('sources') > me.sources + 15) better.push(`Ils citent davantage de sources (${avg('sources')} % des pages, vous ${me.sources} %).`);
    if (avg('dated') > me.dated + 15) better.push(`Leurs pages sont datées (${avg('dated')} %, vous ${me.dated} %) : les IA privilégient les contenus récents.`);
    if (avg('h2') > (me.h2 || 0) + 2) better.push(`Leurs pages sont mieux découpées : ${avg('h2')} intertitres en médiane, vous ${me.h2 || 0}.`);
    if (others.some((r) => r.sitemap > me.sitemap * 2)) better.push(`Ils ont beaucoup plus de pages : ${others.filter((r) => r.sitemap > me.sitemap * 2).map((r) => r.host + ' (' + fmt(r.sitemap) + ')').join(', ')}, contre ${fmt(me.sitemap)} chez vous.`);
    if (me.slow > avg('slow') + 15) better.push(`Vos pages sont plus lentes : ${me.slow} % dépassent 1,5 s, contre ${avg('slow')} % chez eux.`);
    if (me.hidden > avg('hidden') + 15) better.push(`Une partie de votre contenu est cachée aux robots d'IA (${me.hidden} % des pages), moins chez eux (${avg('hidden')} %).`);
    return { topics, words, recipes, weak, better };
  }

  // ---------- interface ----------
  const STORE = 'competitors';
  async function open(el) {
    const saved = await T.load(STORE);
    let site = saved ? saved.input.site : '', comps = saved ? saved.input.comps : '';
    if (!saved && api.radarList) {
      try { const l = await api.radarList(); if (l[0]) { const p = await api.radarLoad(l[0].id); site = p.site || ''; comps = (p.competitors || []).filter((c) => c.domain).map((c) => c.domain).join('\n'); } } catch {}
    }
    el.innerHTML = `<div class="radar">
      <span class="label">Concurrents</span><h1>Ce que vos concurrents font et pas vous</h1>
      <p class="lede">VANTIX lit les pages publiques de vos concurrents et de votre site, puis vous montre les sujets qu’ils traitent et pas vous, les mots qu’ils emploient, la recette de leurs pages et leurs points faibles.</p>
      <form class="rform" id="cpForm" novalidate>
        <div class="grid2"><label class="opt"><span>Votre site</span><input class="field" id="cpSite" value="${esc(site)}" placeholder="getspotiq.com" spellcheck="false"></label>
        <label class="opt"><span>Pages lues par site</span><select class="field" id="cpMax">${[[30, '30 (rapide)'], [60, '60'], [150, '150 (complet, plus long)']].map(([v, l]) => `<option value="${v}" ${(saved ? saved.input.max : 60) == v ? 'selected' : ''}>${l}</option>`).join('')}</select></label></div>
        <label class="opt"><span>Concurrents, un site par ligne (5 au maximum)</span><textarea class="field" id="cpComps" rows="5" spellcheck="false" placeholder="wanderlog.com&#10;routard.com&#10;lonelyplanet.com">${esc(comps)}</textarea></label>
        <p class="err" id="cpErr" role="alert"></p>
        <div class="toolbar"><button class="btn" type="submit">Analyser</button>${saved ? `<button class="ghostbtn" id="cpLast" type="button">Revoir l’analyse du ${new Date(saved.date).toLocaleDateString('fr-FR')}</button>` : ''}</div>
        <p class="muted" style="font-size:13px">Seules les pages publiques sont lues, lentement et en respectant robots.txt. Rien n’est copié : VANTIX en tire des statistiques.</p>
      </form></div>`;
    const last = $('#cpLast', el); if (last) last.addEventListener('click', () => results(el, saved));
    $('#cpForm', el).addEventListener('input', () => { $('#cpErr', el).textContent = ''; });
    $('#cpForm', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const s = T.origin($('#cpSite', el).value), list = $('#cpComps', el).value.split(/[\n,]+/).map((x) => T.origin(x)).filter(Boolean);
      if (!s) { $('#cpErr', el).textContent = 'Indiquez l’adresse de votre site.'; return; }
      if (!list.length) { $('#cpErr', el).textContent = 'Ajoutez au moins un concurrent.'; return; }
      run(el, { site: $('#cpSite', el).value.trim(), comps: $('#cpComps', el).value.trim(), max: +$('#cpMax', el).value }, s, [...new Set(list)].filter((x) => x !== s).slice(0, 5));
    });
  }

  async function run(el, input, site, comps) {
    const pg = T.progress(el, 'Analyse des concurrents');
    const all = [site, ...comps];
    const read = [];
    for (let i = 0; i < all.length; i++) {
      if (pg.stopped) break;
      pg.title(new URL(all[i]).hostname.replace(/^www\./, ''));
      try {
        const r = await T.sitePages(all[i], { max: input.max, log: pg.log, isStopped: () => pg.stopped, onPage: (n, tot, url) => { pg.bar((i + n / Math.max(1, tot)) / all.length); pg.cur(url); } });
        if (!r.pages.length) pg.log(`${r.host} : aucune page lisible (site protégé ou entièrement en JavaScript).`);
        read.push(r);
      } catch (err) { pg.log('Erreur : ' + err.message); if (i === 0) { toast('Votre site est illisible : ' + err.message); return open(el); } }
    }
    const own = read[0], cs = read.slice(1).filter((r) => r.pages.length);
    if (!own || !own.pages.length || !cs.length) { toast('Pas assez de pages lues pour comparer.'); return open(el); }
    const res = { date: new Date().toISOString(), input, own: { host: own.host }, comps: cs.map((c) => c.host), ...compare(own, cs),
      // servent de référence à l'optimiseur d'article et au plan de contenu
      pagesForRefs: cs.flatMap((c) => c.pages.map((p) => ({ url: p.url, title: p.title, h1: p.h1, h2: p.h2, words: p.words, keywords: p.keywords }))),
      ownTitles: own.pages.map((p) => p.h1 || p.title) };
    await T.save(STORE, res);
    results(el, res);
  }

  function results(el, r) {
    const pct = (v) => v == null ? '–' : v + ' %';
    const rows = [
      ['Pages lues', (x) => fmt(x.pages)], ['Adresses dans le sitemap', (x) => fmt(x.sitemap)], ['Mots par page (médiane)', (x) => fmt(x.words)], ['Intertitres H2 (médiane)', (x) => fmt(x.h2)],
      ['Pages avec FAQ', (x) => pct(x.faq)], ['Questions en intertitre', (x) => pct(x.questions)], ['Réponse dès le début', (x) => pct(x.answerFirst)], ['Sources citées', (x) => pct(x.sources)],
      ['Pages datées', (x) => pct(x.dated)], ['Auteur indiqué', (x) => pct(x.author)], ['Données structurées Article', (x) => pct(x.article)], ['Tableaux', (x) => pct(x.tables)],
      ['Liens internes (médiane)', (x) => fmt(x.internal)], ['Temps de réponse (médiane)', (x) => fmt(x.time) + ' ms'], ['Pages lentes (> 1,5 s)', (x) => pct(x.slow)],
      ['Contenu caché aux IA', (x) => pct(x.hidden)], ['Robots d’IA bloqués', (x) => x.aiBlocked.length ? esc(x.aiBlocked.join(', ')) : 'aucun'], ['Fichier llms.txt', (x) => (x.llms ? 'oui' : 'non')],
    ];
    el.innerHTML = `<header class="rhead"><div><span class="label">Concurrents · ${new Date(r.date).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })}</span><h1>${esc(r.own.host)}</h1><p class="rmeta">face à ${r.comps.map(esc).join(', ')}</p></div>
      <div class="ractions"><button class="ghostbtn" id="cpNew" type="button">Nouvelle analyse</button><button class="ghostbtn" id="cpCsv" type="button">Exporter les sujets (CSV)</button></div></header>
      <div class="tabbody">
      ${r.better.length ? `<div class="sec"><h2>Ce qu’ils font mieux que vous</h2><div class="card"><ul class="bul">${r.better.map((b) => `<li>${esc(b)}</li>`).join('')}</ul></div></div>` : ''}
      <div class="sec"><h2>Sujets qu’ils traitent et pas vous <small>${r.topics.length} sujets · les premiers sont traités par plusieurs concurrents</small></h2>
        ${T.table(['Sujet', 'Traité par', 'Pages', 'Mots (médiane)'], r.topics.map((t) => [`<b style="font-weight:400">${esc(t.label)}</b><div class="sub">${t.pages.slice(0, 3).map((p) => T.ext(p.url, p.site + ' · ' + p.title.slice(0, 60))).join('<br>')}</div>`, esc(t.sites.join(', ')), t.pages.length, T.median(t.pages.map((p) => p.words)) || 0]), 'Aucun sujet manquant : vous couvrez déjà ce que vos concurrents publient.', 640)}</div>
      <div class="sec words"><div class="card"><h3>Mots qu’ils emploient et pas vous</h3>${r.words.length ? `<div class="chips">${r.words.map((w) => `<span class="kchip" title="${w.pages} pages, ${w.sites.length} concurrents">${esc(w.word)} <small>${w.pages}</small></span>`).join('')}</div><p class="muted" style="font-size:13px;margin-top:12px">Le chiffre indique le nombre de pages concurrentes où le mot revient. Ce sont des pistes de sujets et de vocabulaire à intégrer.</p>` : '<p class="empty">Rien de notable.</p>'}</div>
        <div class="card"><h3>Leurs points faibles</h3>${r.weak.map((w) => `<p style="margin:0 0 6px"><b style="font-weight:400">${esc(w.host)}</b></p>${w.items.length ? `<ul class="bul" style="margin-bottom:14px">${w.items.map((i) => `<li>${esc(i)}</li>`).join('')}</ul>` : '<p class="muted" style="font-size:13px;margin:0 0 14px">Rien de marquant.</p>'}`).join('')}</div></div>
      <div class="sec"><h2>La recette de chaque site</h2><div class="tablewrap"><table><thead><tr><th></th>${r.recipes.map((x) => `<th>${esc(x.host)}${x.own ? ' (vous)' : ''}</th>`).join('')}</tr></thead><tbody>${rows.map(([l, f]) => `<tr><td>${l}</td>${r.recipes.map((x) => `<td class="num" ${x.own ? 'style="color:var(--spark)"' : ''}>${f(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div></div>
      </div>`;
    T.bindExt(el);
    $('#cpNew', el).addEventListener('click', () => open(el));
    $('#cpCsv', el).addEventListener('click', async () => {
      const lines = [['Sujet', 'Concurrents', 'Pages', 'Exemple'], ...r.topics.map((t) => [t.label, t.sites.join(' '), t.pages.length, t.pages[0].url])];
      const content = '﻿' + lines.map((l) => l.map((c) => /[";\n,]/.test(String(c)) ? '"' + String(c).replace(/"/g, '""') + '"' : c).join(';')).join('\r\n');
      try { await api.exportFile({ defaultName: `sujets-concurrents-${r.own.host}.csv`, content, filters: [{ name: 'CSV', extensions: ['csv'] }] }); } catch (e) { toast(e.message); }
    });
  }

  T.register({ id: 'competitors', label: 'Concurrents', group: 'Analyser', icon: 'M4 19h16M7 16V9M12 16V5M17 16v-4', open });
  VX.competitors = { compare, topicSets };
})();
