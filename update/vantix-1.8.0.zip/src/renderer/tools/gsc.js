// VANTIX — Search Console : lecture de l'export Google (zip ou CSV), opportunités de positions et de clics
(function () {
  'use strict';
  const VX = window.VX, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T) return;
  const { $, $$, esc, toast, fmt } = UI;

  // ---------- lecture des fichiers ----------
  async function unzip(buf) {
    const dv = new DataView(buf), u8 = new Uint8Array(buf), out = [];
    let eocd = -1;
    for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 66000); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    if (eocd < 0) throw new Error('Fichier zip illisible.');
    const n = dv.getUint16(eocd + 10, true); let p = dv.getUint32(eocd + 16, true);
    for (let k = 0; k < n; k++) {
      if (dv.getUint32(p, true) !== 0x02014b50) break;
      const method = dv.getUint16(p + 10, true), csize = dv.getUint32(p + 20, true), nlen = dv.getUint16(p + 28, true), xlen = dv.getUint16(p + 30, true), clen = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true);
      const name = new TextDecoder().decode(u8.subarray(p + 46, p + 46 + nlen));
      const lnlen = dv.getUint16(off + 26, true), lxlen = dv.getUint16(off + 28, true);
      const data = u8.subarray(off + 30 + lnlen + lxlen, off + 30 + lnlen + lxlen + csize);
      let bytes;
      if (method === 0) bytes = data;
      else if (method === 8) bytes = new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
      else { p += 46 + nlen + xlen + clen; continue; }
      if (/\.csv$/i.test(name)) out.push({ name: name.split('/').pop(), text: new TextDecoder('utf-8').decode(bytes) });
      p += 46 + nlen + xlen + clen;
    }
    return out;
  }
  function parseCsv(text) {
    text = text.replace(/^﻿/, '');
    const sep = (text.split('\n')[0].match(/;/g) || []).length > (text.split('\n')[0].match(/,/g) || []).length ? ';' : ',';
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; continue; }
      if (c === '"') q = true; else if (c === sep) { row.push(cell); cell = ''; } else if (c === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; } else if (c !== '\r') cell += c;
    }
    if (cell || row.length) { row.push(cell); rows.push(row); }
    return rows.filter((r) => r.some((x) => x.trim()));
  }
  const num = (v) => { const s = String(v || '').replace(/\s| | /g, '').replace('%', ''); if (!s) return 0; if (/^\d{1,3}(,\d{3})+$/.test(s)) return +s.replace(/,/g, ''); return parseFloat(s.includes(',') && !s.includes('.') ? s.replace(',', '.') : s.replace(/,/g, '')) || 0; };
  const KIND = [
    ['queries', /quer|requ[eê]t|consulta|suchanfrage/i], ['pages', /^(top )?pages?|pages les plus|p[aá]ginas|seiten/i], ['dates', /^date|^fecha|^datum/i],
    ['countries', /countr|pays|pa[ií]s|land/i], ['devices', /device|appareil|dispositivo|ger[aä]t/i],
  ];
  /** Transforme les CSV de l'export en un jeu de données normalisé. */
  function normalize(files) {
    const d = { queries: [], pages: [], dates: [], countries: [], devices: [] };
    for (const f of files) {
      const rows = parseCsv(f.text); if (rows.length < 2) continue;
      const head = rows[0].map((h) => h.trim().toLowerCase());
      const kind = (KIND.find(([, re]) => re.test(head[0])) || KIND.find(([, re]) => re.test(f.name)) || [])[0];
      if (!kind) continue;
      const ix = (re) => head.findIndex((h) => re.test(h));
      const iC = ix(/clic|click|klick/), iI = ix(/impr/), iP = ix(/position|posici/), iT = ix(/ctr/);
      if (iC < 0 || iI < 0) continue;
      d[kind] = rows.slice(1).map((r) => ({ key: r[0].trim(), clicks: num(r[iC]), impressions: num(r[iI]), ctr: iT >= 0 ? num(r[iT]) : 0, position: iP >= 0 ? num(r[iP]) : 0 })).filter((x) => x.key);
      for (const x of d[kind]) if (!x.ctr && x.impressions) x.ctr = Math.round((x.clicks / x.impressions) * 1000) / 10;
    }
    d.dates.sort((a, b) => a.key.localeCompare(b.key));
    return d;
  }
  // taux de clic habituel selon la position (ordre de grandeur des études publiques)
  const EXPECTED = [0, 28, 15, 11, 8, 7, 5, 4, 3, 2.5, 2];
  function analyze(d) {
    const totC = d.queries.reduce((s, q) => s + q.clicks, 0) || d.dates.reduce((s, x) => s + x.clicks, 0);
    const totI = d.dates.length ? d.dates.reduce((s, x) => s + x.impressions, 0) : d.queries.reduce((s, q) => s + q.impressions, 0);
    const wPos = d.queries.length ? d.queries.reduce((s, q) => s + q.position * q.impressions, 0) / Math.max(1, d.queries.reduce((s, q) => s + q.impressions, 0)) : 0;
    const striking = d.queries.filter((q) => q.position > 7 && q.position <= 20 && q.impressions >= 10).sort((a, b) => b.impressions - a.impressions).slice(0, 50);
    const lowCtr = d.queries.filter((q) => q.position >= 1 && q.position <= 10 && q.impressions >= 30 && q.ctr < (EXPECTED[Math.round(q.position)] || 2) * 0.6).map((q) => ({ ...q, expected: EXPECTED[Math.round(q.position)] || 2, lost: Math.round(q.impressions * ((EXPECTED[Math.round(q.position)] || 2) - q.ctr) / 100) })).sort((a, b) => b.lost - a.lost).slice(0, 40);
    const questions = d.queries.filter((q) => /\?|^(comment|pourquoi|quand|quel|quelle|quels|quelles|où|combien|que |qu'|est-ce|how|what|why|when|where|which|who|can|is |are |do |does |cómo|qué|cuándo|dónde|cuál)/i.test(q.key)).sort((a, b) => b.impressions - a.impressions).slice(0, 40);
    const pagesLow = d.pages.filter((p) => p.impressions >= 100 && p.ctr < 1.5).sort((a, b) => b.impressions - a.impressions).slice(0, 30);
    return { clicks: totC, impressions: totI, ctr: totI ? Math.round((totC / totI) * 1000) / 10 : 0, position: Math.round(wPos * 10) / 10, striking, lowCtr, questions, pagesLow };
  }

  // ---------- interface ----------
  const STORE = 'gsc';
  async function open(el) {
    const saved = await T.load(STORE);
    if (saved && saved.data) return results(el, saved);
    intro(el);
  }
  function intro(el, saved) {
    el.innerHTML = `<div class="radar"><span class="label">Search Console</span><h1>Vos vraies positions sur Google</h1>
      <p class="lede">Importez l’export de Google Search Console : VANTIX vous montre vos clics, vos positions, et surtout les mots-clés où un petit effort vous ferait gagner des visiteurs.</p>
      <div class="card steps"><h3>Récupérer l’export (une minute, gratuit)</h3><ol>
        <li>Ouvrez <b>search.google.com/search-console</b> et choisissez votre site.</li>
        <li>Cliquez sur <b>Performances</b> (ou Résultats de recherche), puis choisissez la période, par exemple <b>3 derniers mois</b>.</li>
        <li>En haut à droite, <b>Exporter</b>, puis <b>Télécharger le fichier CSV</b>. Vous obtenez un fichier .zip.</li>
        <li>Déposez ce fichier ci-dessous, tel quel.</li></ol></div>
      <label class="drop" id="gscDrop"><input type="file" id="gscFile" accept=".zip,.csv" multiple hidden><b>Déposer l’export ici</b><span class="muted">ou cliquez pour choisir le fichier .zip (ou les fichiers .csv)</span></label>
      <p class="err" id="gscErr" role="alert"></p>
      ${saved ? '<div class="toolbar"><button class="ghostbtn" id="gscBack" type="button">Revenir à l’import précédent</button></div>' : ''}</div>`;
    const take = async (files) => {
      try {
        let csvs = [];
        for (const f of files) {
          const buf = await f.arrayBuffer();
          if (/\.zip$/i.test(f.name) || new Uint8Array(buf.slice(0, 2)).join() === '80,75') csvs.push(...await unzip(buf));
          else csvs.push({ name: f.name, text: new TextDecoder('utf-8').decode(buf) });
        }
        const data = normalize(csvs);
        if (!data.queries.length && !data.pages.length) throw new Error('Aucune donnée de requêtes ou de pages trouvée : déposez le fichier .zip exporté depuis « Performances ».');
        const rec = { date: new Date().toISOString(), file: files[0].name, from: data.dates[0] ? data.dates[0].key : null, to: data.dates.length ? data.dates[data.dates.length - 1].key : null, data };
        await T.save(STORE, rec); toast('Export importé'); results(el, rec);
      } catch (e) { $('#gscErr', el).textContent = e.message; }
    };
    $('#gscFile', el).addEventListener('change', (e) => take([...e.target.files]));
    const drop = $('#gscDrop', el);
    drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('on'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('on'));
    drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('on'); take([...e.dataTransfer.files]); });
    const back = $('#gscBack', el); if (back) back.addEventListener('click', () => results(el, saved));
  }

  function lineChart(series, key, label, color) {
    if (series.length < 2) return '<p class="empty">Pas de données par jour dans cet export.</p>';
    const W = 560, H = 170, L = 44, R = 10, Tp = 10, B = 26, iw = W - L - R, ih = H - Tp - B;
    const max = Math.max(1, ...series.map((s) => s[key]));
    const x = (i) => L + (i / (series.length - 1)) * iw, y = (v) => Tp + ih - (v / max) * ih;
    const path = series.map((s, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(s[key]).toFixed(1)}`).join(' ');
    const ticks = [0, max / 2, max].map((v) => `<line x1="${L}" x2="${W - R}" y1="${y(v).toFixed(1)}" y2="${y(v).toFixed(1)}" stroke="#1d1d25"/><text x="${L - 6}" y="${(y(v) + 4).toFixed(1)}" text-anchor="end" class="ax">${fmt(Math.round(v))}</text>`).join('');
    const lab = [0, Math.floor(series.length / 2), series.length - 1].map((i) => `<text x="${x(i).toFixed(1)}" y="${H - 6}" text-anchor="${i === 0 ? 'start' : i === series.length - 1 ? 'end' : 'middle'}" class="ax">${new Date(series[i].key + 'T12:00:00').toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</text>`).join('');
    return `<div class="chart mini"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(label)} par jour" style="width:100%;height:auto">${ticks}<path d="${path} L${x(series.length - 1)},${Tp + ih} L${L},${Tp + ih} Z" fill="${color}" opacity=".12"/><path d="${path}" fill="none" stroke="${color}" stroke-width="2" stroke-linejoin="round"/>${lab}${series.map((s, i) => `<rect x="${(x(i) - iw / series.length / 2).toFixed(1)}" y="${Tp}" width="${(iw / series.length).toFixed(1)}" height="${ih}" fill="transparent"><title>${new Date(s.key + 'T12:00:00').toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'long' })} : ${fmt(s[key])} ${label.toLowerCase()}</title></rect>`).join('')}</svg></div>`;
  }

  function results(el, rec) {
    const d = rec.data, a = analyze(d);
    const pos = (v) => v ? v.toLocaleString('fr-FR', { maximumFractionDigits: 1 }) : '–';
    const ctr = (v) => v.toLocaleString('fr-FR', { maximumFractionDigits: 1 }) + ' %';
    el.innerHTML = `<header class="rhead"><div><span class="label">Search Console${rec.from ? ` · du ${new Date(rec.from + 'T12:00:00').toLocaleDateString('fr-FR')} au ${new Date(rec.to + 'T12:00:00').toLocaleDateString('fr-FR')}` : ''}</span><h1>Vos positions sur Google</h1><p class="rmeta">Import du ${new Date(rec.date).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })} · ${fmt(d.queries.length)} requêtes · ${fmt(d.pages.length)} pages</p></div>
      <div class="ractions"><button class="btn" id="gscNew" type="button">Importer un nouvel export</button></div></header>
      <div class="tabbody">
      <div class="sec"><div class="tiles">
        <div class="tile"><b>${fmt(a.clicks)}</b><span>clics depuis Google</span></div><div class="tile"><b>${fmt(a.impressions)}</b><span>affichages dans les résultats</span></div>
        <div class="tile"><b>${ctr(a.ctr)}</b><span>taux de clic moyen</span></div><div class="tile"><b>${pos(a.position)}</b><span>position moyenne</span></div>
        <div class="tile ${a.striking.length ? 'good' : ''}"><b>${fmt(a.striking.length)}</b><span>mots-clés aux portes de la 1re page</span></div>
      </div></div>
      ${d.dates.length > 1 ? `<div class="sec pair"><div class="card"><h3>Clics par jour</h3>${lineChart(d.dates, 'clicks', 'Clics', '#3987e5')}</div><div class="card"><h3>Affichages par jour</h3>${lineChart(d.dates, 'impressions', 'Affichages', '#d95926')}</div></div>` : ''}
      <div class="sec"><h2>Aux portes de la première page <small>positions 8 à 20 : quelques améliorations peuvent les faire monter</small></h2>
        ${T.table(['Mot-clé', 'Position', 'Affichages', 'Clics'], a.striking.map((q) => [esc(q.key), pos(q.position), q.impressions, q.clicks]), 'Aucun mot-clé entre la 8e et la 20e place avec assez d’affichages.', 520)}
        <p class="muted" style="font-size:13px;margin-top:10px">À faire : enrichir la page qui se classe (sous-titres, FAQ, exemples), ajouter des liens internes vers elle depuis vos pages fortes, et viser le mot-clé exact dans le title.</p></div>
      <div class="sec"><h2>Bien placés mais peu cliqués <small>le title ou la description n’attirent pas</small></h2>
        ${T.table(['Mot-clé', 'Position', 'Taux de clic', 'Habituel à cette place', 'Clics perdus estimés'], a.lowCtr.map((q) => [esc(q.key), pos(q.position), ctr(q.ctr), ctr(q.expected), q.lost]), 'Rien d’anormal : vos taux de clic sont dans la moyenne.', 480)}</div>
      <div class="sec words"><div class="card"><h3>Questions que les internautes vous posent</h3>${T.table(['Question', 'Affichages', 'Position'], a.questions.map((q) => [esc(q.key), q.impressions, pos(q.position)]), 'Aucune question dans les requêtes.', 420)}<p class="muted" style="font-size:13px;margin-top:10px">Chacune peut devenir un intertitre ou une entrée de FAQ : c’est exactement le format que reprennent les IA.</p></div>
        <div class="card"><h3>Pages vues mais rarement cliquées</h3>${T.table(['Page', 'Affichages', 'Taux de clic'], a.pagesLow.map((p) => [`<span class="mono">${esc(p.key.replace(/^https?:\/\/[^/]+/, '') || '/')}</span>`, p.impressions, ctr(p.ctr)]), 'Aucune page concernée.', 420)}</div></div>
      <div class="sec words"><div class="card"><h3>Mots-clés qui vous amènent le plus de visiteurs</h3>${T.table(['Mot-clé', 'Clics', 'Position'], [...d.queries].sort((x, y) => y.clicks - x.clicks).slice(0, 60).map((q) => [esc(q.key), q.clicks, pos(q.position)]), 'Aucune requête.', 520)}</div>
        <div class="card"><h3>Vos meilleures pages</h3>${T.table(['Page', 'Clics', 'Position'], [...d.pages].sort((x, y) => y.clicks - x.clicks).slice(0, 60).map((p) => [`<span class="mono">${esc(p.key.replace(/^https?:\/\/[^/]+/, '') || '/')}</span>`, p.clicks, pos(p.position)]), 'Aucune page.', 520)}</div></div>
      ${d.countries.length || d.devices.length ? `<div class="sec words"><div class="card"><h3>Pays</h3>${T.table(['Pays', 'Clics', 'Affichages'], d.countries.slice(0, 15).map((c) => [esc(c.key), c.clicks, c.impressions]), '—')}</div><div class="card"><h3>Appareils</h3>${T.table(['Appareil', 'Clics', 'Affichages'], d.devices.map((c) => [esc(c.key), c.clicks, c.impressions]), '—')}</div></div>` : ''}
      </div>`;
    $('#gscNew', el).addEventListener('click', () => intro(el, rec));
  }

  T.register({ id: 'gsc', label: 'Search Console', group: 'Analyser', icon: 'M10.5 17a6.5 6.5 0 1 1 0-13 6.5 6.5 0 0 1 0 13zM15.5 15.5 20 20', open });
  VX.gsc = { unzip, parseCsv, normalize, analyze };
})();
