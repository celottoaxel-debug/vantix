// VANTIX — outils « IA » : simulateur de citation, où être cité, veille IA, erreurs des IA sur votre marque, score public
(function () {
  'use strict';
  const VX = window.VX, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T) return;
  const { $, $$, esc, toast, fmt, modal } = UI;
  const PLABEL = { openai: 'ChatGPT', anthropic: 'Claude', perplexity: 'Perplexity', gemini: 'Gemini' };
  const pct = (v) => (v == null ? '–' : String(Math.round(v * 10) / 10).replace('.', ',') + ' %');
  const dateFr = (d) => new Date(d).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
  const scoreCol = (v) => (v >= 75 ? 'var(--ok)' : v >= 50 ? 'var(--warn)' : 'var(--crit)');
  const fullUrl = (u) => (/^https?:\/\//i.test(u) ? u : 'https://' + String(u || '').trim());
  const aiReady = async () => { try { const a = await api.aiAvailable(); return !!(a.anthropic || a.openai); } catch { return false; } };
  const copy = async (text) => { try { await navigator.clipboard.writeText(text); toast('Copié'); } catch { toast('Copie impossible : sélectionnez le texte.'); } };

  // =====================================================================================
  // Lecture du texte d'une page : blocs « intertitre + paragraphes », sans menus ni pied de page
  // =====================================================================================
  function pageText(html, url) {
    const doc = new DOMParser().parseFromString(String(html || ''), 'text/html');
    doc.querySelectorAll('script,style,noscript,svg,iframe,template,nav,footer,header,aside,form,[role=navigation],[aria-hidden=true]').forEach((n) => n.remove());
    const root = doc.querySelector('main, article, [role=main]') || doc.body;
    const blocks = [];
    let cur = { heading: (doc.querySelector('h1') || {}).textContent || '', parts: [] };
    const flush = () => { const text = cur.parts.join(' ').replace(/\s+/g, ' ').trim(); if (text) blocks.push({ heading: cur.heading.replace(/\s+/g, ' ').trim(), text }); };
    if (root) {
      const walker = doc.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
      for (let n = walker.currentNode; n; n = walker.nextNode()) {
        const tag = n.tagName;
        if (/^H[1-4]$/.test(tag)) { flush(); cur = { heading: n.textContent || '', parts: [] }; }
        else if (tag === 'P' || tag === 'LI' || tag === 'DD' || tag === 'BLOCKQUOTE' || tag === 'TD') {
          if (n.closest('li li, p p')) continue;
          const t = (n.textContent || '').replace(/\s+/g, ' ').trim();
          if (t.length >= 2) cur.parts.push(tag === 'LI' ? '• ' + t : t);
        }
      }
      flush();
    }
    const title = (doc.querySelector('title') || {}).textContent || '';
    const text = blocks.map((b) => (b.heading ? b.heading + '\n' : '') + b.text).join('\n\n');
    return { url, title: title.trim(), blocks, text };
  }

  // =====================================================================================
  // 1. SIMULATEUR DE CITATION : ce passage a-t-il des chances d'être repris par une IA ?
  // =====================================================================================
  const VAGUE = /\b(r[ée]volutionnaire|incroyable|exceptionnel|unique en son genre|in[ée]gal[ée]|ultime|game[- ]?changer|leader|n°\s?1|num[ée]ro un|de r[êe]ve|magique|parfait|innovant|disruptif|best[- ]in[- ]class|world[- ]class|amazing|revolutionary)\b/i;
  const DECL = /\b(est|sont|permet|permettent|consiste|signifie|d[ée]signe|co[ûu]te|co[ûu]tent|dure|faut|propose|offre|repr[ée]sente|compte|se trouve|is|are|means|costs|allows|lets|takes|requires)\b/i;
  const SOURCE = /\b(selon|d['’]apr[èe]s|source|[ée]tude|rapport|enqu[êe]te|sondage|chiffres? (de|du|officiels?)|insee|minist[èe]re|according to|study|survey|report)\b|https?:\/\//i;
  const UNIT = /\d[\d\s.,]*\s?(€|euros?|\$|%|km|m²|kg|g\b|min|minutes?|h\b|heures?|jours?|mois|ans?|ann[ée]es?|personnes|utilisateurs|clients|pages|fois)/gi;
  function sentencesOf(t) { return String(t).replace(/\s+/g, ' ').trim().split(/(?<=[.!?…])\s+(?=[A-ZÀ-ÖØ-Ý0-9«"“•])/).filter((s) => s.trim()); }
  function scorePassage(text, question) {
    const t = String(text || '').replace(/\s+/g, ' ').trim();
    const words = t ? t.split(' ').length : 0;
    const sents = sentencesOf(t);
    const first = sents[0] || '';
    const firstW = first.split(' ').filter(Boolean).length;
    const avgLen = sents.length ? Math.round(words / sents.length) : 0;
    const units = (t.match(UNIT) || []).length;
    const nums = (t.match(/\d+/g) || []).length;
    const caps = (t.match(/(?<![.!?]\s|^)\b[A-ZÀ-Ý][a-zà-ÿ]+(?:\s[A-ZÀ-Ý][a-zà-ÿ]+)*/g) || []).length;
    const we = (t.match(/\b(nous|notre|nos|we|our)\b/gi) || []).length;
    const qTerms = question ? [...T.terms(question)] : [];
    const head = T.terms(sents.slice(0, 2).join(' '));
    const qHit = qTerms.length ? qTerms.filter((w) => head.has(w) || [...head].some((h) => h.startsWith(w.slice(0, 5)))).length / qTerms.length : null;
    const checks = [
      { id: 'answer', w: 22, ok: firstW > 0 && firstW <= 35 && !/\?$/.test(first) && DECL.test(first), label: 'La réponse arrive dès la première phrase', tip: 'Commencez par une phrase courte (moins de 35 mots) qui répond directement, du type « X est… » ou « Il faut compter… ». Les IA reprennent surtout les premières phrases.' },
      { id: 'match', w: 12, ok: qHit == null ? true : qHit >= 0.5, label: question ? 'Le début reprend les mots de la question' : 'Question visée (facultatif)', tip: 'Reprenez les mots de la question dans les deux premières phrases : l’IA doit reconnaître tout de suite que le passage y répond.' },
      { id: 'facts', w: 16, ok: units >= 2 || nums >= 3, label: 'Des faits précis : chiffres, prix, durées', tip: 'Ajoutez au moins deux données concrètes (prix, durée, pourcentage, quantité). Une IA cite plus volontiers un passage qui contient des chiffres vérifiables.' },
      { id: 'source', w: 10, ok: SOURCE.test(t), label: 'Une source ou une référence', tip: 'Appuyez une affirmation sur une source (« selon l’Insee… », une étude, un lien). Cela rend le passage plus fiable aux yeux des IA.' },
      { id: 'length', w: 12, ok: words >= 40 && words <= 170, label: 'Longueur idéale (40 à 170 mots)', tip: words < 40 ? 'Le passage est trop court pour se suffire à lui-même : développez la réponse avec un ou deux faits.' : 'Le passage est trop long : coupez-le en blocs de 40 à 170 mots, chacun sous un intertitre qui pose une question.' },
      { id: 'short', w: 8, ok: avgLen > 0 && avgLen <= 22, label: 'Des phrases courtes', tip: 'Visez 22 mots par phrase en moyenne : une phrase courte se cite telle quelle, une phrase longue se résume (et se perd).' },
      { id: 'entities', w: 8, ok: caps >= 2, label: 'Des noms précis (lieux, marques, personnes)', tip: 'Nommez les choses : villes, produits, marques, organismes. Les IA s’appuient sur ces noms pour relier votre passage à la question.' },
      { id: 'neutral', w: 7, ok: !VAGUE.test(t) && we <= 2, label: 'Un ton factuel, sans superlatifs', tip: 'Retirez les mots publicitaires (« révolutionnaire », « le meilleur »…) et limitez « nous / notre ». Les IA écartent les textes qui ressemblent à de la publicité.' },
      { id: 'fresh', w: 5, ok: /\b20\d\d\b|\b(janvier|f[ée]vrier|mars|avril|mai|juin|juillet|ao[ûu]t|septembre|octobre|novembre|d[ée]cembre)\b/i.test(t), label: 'Une date ou une année', tip: 'Indiquez l’année ou la date des informations (« en 2026… ») : les IA privilégient ce qui est daté et récent.' },
    ];
    const score = Math.round(checks.reduce((s, c) => s + (c.ok ? c.w : 0), 0));
    return { score, words, sentences: sents.length, checks };
  }
  const verdictOf = (s) => (s >= 75 ? 'Très citable' : s >= 50 ? 'Citable avec quelques retouches' : 'Peu de chances d’être cité');

  function openCitation(el) {
    el.innerHTML = `<div class="radar"><span class="label">Simulateur de citation IA</span><h1>Ce passage sera-t-il cité par une IA ?</h1>
      <p class="lede">Collez un paragraphe ou l’adresse d’une page. VANTIX estime ses chances d’être repris par ChatGPT, Perplexity, Claude ou Gemini, puis vous propose une version plus « citable ».</p>
      <form class="rform" id="ciForm" novalidate>
        <div class="grid2"><label class="opt"><span>Question visée (facultatif)</span><input class="field" id="ciQ" placeholder="combien coûte un week-end à Lisbonne ?"></label>
        <label class="opt"><span>Ou l’adresse d’une page à passer au crible</span><input class="field" id="ciUrl" placeholder="https://monsite.fr/article" spellcheck="false"></label></div>
        <label class="opt"><span>Passage à tester</span><textarea class="field" id="ciText" rows="7" placeholder="Collez ici un paragraphe de votre article…"></textarea></label>
        <p class="err" id="ciErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Tester</button></div>
      </form><div id="ciOut"></div></div>`;
    $('#ciForm', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const q = $('#ciQ', el).value.trim(), url = $('#ciUrl', el).value.trim(), text = $('#ciText', el).value.trim();
      const err = $('#ciErr', el); err.textContent = '';
      if (!text && !url) { err.textContent = 'Collez un passage ou indiquez l’adresse d’une page.'; return; }
      if (text) return showPassage($('#ciOut', el), text, q);
      const btn = $('#ciForm .btn', el); btn.disabled = true; btn.textContent = 'Lecture de la page…';
      try {
        const res = await api.fetchPage({ url: fullUrl(url) });
        if (!res.ok || !res.body) throw new Error('Page illisible : ' + (res.error || res.status));
        const pt = pageText(res.body, res.finalUrl || url);
        const blocks = pt.blocks.filter((b) => b.text.split(' ').length >= 15).map((b) => ({ ...b, s: scorePassage(b.text, q || b.heading) }));
        if (!blocks.length) throw new Error('Aucun paragraphe lisible sur cette page (elle est peut-être affichée uniquement par JavaScript).');
        showPage($('#ciOut', el), pt, blocks, q);
      } catch (ex) { err.textContent = ex.message; } finally { btn.disabled = false; btn.textContent = 'Tester'; }
    });
  }
  function checksHtml(s) {
    return `<ul class="checks2">${s.checks.filter((c) => c.id !== 'match' || c.label.startsWith('Le début')).map((c) => `<li class="${c.ok ? 'ok' : 'ko'}"><span class="ic">${c.ok ? '✓' : '✕'}</span><div><b>${esc(c.label)}</b>${c.ok ? '' : `<p>${esc(c.tip)}</p>`}</div></li>`).join('')}</ul>`;
  }
  function showPassage(out, text, q, heading) {
    const s = scorePassage(text, q || heading);
    out.innerHTML = `<div class="sec"><div class="scorehead"><div class="bigscore" style="color:${scoreCol(s.score)}">${s.score}<small>/100</small></div><div><h2 style="margin:0">${verdictOf(s.score)}</h2><p class="muted" style="margin:6px 0 0">${fmt(s.words)} mots, ${fmt(s.sentences)} phrase${s.sentences > 1 ? 's' : ''}. Estimation à partir de ce que les IA reprennent le plus souvent.</p></div></div></div>
      <div class="sec words"><div class="card"><h3>Points vérifiés</h3>${checksHtml(s)}</div>
      <div class="card"><h3>Version plus citable</h3><p class="muted" style="font-size:14px">Une IA réécrit le passage selon ces règles, sans inventer : les chiffres manquants sont signalés « à compléter ».</p><div class="toolbar"><button class="btn" id="ciRw" type="button">Réécrire pour être cité</button></div><div id="ciRwOut"></div></div></div>`;
    $('#ciRw', out).addEventListener('click', () => rewrite($('#ciRwOut', out), $('#ciRw', out), text, q || heading, s));
  }
  async function rewrite(box, btn, text, q, before) {
    if (!(await aiReady())) { box.innerHTML = '<p class="muted">Ajoutez une clé Claude ou ChatGPT dans le Radar IA pour obtenir la réécriture. Les points ci-contre suffisent pour la faire vous-même.</p>'; return; }
    btn.disabled = true; btn.textContent = 'Réécriture…';
    const prompt = `Réécris ce passage pour qu'un assistant IA (ChatGPT, Perplexity, Claude, Gemini) puisse le citer tel quel${q ? ` en réponse à la question : « ${q} »` : ''}.
Règles :
- première phrase : la réponse directe, moins de 30 mots, qui reprend les mots de la question ;
- des faits précis et vérifiables, des noms précis ; phrases de moins de 22 mots ; ton neutre, sans superlatif ni « nous » ;
- 60 à 150 mots ; même langue que le passage ;
- n'invente AUCUN fait : si une donnée utile manque, écris [à compléter : ce qu'il faut ajouter].
Réponds uniquement en JSON : {"rewrite":"…","changes":["ce que tu as changé, en une ligne", "…"]}

Passage :
${text.slice(0, 6000)}`;
    const r = await api.aiText({ prompt, maxTokens: 1500, json: true });
    btn.disabled = false; btn.textContent = 'Réécrire à nouveau';
    if (!r.ok) { box.innerHTML = `<p class="err">${esc(r.error)}</p>`; return; }
    const j = r.json && r.json.rewrite ? r.json : { rewrite: r.text, changes: [] };
    const after = scorePassage(j.rewrite, q);
    box.innerHTML = `<p class="muted" style="font-size:13px">Note : ${before.score} → <b style="color:${scoreCol(after.score)}">${after.score}</b>/100</p><div class="quote">${esc(j.rewrite).replace(/\[à compléter[^\]]*\]/gi, (m) => `<mark>${m}</mark>`)}</div>
      ${(j.changes || []).length ? `<ul class="minilist">${j.changes.slice(0, 6).map((c) => `<li>${esc(c)}</li>`).join('')}</ul>` : ''}<div class="toolbar"><button class="ghostbtn" id="ciCopy" type="button">Copier</button></div>`;
    $('#ciCopy', box).addEventListener('click', () => copy(j.rewrite));
  }
  function showPage(out, pt, blocks, q) {
    const avg = Math.round(blocks.reduce((s, b) => s + b.s.score, 0) / blocks.length);
    const strong = blocks.filter((b) => b.s.score >= 75).length;
    const sorted = [...blocks].sort((a, b) => a.s.score - b.s.score);
    out.innerHTML = `<div class="sec"><div class="scorehead"><div class="bigscore" style="color:${scoreCol(avg)}">${avg}<small>/100</small></div><div><h2 style="margin:0">${esc(pt.title || pt.url)}</h2><p class="muted" style="margin:6px 0 0">${fmt(blocks.length)} passages lus, ${fmt(strong)} très citables. Les plus faibles en premier.</p></div></div></div>
      <div class="sec">${sorted.slice(0, 25).map((b, i) => `<div class="card pass"><div class="passhead"><b style="color:${scoreCol(b.s.score)}">${b.s.score}</b><div><h3>${esc(b.heading || 'Sans intertitre')}</h3><p class="muted">${esc(b.text.slice(0, 220))}${b.text.length > 220 ? '…' : ''}</p></div><button class="ghostbtn" type="button" data-pi="${i}">Détail et réécriture</button></div></div>`).join('')}</div>`;
    $$('[data-pi]', out).forEach((btn) => btn.addEventListener('click', () => { const b = sorted[+btn.dataset.pi]; const box = document.createElement('div'); btn.closest('.card').after(box); btn.remove(); showPassage(box, b.text, q, b.heading); }));
  }

  // =====================================================================================
  // Radars enregistrés (partagés par plusieurs outils)
  // =====================================================================================
  async function radars() { try { return await api.radarList(); } catch { return []; } }
  async function radarPicker(el, id, onPick, emptyMsg) {
    const list = await radars();
    if (!list.length) { el.innerHTML = `<div class="card"><p>${esc(emptyMsg || 'Créez d’abord un radar dans « Radar IA » : cet outil s’appuie sur les réponses des IA.')}</p><div class="toolbar"><button class="btn" type="button" id="goRadar">Ouvrir le Radar IA</button></div></div>`; $('#goRadar', el).addEventListener('click', () => $('#radarBtn').click()); return; }
    el.innerHTML = `<label class="opt" style="max-width:420px"><span>Radar</span><select class="field" id="${id}">${list.map((p) => `<option value="${esc(p.id)}">${esc(p.brand)} · ${esc(p.site || '')}</option>`).join('')}</select></label><div id="${id}Out"></div>`;
    const go = async () => { const p = await api.radarLoad($('#' + id, el).value); onPick(p, $('#' + id + 'Out', el)); };
    $('#' + id, el).addEventListener('change', go); go();
  }
  const lastRun = (p) => [...(p.runs || [])].reverse().find((r) => r.summary);
  const lastDetailedRun = (p) => [...(p.runs || [])].reverse().find((r) => r.results && r.results.length);

  // =====================================================================================
  // 2. OÙ ÊTRE CITÉ : les sources que les IA utilisent à votre place
  // =====================================================================================
  const KINDS = [
    ['forum', 'Forum / communauté', /(^|\.)(reddit|quora|stackexchange|stackoverflow|discord|discourse|jeuxvideo|doctissimo|routard|hardware|commentcamarche|01net|futura-sciences)\.|forum|community|communaute/i, 'Répondre utilement dans le fil (sans publicité), en citant votre page qui traite la question.', 1],
    ['avis', 'Site d’avis', /(^|\.)(trustpilot|g2|capterra|getapp|appvizer|avis-verifies|yelp|tripadvisor|sitejabber|softwareadvice)\./i, 'Créer ou compléter votre fiche, puis demander des avis à vos clients satisfaits.', 1],
    ['annuaire', 'Annuaire / boutique d’apps', /(^|\.)(producthunt|alternativeto|saashub|crunchbase|apps\.apple|play\.google|betalist|indiehackers|pagesjaunes|linkedin|f6s|uneed|toolify|theresanaiforthat|futurepedia)\./i, 'Créer la fiche de votre produit avec une description claire et un lien vers votre site.', 1],
    ['video', 'Vidéo', /(^|\.)(youtube|youtu|tiktok|vimeo|dailymotion)\./i, 'Publier une courte vidéo qui répond à la même question, avec votre site dans la description.', 2],
    ['wiki', 'Encyclopédie', /(^|\.)(wikipedia|wikidata|fandom|wikivoyage|wiktionary)\./i, 'Vérifier que les informations sur votre domaine y sont justes ; n’ajoutez votre marque que si elle est notable et sourcée.', 3],
  ];
  const COMPARE = /\b(meilleur|meilleures|top\s?\d+|comparatif|classement|alternative|alternatives|versus|vs\.?|best|ranking|review|avis|test)\b/i;
  function classify(src) {
    for (const [k, label, re, action, effort] of KINDS) if (re.test(src.domain + '.')) return { kind: k, label, action, effort };
    const titles = (src.urls || []).map((u) => u.title + ' ' + u.url).join(' ');
    if (COMPARE.test(titles)) return { kind: 'comparatif', label: 'Comparatif / classement', action: 'Écrire à l’auteur pour être ajouté au comparatif, avec ce qui vous distingue en une phrase.', effort: 2 };
    return { kind: 'media', label: 'Média / blog', action: 'Proposer un témoignage, une donnée inédite ou un article invité sur le même sujet.', effort: 3 };
  }
  function openSources(el) {
    el.innerHTML = `<div class="radar"><span class="label">Où être cité</span><h1>Les sources que les IA citent à votre place</h1>
      <p class="lede">Quand ChatGPT ou Perplexity répondent à vos clients, ils s’appuient sur des forums, des comparatifs, des sites d’avis. Voici ceux qui comptent dans votre domaine, et ce qu’il faut y faire pour apparaître.</p><div id="srcPick" class="sec"></div></div>`;
    radarPicker($('#srcPick', el), 'srcSel', (p, out) => showSources(p, out));
  }
  function showSources(p, out) {
    const run = lastRun(p);
    if (!run) { out.innerHTML = '<p class="empty">Ce radar n’a pas encore été lancé. Lancez-le depuis « Radar IA ».</p>'; return; }
    const srcs = (run.summary.sources || []).filter((s) => !s.own && !s.competitor).map((s) => ({ ...s, ...classify(s) }));
    const prio = srcs.map((s) => ({ ...s, prio: (s.withoutBrand * 2 + s.withCompetitors + s.providers.length * 2 + s.count) / s.effort })).sort((a, b) => b.prio - a.prio);
    const present = srcs.filter((s) => s.withBrand > 0).length;
    const byKind = {}; for (const s of srcs) byKind[s.label] = (byKind[s.label] || 0) + s.count;
    out.innerHTML = `<div class="tiles" style="margin-top:20px"><div class="tile"><b>${fmt(srcs.length)}</b><span>sources utilisées par les IA</span></div><div class="tile"><b>${fmt(present)}</b><span>où vous êtes déjà présent</span></div><div class="tile bad"><b>${fmt(srcs.filter((s) => s.withBrand === 0 && s.withCompetitors > 0).length)}</b><span>où vos concurrents sont cités sans vous</span></div><div class="tile"><b>${esc(new Date(run.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' }))}</b><span>dernier passage du radar</span></div></div>
      <div class="sec"><h2>Par type de source</h2><div class="chips">${Object.entries(byKind).sort((a, b) => b[1] - a[1]).map(([k, v]) => `<span class="kchip">${esc(k)} <small>${v}</small></span>`).join('')}</div></div>
      <div class="sec"><h2>À faire, dans l’ordre <small>${fmt(Math.min(prio.length, 40))}</small></h2>${prio.length ? prio.slice(0, 40).map((s, i) => `<div class="card pass"><div class="passhead"><b class="rank">${i + 1}</b><div><h3>${esc(s.domain)} <span class="tag">${esc(s.label)}</span></h3>
        <p class="muted">Cité ${s.count} fois par ${s.providers.map((x) => PLABEL[x] || x).join(', ')} · ${s.withBrand ? `vous y êtes dans ${s.withBrand} réponse${s.withBrand > 1 ? 's' : ''}` : 'vous n’y êtes pas'}${s.withCompetitors ? ` · concurrents présents dans ${s.withCompetitors} réponse${s.withCompetitors > 1 ? 's' : ''}` : ''}</p>
        <p>${esc(s.action)}</p><div class="toolbar" style="margin:8px 0 0">${(s.urls || []).slice(0, 3).map((u) => T.ext(u.url, (u.title || u.url).slice(0, 70))).join(' ')}</div></div>
        <button class="ghostbtn" type="button" data-pitch="${i}">Rédiger le message</button></div></div>`).join('') : '<p class="empty">Aucune source externe dans les réponses : relancez le radar avec plus de questions.</p>'}</div>`;
    T.bindExt(out);
    $$('[data-pitch]', out).forEach((b) => b.addEventListener('click', () => pitch(p, prio[+b.dataset.pitch])));
  }
  async function pitch(p, s) {
    const page = (s.urls || [])[0] || { url: 'https://' + s.domain, title: s.domain };
    const base = s.kind === 'forum'
      ? `Bonjour,\n\nJe tombe sur cette discussion (« ${page.title || 'votre question'} »). [Votre réponse utile en 3 ou 4 phrases, sans publicité.]\n\nJ’ai détaillé le sujet ici si ça peut aider : ${p.site}\n`
      : `Bonjour,\n\nJ’ai lu « ${page.title || s.domain} » (${page.url}), très utile.\n\nJe vous écris pour vous présenter ${p.brand} (${p.site}) : [ce qui vous distingue, en une phrase]. ${s.kind === 'comparatif' ? 'Pensez-vous qu’il aurait sa place dans votre sélection ? ' : ''}Je peux vous donner un accès gratuit pour le tester, ou des chiffres inédits sur [sujet].\n\nBonne journée,\n[Prénom]`;
    const close = modal(`<h2>Message pour ${esc(s.domain)}</h2><p class="muted">${esc(s.action)}</p><textarea class="field" id="ptText" rows="12">${esc(base)}</textarea><div class="toolbar" style="margin-top:12px"><button class="btn" id="ptCopy" type="button">Copier</button><button class="ghostbtn" id="ptAi" type="button">Personnaliser avec l’IA</button><button class="ghostbtn" data-close type="button">Fermer</button></div><p class="err" id="ptErr"></p>`, (m) => {
      $('#ptCopy', m).addEventListener('click', () => copy($('#ptText', m).value));
      $('#ptAi', m).addEventListener('click', async () => {
        if (!(await aiReady())) { $('#ptErr', m).textContent = 'Ajoutez une clé Claude ou ChatGPT dans le Radar IA.'; return; }
        $('#ptAi', m).disabled = true; $('#ptAi', m).textContent = 'Rédaction…';
        const r = await api.aiText({ prompt: `Écris un message court (120 mots max), en français, chaleureux et sans flagornerie, pour ${s.kind === 'forum' ? 'répondre dans une discussion de forum de façon réellement utile, en mentionnant la marque une seule fois à la fin' : 'demander à l’auteur de cette page d’ajouter ou de mentionner la marque'}.\nPage : ${page.title} (${page.url})\nMarque : ${p.brand} (${p.site})${p.description ? '\nActivité : ' + p.description : ''}\nLaisse entre crochets ce que tu ne sais pas. Réponds uniquement par le message.`, maxTokens: 700 });
        $('#ptAi', m).disabled = false; $('#ptAi', m).textContent = 'Personnaliser avec l’IA';
        if (r.ok) $('#ptText', m).value = r.text; else $('#ptErr', m).textContent = r.error;
      });
    });
    void close;
  }

  // =====================================================================================
  // 3. VEILLE IA : alerte quand une IA commence ou arrête de vous recommander
  // =====================================================================================
  const WATCH = 'aiwatch';
  function cellsOf(run) {
    const m = new Map();
    for (const r of run.results || []) if (r.ok && r.analysis) m.set(r.provider + '\u0000' + r.question, r.analysis);
    return m;
  }
  /** Ce qui a changé entre deux passages du radar. */
  function compareRuns(prev, last, p) {
    const a = cellsOf(prev), b = cellsOf(last);
    const gained = [], lost = [];
    for (const [k, an] of b) { const old = a.get(k); if (!old) continue; const [prov, q] = k.split('\u0000'); if (an.brand.mentioned && !old.brand.mentioned) gained.push({ provider: prov, question: q, pos: an.brand.pos }); if (!an.brand.mentioned && old.brand.mentioned) lost.push({ provider: prov, question: q }); }
    const sp = prev.summary || {}, sl = last.summary || {};
    const rankOf = (s) => Object.fromEntries((s.ranking || []).map((r) => [r.name, r.share]));
    const rp = rankOf(sp), rl = rankOf(sl);
    const overtook = (sl.ranking || []).filter((r) => !r.own && r.share > (sl.share || 0) && !((rp[r.name] || 0) > (sp.share || 0))).map((r) => r.name);
    const fell = (sl.ranking || []).filter((r) => !r.own && (rp[r.name] || 0) > (sp.share || 0) && r.share <= (sl.share || 0)).map((r) => r.name);
    const providers = Object.keys(sl.providers || {}).map((k) => ({ provider: k, before: (sp.providers || {})[k] ? sp.providers[k].share : null, after: sl.providers[k].share })).filter((x) => x.before != null && Math.abs(x.after - x.before) >= 10);
    const delta = Math.round(((sl.share || 0) - (sp.share || 0)) * 10) / 10;
    const alerts = [];
    if (Math.abs(delta) >= 5) alerts.push(`part de voix ${delta > 0 ? 'en hausse' : 'en baisse'} : ${pct(sp.share)} → ${pct(sl.share)}`);
    if (gained.length) alerts.push(`${gained.length} nouvelle${gained.length > 1 ? 's' : ''} recommandation${gained.length > 1 ? 's' : ''}`);
    if (lost.length) alerts.push(`${lost.length} recommandation${lost.length > 1 ? 's' : ''} perdue${lost.length > 1 ? 's' : ''}`);
    for (const n of overtook) alerts.push(`${n} vous dépasse`);
    for (const n of fell) alerts.push(`vous repassez devant ${n}`);
    void rl; void p;
    return { delta, gained, lost, overtook, fell, providers, alerts, from: prev.date, to: last.date };
  }
  let ticking = false;
  async function watchTick() {
    const R = window.__vxRadar; if (!R || ticking) return;
    ticking = true;
    try {
      const st = (await T.load(WATCH)) || { projects: {}, alerts: [] };
      for (const [id, cfg] of Object.entries(st.projects || {})) {
        if (!cfg.on) continue;
        let p; try { p = await api.radarLoad(id); } catch { continue; }
        const lr = (p.runs || []).slice(-1)[0];
        if (!lr || Date.now() - new Date(lr.date).getTime() >= (cfg.days || 7) * 86400000) {
          try { await R.runProject(p, { silent: true }); } catch {}
          try { p = await api.radarLoad(id); } catch { continue; }
        }
        // un nouveau passage (lancé par la veille, à la main ou par le radar quotidien) : on compare au précédent
        const runs = (p.runs || []).filter((r) => r.results && r.results.length);
        const last = runs[runs.length - 1];
        if (last && last.date !== cfg.lastSeen) {
          if (runs.length >= 2 && cfg.lastSeen) {
            const c = compareRuns(runs[runs.length - 2], last, p);
            st.alerts = [{ id, brand: p.brand, date: last.date, alerts: c.alerts, delta: c.delta, gained: c.gained.length, lost: c.lost.length }, ...(st.alerts || [])].slice(0, 60);
            if (c.alerts.length) api.notify(`VANTIX · ${p.brand} dans les IA`, c.alerts.slice(0, 3).join(' · '));
          }
          cfg.lastSeen = last.date;
        }
        await T.save(WATCH, st);
      }
    } finally { ticking = false; }
  }
  setTimeout(() => watchTick().catch(() => {}), 90 * 1000);
  setInterval(() => watchTick().catch(() => {}), 30 * 60 * 1000);

  async function openWatch(el) {
    const st = (await T.load(WATCH)) || { projects: {}, alerts: [] };
    const list = await radars();
    el.innerHTML = `<div class="radar"><span class="label">Veille IA</span><h1>Soyez prévenu quand les IA changent d’avis</h1>
      <p class="lede">VANTIX repose vos questions aux IA à intervalle régulier et vous alerte quand l’une d’elles commence ou arrête de vous recommander, ou quand un concurrent vous double.</p>
      ${list.length ? `<div class="sec"><h2>Radars surveillés</h2>${list.map((p) => { const c = st.projects[p.id] || {}; return `<div class="card keyrow2"><div><b>${esc(p.brand)}</b><p class="muted">${esc(p.site || '')}${p.lastDate ? ' · dernier passage le ' + esc(dateFr(p.lastDate)) : ''}</p></div>
        <select class="field" data-days="${esc(p.id)}" aria-label="Fréquence"><option value="7" ${(c.days || 7) === 7 ? 'selected' : ''}>Chaque semaine</option><option value="14" ${c.days === 14 ? 'selected' : ''}>Toutes les 2 semaines</option><option value="30" ${c.days === 30 ? 'selected' : ''}>Chaque mois</option></select>
        <label class="switch"><input type="checkbox" data-on="${esc(p.id)}" ${c.on ? 'checked' : ''}><span>${c.on ? 'Surveillé' : 'En pause'}</span></label>
        <button class="ghostbtn" type="button" data-cmp="${esc(p.id)}">Comparer les 2 derniers passages</button></div>`; }).join('')}
        <p class="muted" style="font-size:13px">La veille tourne tant que VANTIX est ouvert (même réduit). Activez « Ouvrir VANTIX au démarrage » dans Audits programmés pour qu’elle ne s’arrête jamais. Chaque passage utilise vos clés IA (quelques centimes).</p></div>
      <div id="wCmp"></div>
      <div class="sec"><h2>Dernières alertes</h2>${(st.alerts || []).length ? st.alerts.slice(0, 20).map((a) => `<div class="card pass"><div class="passhead"><b style="color:${a.delta > 0 ? 'var(--ok)' : a.delta < 0 ? 'var(--crit)' : 'var(--text-3)'}">${a.delta > 0 ? '+' : ''}${String(a.delta).replace('.', ',')}</b><div><h3>${esc(a.brand)} · ${esc(dateFr(a.date))}</h3><p class="muted">${a.alerts.length ? esc(a.alerts.join(' · ')) : 'Aucun changement notable'}</p></div></div></div>`).join('') : '<p class="empty">Aucune alerte pour l’instant.</p>'}</div>`
      : '<div class="card"><p>Créez d’abord un radar dans « Radar IA ».</p></div>'}</div>`;
    const save = () => T.save(WATCH, st);
    $$('[data-on]', el).forEach((c) => c.addEventListener('change', async () => { const id = c.dataset.on; const pp = list.find((x) => x.id === id); st.projects[id] = { lastSeen: pp && pp.lastDate ? pp.lastDate : null, ...(st.projects[id] || {}), on: c.checked, days: +($(`[data-days="${id}"]`, el).value) }; c.nextElementSibling.textContent = c.checked ? 'Surveillé' : 'En pause'; await save(); toast(c.checked ? 'Veille activée' : 'Veille en pause'); if (c.checked) setTimeout(() => watchTick().catch(() => {}), 3000); }));
    $$('[data-days]', el).forEach((s) => s.addEventListener('change', async () => { const id = s.dataset.days; st.projects[id] = { ...(st.projects[id] || {}), days: +s.value }; await save(); }));
    $$('[data-cmp]', el).forEach((b) => b.addEventListener('click', async () => {
      const p = await api.radarLoad(b.dataset.cmp);
      const runs = (p.runs || []).filter((r) => r.results && r.results.length);
      const box = $('#wCmp', el);
      if (runs.length < 2) { box.innerHTML = '<div class="sec"><p class="empty">Il faut au moins deux passages du radar pour comparer.</p></div>'; return; }
      const c = compareRuns(runs[runs.length - 2], runs[runs.length - 1], p);
      box.innerHTML = `<div class="sec"><h2>${esc(p.brand)} : du ${esc(dateFr(c.from))} au ${esc(dateFr(c.to))}</h2>
        <div class="tiles"><div class="tile ${c.delta < 0 ? 'bad' : c.delta > 0 ? 'good' : ''}"><b>${c.delta > 0 ? '+' : ''}${String(c.delta).replace('.', ',')} pts</b><span>part de voix</span></div><div class="tile good"><b>${fmt(c.gained.length)}</b><span>recommandations gagnées</span></div><div class="tile bad"><b>${fmt(c.lost.length)}</b><span>recommandations perdues</span></div></div>
        ${c.overtook.length ? `<p class="note">Vous dépassent désormais : <b>${esc(c.overtook.join(', '))}</b></p>` : ''}
        ${T.table(['IA', 'Question', 'Changement'], [...c.gained.map((g) => [esc(PLABEL[g.provider] || g.provider), esc(g.question), `<span style="color:var(--ok)">vous cite (${g.pos}ᵉ)</span>`]), ...c.lost.map((g) => [esc(PLABEL[g.provider] || g.provider), esc(g.question), '<span style="color:var(--crit)">ne vous cite plus</span>'])], 'Aucune question n’a changé.')}</div>`;
    }));
  }

  // =====================================================================================
  // 4. ERREURS DES IA SUR VOTRE MARQUE
  // =====================================================================================
  const PRICE = /(\d{1,5}(?:[.,]\d{1,2})?)\s?(€|euros?|eur\b|\$|usd)/gi;
  const prices = (t) => [...new Set([...String(t).matchAll(PRICE)].map((m) => parseFloat(m[1].replace(',', '.'))))];
  const KEYPAGE = /tarif|prix|pricing|price|plans?|offres?|abonnement|about|a-propos|qui-sommes|equipe|team|contact|faq|aide|help|fonctionnalit|features|produit|product|mentions/i;
  async function readBrandSite(site, log) {
    const origin = T.origin(site); if (!origin) throw new Error('Adresse du site invalide.');
    const home = await api.fetchPage({ url: origin + '/' });
    if (!home.ok || !home.body) throw new Error('Le site ne répond pas : ' + (home.error || home.status));
    const startHost = new URL(home.finalUrl || origin).hostname;
    const hp = VX.parse.analyzePage(home, { depth: 0, startHost, includeSubdomains: false });
    const links = [...new Set(hp.links.filter((l) => l.internal && l.kind === 'page').map((l) => l.url))];
    const picked = links.filter((u) => KEYPAGE.test(new URL(u).pathname)).slice(0, 9);
    const pages = [pageText(home.body, home.finalUrl || origin)];
    for (const u of picked) { const r = await api.fetchPage({ url: u }); if (r.ok && r.body && /html/i.test(r.contentType || '')) { pages.push(pageText(r.body, r.finalUrl || u)); log && log('lu : ' + u); } }
    return { origin, host: startHost.replace(/^www\./, ''), pages };
  }
  function openFacts(el) {
    T.load('brandfacts').then((saved) => {
      el.innerHTML = `<div class="radar"><span class="label">Erreurs des IA sur votre marque</span><h1>Ce que les IA disent de faux sur vous</h1>
        <p class="lede">Les IA inventent parfois des prix, des fonctionnalités ou des informations dépassées. VANTIX leur pose les questions de vos clients, compare leurs réponses à votre site, et prépare la page « faits officiels » qui les corrige.</p>
        <form class="rform" id="bfForm" novalidate><div class="grid2"><label class="opt"><span>Nom de la marque</span><input class="field" id="bfBrand" value="${esc(saved ? saved.brand : '')}" placeholder="SPOTIQ"></label>
        <label class="opt"><span>Site</span><input class="field" id="bfSite" value="${esc(saved ? saved.site : '')}" placeholder="getspotiq.com" spellcheck="false"></label></div>
        <p class="err" id="bfErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Lancer la vérification</button>${saved ? '<button class="ghostbtn" id="bfLast" type="button">Voir la dernière vérification</button>' : ''}</div></form><div id="bfOut"></div></div>`;
      if (saved) $('#bfLast', el).addEventListener('click', () => showFacts($('#bfOut', el), saved));
      $('#bfForm', el).addEventListener('submit', async (e) => {
        e.preventDefault();
        const brand = $('#bfBrand', el).value.trim(), site = $('#bfSite', el).value.trim();
        if (!brand || !T.origin(site)) { $('#bfErr', el).textContent = 'Indiquez le nom de la marque et l’adresse du site.'; return; }
        const keys = await api.keysStatus().catch(() => ({}));
        const provs = ['openai', 'anthropic', 'perplexity', 'gemini'].filter((k) => keys[k]);
        if (!provs.length) { $('#bfErr', el).textContent = 'Ajoutez au moins une clé IA dans le Radar IA (ChatGPT, Claude, Perplexity ou Gemini).'; return; }
        runFacts($('#bfOut', el), brand, site, provs);
      });
    });
  }
  async function runFacts(out, brand, site, provs) {
    const pg = T.progress(out, 'Vérification en cours'); pg.title(brand);
    try {
      pg.cur('Lecture de votre site…'); pg.bar(0.05);
      const s = await readBrandSite(site, pg.log);
      const siteText = s.pages.map((p) => `### ${p.url}\n${p.text.slice(0, 5000)}`).join('\n\n').slice(0, 40000);
      const qs = [`Qu’est-ce que ${brand} (${s.host}) ? À qui ça s’adresse, que propose ce service, et qui est derrière ?`, `Combien coûte ${brand} (${s.host}) ? Y a-t-il une version gratuite, et quelles sont les formules ?`, `${brand} (${s.host}) : quelles sont ses fonctionnalités principales, ses limites, et ses alternatives ?`];
      const answers = []; let done = 0; const total = qs.length * provs.length;
      await Promise.all(provs.map(async (prov) => { for (const q of qs) { if (pg.stopped) return; const r = await api.radarAsk({ provider: prov, question: q, lang: 'fr' }); done++; pg.bar(0.1 + 0.6 * (done / total)); pg.cur(`${PLABEL[prov]} : ${q}`); if (r.ok) answers.push({ provider: prov, question: q, text: r.text.slice(0, 3500), sources: (r.sources || []).slice(0, 8) }); else pg.log(`${PLABEL[prov]} : ${r.error}`); } }));
      if (!answers.length) throw new Error('Aucune IA n’a répondu : vérifiez vos clés.');
      pg.cur('Comparaison avec votre site…'); pg.bar(0.75);
      const sitePrices = prices(siteText);
      let check = null;
      if (await aiReady()) {
        const prompt = `Tu es vérificateur de faits. Voici le contenu officiel du site de la marque « ${brand} » (${s.host}), puis des réponses d'assistants IA à son sujet.
Pour CHAQUE affirmation factuelle des réponses qui concerne ${brand} (prix, formules, fonctionnalités, public visé, entreprise, fondateurs, pays, date de création, limites…), compare avec le site officiel.
verdict : "juste" (confirmé par le site), "faux" (contredit par le site), "imprécis" (partiellement juste ou dépassé), "invérifiable" (le site n'en dit rien).
gravite : "grave" si cela peut faire perdre un client (prix, gratuit/payant, fonctionnalité absente ou inventée, confusion avec une autre marque), "moyen", "faible".
N'utilise QUE le site officiel comme vérité. Réponds uniquement en JSON :
{"claims":[{"provider":"openai|anthropic|perplexity|gemini","claim":"…","verdict":"…","truth":"ce que dit le site (ou vide)","url":"page du site qui le prouve (ou vide)","gravite":"…"}],
 "facts":[{"label":"Prix","value":"…","url":"…"}],
 "faq":[{"q":"question qu'un client pose à une IA","a":"réponse officielle de 40 à 80 mots, tirée du site uniquement"}],
 "summary":"2 phrases"}
facts : 6 à 12 faits officiels clés (offre, prix, public, fonctionnalités, entreprise, contact). faq : 5 à 8 questions.

=== SITE OFFICIEL ===
${siteText}

=== RÉPONSES DES IA ===
${answers.map((a) => `[${a.provider}] Q : ${a.question}\n${a.text}`).join('\n\n')}`;
        const r = await api.aiText({ prompt, maxTokens: 6000, json: true });
        if (r.ok && r.json && Array.isArray(r.json.claims)) check = r.json; else pg.log('Vérification détaillée impossible : ' + (r.error || 'réponse illisible'));
      }
      if (!check) {
        // sans IA de vérification : on contrôle au moins les prix cités
        const claims = [];
        for (const a of answers) for (const pz of prices(a.text)) if (sitePrices.length && !sitePrices.some((x) => Math.abs(x - pz) < 0.01)) claims.push({ provider: a.provider, claim: `Prix cité : ${String(pz).replace('.', ',')} €`, verdict: 'faux', truth: 'Prix présents sur le site : ' + sitePrices.slice(0, 6).map((x) => String(x).replace('.', ',') + ' €').join(', '), url: '', gravite: 'grave' });
        check = { claims, facts: [], faq: [], summary: 'Contrôle limité aux prix : ajoutez une clé Claude ou ChatGPT pour une vérification complète.' };
      }
      const rec = { date: new Date().toISOString(), brand, site: s.origin, host: s.host, providers: provs, answers, ...check };
      await T.save('brandfacts', rec);
      showFacts(out, rec);
    } catch (e) { out.innerHTML = `<div class="card"><p class="err">${esc(e.message)}</p></div>`; }
  }
  function factsPage(rec) {
    const ld = { '@context': 'https://schema.org', '@graph': [
      { '@type': 'Organization', name: rec.brand, url: rec.site, description: (rec.facts || []).map((f) => f.label + ' : ' + f.value).join(' · ').slice(0, 500) },
      ...((rec.faq || []).length ? [{ '@type': 'FAQPage', mainEntity: rec.faq.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })) }] : []),
    ] };
    const today = new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
    const html = `<!-- Page « ${rec.brand} en bref » générée par VANTIX : à publier sur ${rec.host}/a-propos ou /faits -->
<section class="faits-officiels">
  <h1>${esc(rec.brand)} en bref : les faits officiels</h1>
  <p>Informations vérifiées, à jour au ${esc(today)}.</p>
  <dl>
${(rec.facts || []).map((f) => `    <dt>${esc(f.label)}</dt><dd>${esc(f.value)}</dd>`).join('\n')}
  </dl>
  <h2>Questions fréquentes</h2>
${(rec.faq || []).map((f) => `  <h3>${esc(f.q)}</h3>\n  <p>${esc(f.a)}</p>`).join('\n')}
</section>
<script type="application/ld+json">
${JSON.stringify(ld, null, 2)}
</script>`;
    const llms = `## ${rec.brand} : faits officiels (${today})\n${(rec.facts || []).map((f) => `- ${f.label} : ${f.value}`).join('\n')}\n\n### Questions fréquentes\n${(rec.faq || []).map((f) => `- ${f.q} ${f.a}`).join('\n')}\n`;
    return { html, llms };
  }
  function showFacts(out, rec) {
    const claims = rec.claims || [];
    const wrong = claims.filter((c) => c.verdict === 'faux' || c.verdict === 'imprécis');
    const verif = claims.filter((c) => c.verdict !== 'invérifiable');
    const acc = verif.length ? Math.round((verif.filter((c) => c.verdict === 'juste').length / verif.length) * 100) : null;
    const order = { grave: 0, moyen: 1, faible: 2 };
    const vcol = { faux: 'var(--crit)', 'imprécis': 'var(--warn)', juste: 'var(--ok)', 'invérifiable': 'var(--text-3)' };
    const byProv = {}; for (const c of verif) { const b = byProv[c.provider] || (byProv[c.provider] = { ok: 0, n: 0 }); b.n++; if (c.verdict === 'juste') b.ok++; }
    const fp = factsPage(rec);
    out.innerHTML = `<div class="sec"><div class="scorehead"><div class="bigscore" style="color:${acc == null ? 'var(--text-3)' : scoreCol(acc)}">${acc == null ? '–' : acc}<small>${acc == null ? '' : '%'}</small></div><div><h2 style="margin:0">${wrong.length ? `${wrong.length} erreur${wrong.length > 1 ? 's' : ''} sur ${esc(rec.brand)}` : 'Aucune erreur détectée'}</h2><p class="muted" style="margin:6px 0 0">${esc(rec.summary || '')} Vérifié le ${esc(dateFr(rec.date))}.</p></div></div>
      <div class="chips" style="margin-top:14px">${Object.entries(byProv).map(([k, v]) => `<span class="kchip">${esc(PLABEL[k] || k)} <small>${Math.round((v.ok / v.n) * 100)} % juste</small></span>`).join('')}</div></div>
      <div class="sec"><h2>Erreurs à corriger <small>${fmt(wrong.length)}</small></h2>${wrong.length ? [...wrong].sort((a, b) => (order[a.gravite] ?? 3) - (order[b.gravite] ?? 3)).map((c) => `<div class="card pass"><div class="passhead"><span class="tag" style="color:${vcol[c.verdict]}">${esc(c.verdict)}${c.gravite === 'grave' ? ' · grave' : ''}</span><div><h3>${esc(PLABEL[c.provider] || c.provider)} : « ${esc(c.claim)} »</h3>${c.truth ? `<p>Sur votre site : ${esc(c.truth)}</p>` : ''}${c.url ? `<p class="muted">${T.ext(c.url, c.url)}</p>` : ''}</div></div></div>`).join('') : '<p class="empty">Rien à corriger : les IA décrivent votre marque correctement.</p>'}</div>
      ${claims.length ? `<div class="sec"><h2>Toutes les affirmations vérifiées</h2>${T.table(['IA', 'Affirmation', 'Verdict'], claims.map((c) => [esc(PLABEL[c.provider] || c.provider), esc(c.claim), `<span style="color:${vcol[c.verdict] || 'inherit'}">${esc(c.verdict)}</span>`]), '', 420)}</div>` : ''}
      ${(rec.facts || []).length ? `<div class="sec"><h2>La page qui corrige les IA</h2><p class="muted">Publiez cette page sur votre site (par exemple /a-propos), ajoutez le bloc à votre llms.txt, puis relancez la vérification dans 2 à 4 semaines : les IA s’appuient sur les pages claires et datées.</p>
        <div class="toolbar"><button class="btn" id="bfExp" type="button">Enregistrer la page et le bloc llms.txt</button><button class="ghostbtn" id="bfCopy" type="button">Copier le HTML</button></div><pre class="code">${esc(fp.html)}</pre></div>` : ''}`;
    T.bindExt(out);
    const e1 = $('#bfExp', out); if (e1) e1.addEventListener('click', () => api.exportFolder('faits-officiels-' + rec.host, [{ rel: 'faits-officiels.html', content: fp.html }, { rel: 'bloc-llms.txt', content: fp.llms }, { rel: 'LISEZMOI.txt', content: `1. Copiez le contenu de faits-officiels.html dans une page de votre site (ex. ${rec.host}/a-propos).\n2. Ajoutez le contenu de bloc-llms.txt à la fin de votre fichier llms.txt.\n3. Relancez « Erreurs des IA » dans VANTIX dans 2 à 4 semaines.\n` }], 'Où enregistrer la page « faits officiels » ?').catch((x) => toast(x.message)));
    const e2 = $('#bfCopy', out); if (e2) e2.addEventListener('click', () => copy(fp.html));
  }

  // =====================================================================================
  // 10. SCORE PUBLIC : badge, carte à partager et page de score
  // =====================================================================================
  function badgeSvg(share, label = 'Cité par les IA') {
    const v = pct(share); const lw = 8 + label.length * 6.6, vw = 14 + v.length * 7.4, w = Math.round(lw + vw);
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="24" viewBox="0 0 ${w} 24" role="img" aria-label="${label} : ${v}"><title>${label} : ${v}</title><rect width="${w}" height="24" rx="6" fill="#111214"/><rect x="${Math.round(lw)}" width="${Math.round(vw)}" height="24" rx="6" fill="#ff6363"/><rect x="${Math.round(lw)}" width="8" height="24" fill="#ff6363"/><g font-family="Inter,Segoe UI,Helvetica,Arial,sans-serif" font-size="12"><text x="${Math.round(lw / 2)}" y="16" fill="#e6e6e6" text-anchor="middle">${label}</text><text x="${Math.round(lw + vw / 2)}" y="16" fill="#ffffff" font-weight="600" text-anchor="middle">${v}</text></g></svg>`;
  }
  function cardSvg(p, s) {
    const provs = Object.entries(s.providers || {}).slice(0, 4);
    return `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630"><defs><radialGradient id="g" cx="85%" cy="0%" r="80%"><stop offset="0" stop-color="#452324"/><stop offset="1" stop-color="#040506"/></radialGradient></defs><rect width="1200" height="630" fill="url(#g)"/>
<g font-family="Inter,Segoe UI,Helvetica,Arial,sans-serif"><text x="80" y="110" fill="#9c9c9d" font-size="26" letter-spacing="3">VISIBILITÉ DANS LES IA</text><text x="80" y="200" fill="#ffffff" font-size="64">${esc(p.brand)}</text>
<text x="80" y="390" fill="#ff6363" font-size="190" font-weight="500">${esc(pct(s.share))}</text><text x="80" y="450" fill="#c4c4c5" font-size="30">des réponses de ${provs.map(([k]) => PLABEL[k] || k).join(', ')} recommandent ${esc(p.brand)}</text>
${provs.map(([k, v], i) => `<g transform="translate(${80 + i * 270} 520)"><rect width="250" height="64" rx="12" fill="#111214" stroke="#363739"/><text x="20" y="40" fill="#e6e6e6" font-size="22">${PLABEL[k] || k}</text><text x="230" y="40" fill="#ffffff" font-size="22" text-anchor="end">${esc(pct(v.share))}</text></g>`).join('')}
<text x="1120" y="110" fill="#6a6b6c" font-size="20" text-anchor="end">${esc(new Date().toLocaleDateString('fr-FR'))} · mesuré avec VANTIX</text></g></svg>`;
  }
  function svgToPng(svg, w, h) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => { const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(img, 0, 0, w, h); resolve(c.toDataURL('image/png').split(',')[1]); };
      img.onerror = () => reject(new Error('Image impossible à créer'));
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    });
  }
  function scorePage(p, s, run) {
    return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(p.brand)} dans les IA : ${esc(pct(s.share))}</title>
<meta name="description" content="${esc(p.brand)} est recommandé dans ${esc(pct(s.share))} des réponses de ChatGPT, Claude, Perplexity et Gemini (mesure du ${esc(dateFr(run.date))}).">
<meta property="og:title" content="${esc(p.brand)} : ${esc(pct(s.share))} de visibilité dans les IA"><meta property="og:image" content="carte.png">
<style>body{margin:0;background:#040506;color:#e6e6e6;font:16px/1.6 Inter,-apple-system,Segoe UI,Roboto,sans-serif}main{max-width:760px;margin:0 auto;padding:64px 20px}.k{font:12px/1 ui-monospace,Menlo,monospace;letter-spacing:.1em;color:#9c9c9d;text-transform:uppercase}h1{font-weight:400;font-size:44px;margin:12px 0}.n{font-size:120px;color:#ff6363;line-height:1;margin:24px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin:32px 0}.c{background:#111214;border-radius:14px;padding:16px;box-shadow:rgba(255,255,255,.05) 0 1px 0 0 inset,rgba(255,255,255,.25) 0 0 0 1px}.c b{display:block;font-size:28px;font-weight:400;color:#fff}p.m{color:#9c9c9d;font-size:14px}</style></head>
<body><main><div class="k">Visibilité dans les IA</div><h1>${esc(p.brand)}</h1><div class="n">${esc(pct(s.share))}</div><p>des réponses des assistants IA recommandent ${esc(p.brand)}, sur ${fmt(s.answers)} réponses à de vraies questions de clients${s.rank ? `, ${s.rank === 1 ? 'au premier rang' : 'au rang ' + s.rank} face aux concurrents` : ''}.</p>
<div class="grid">${Object.entries(s.providers || {}).map(([k, v]) => `<div class="c">${PLABEL[k] || k}<b>${esc(pct(v.share))}</b></div>`).join('')}</div>
<p class="m">Mesure du ${esc(dateFr(run.date))} : ${fmt(new Set((run.results || []).map((r) => r.question)).size || s.answers)} questions posées à chaque IA, avec recherche web. Une réponse compte quand la marque y est nommée.</p></main></body></html>`;
  }
  function openBadge(el) {
    el.innerHTML = `<div class="radar"><span class="label">Score public</span><h1>Montrez que les IA vous recommandent</h1>
      <p class="lede">Un badge pour votre site, une carte à partager sur LinkedIn et une page de score : la preuve concrète, tirée de votre dernier Radar IA. Idéal pour rassurer vos clients et gagner des liens.</p><div id="bdPick" class="sec"></div></div>`;
    radarPicker($('#bdPick', el), 'bdSel', (p, out) => {
      const run = lastRun(p);
      if (!run) { out.innerHTML = '<p class="empty">Lancez d’abord ce radar depuis « Radar IA ».</p>'; return; }
      const s = run.summary, badge = badgeSvg(s.share), card = cardSvg(p, s);
      const embed = `<a href="https://${esc(VX.radar.hostOf(p.site))}/score-ia.html" title="Visibilité de ${esc(p.brand)} dans les IA"><img src="/badge-ia.svg" alt="${esc(p.brand)} est cité par les IA dans ${esc(pct(s.share))} des réponses" width="${badge.match(/width="(\d+)"/)[1]}" height="24"></a>`;
      out.innerHTML = `<div class="sec"><h2>Le badge</h2><div class="card" style="display:flex;align-items:center;gap:20px;flex-wrap:wrap"><div class="preview">${badge}</div><p class="muted" style="margin:0">À placer dans le pied de page de votre site.</p></div></div>
        <div class="sec"><h2>La carte à partager</h2><div class="card"><div class="preview wide">${card}</div></div></div>
        <div class="sec"><h2>Mise en ligne</h2><ol class="steps2"><li>Enregistrez le dossier ci-dessous.</li><li>Déposez <b>badge-ia.svg</b>, <b>score-ia.html</b> et <b>carte.png</b> à la racine de votre site.</li><li>Collez ce code dans le pied de page :</li></ol><pre class="code">${esc(embed)}</pre>
        <div class="toolbar"><button class="btn" id="bdExp" type="button">Enregistrer le badge, la carte et la page</button><button class="ghostbtn" id="bdCopy" type="button">Copier le code</button></div>
        <p class="muted" style="font-size:13px">Relancez le radar et réenregistrez le dossier quand votre score progresse : le badge se met à jour.</p></div>`;
      $('#bdCopy', out).addEventListener('click', () => copy(embed.replace(/&amp;/g, '&')));
      $('#bdExp', out).addEventListener('click', async () => {
        try {
          const png = await svgToPng(card, 1200, 630);
          await api.exportFolder('score-ia-' + VX.radar.hostOf(p.site), [{ rel: 'badge-ia.svg', content: badge }, { rel: 'carte.svg', content: card }, { rel: 'carte.png', content: png, base64: true }, { rel: 'score-ia.html', content: scorePage(p, s, run) }, { rel: 'code-a-coller.txt', content: embed.replace(/&amp;/g, '&') + '\n' }], 'Où enregistrer le badge et la carte ?');
        } catch (x) { toast(x.message); }
      });
    }, 'Créez d’abord un radar dans « Radar IA » : le score public s’appuie sur ses résultats.');
  }

  // ---------- déclaration des outils ----------
  T.register({ id: 'citation', label: 'Simulateur de citation', group: 'IA', icon: 'M7 8h10M7 12h6m-9 8 3-3h11a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14z', open: openCitation });
  T.register({ id: 'aisources', label: 'Où être cité', group: 'IA', icon: 'M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21zm0-9a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z', open: openSources });
  T.register({ id: 'brandfacts', label: 'Erreurs des IA', group: 'IA', icon: 'M12 9v4m0 4h.01M10.3 3.9 2.4 18a2 2 0 0 0 1.7 3h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z', open: openFacts });
  T.register({ id: 'aiwatch', label: 'Veille IA', group: 'IA', icon: 'M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0', open: openWatch });
  T.register({ id: 'badge', label: 'Score public', group: 'IA', icon: 'M12 15a6 6 0 1 0 0-12 6 6 0 0 0 0 12zm-3.5-1L7 22l5-3 5 3-1.5-8', open: openBadge });

  VX.geo = { pageText, scorePassage, classify, compareRuns, prices, badgeSvg, cardSvg, readBrandSite, aiReady, copy, radarPicker, lastRun };
})();
