// VANTIX — Contenu : optimiseur d'article, plan de contenu (gratuit), données structurées, maillage interne
(function () {
  'use strict';
  const VX = window.VX, U = VX.util, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T) return;
  const { $, $$, esc, toast, fmt } = UI;
  const csv = (rows) => '﻿' + rows.map((l) => l.map((c) => /[";\n,]/.test(String(c)) ? '"' + String(c).replace(/"/g, '""') + '"' : c).join(';')).join('\r\n');

  // =====================================================================================
  // 4. OPTIMISEUR D'ARTICLE
  // =====================================================================================
  /** Texte collé (Markdown simple, texte brut ou HTML) → HTML analysable */
  function draftToHtml(text, title) {
    const t = String(text || '').trim();
    if (/<(p|h[1-6]|div|article|ul|ol|table)\b/i.test(t)) return /<html/i.test(t) ? t : `<!doctype html><html><head><title>${esc(title || '')}</title></head><body><main>${t}</main></body></html>`;
    const inline = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+|\/[^)\s]*)\)/g, '<a href="$2">$1</a>');
    const out = []; let list = null, para = [];
    const flush = () => { if (para.length) { out.push('<p>' + inline(para.join(' ')) + '</p>'); para = []; } if (list) { out.push(`<${list.tag}>` + list.items.map((i) => '<li>' + inline(i) + '</li>').join('') + `</${list.tag}>`); list = null; } };
    let h1 = '';
    for (const raw of t.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line) { flush(); continue; }
      const h = line.match(/^(#{1,4})\s+(.*)$/);
      if (h) { flush(); const lvl = h[1].length; if (lvl === 1 && !h1) h1 = h[2]; out.push(`<h${lvl}>${inline(h[2])}</h${lvl}>`); continue; }
      const li = line.match(/^([-*•]|\d+[.)])\s+(.*)$/);
      if (li) { if (para.length) { out.push('<p>' + inline(para.join(' ')) + '</p>'); para = []; } const tag = /\d/.test(li[1]) ? 'ol' : 'ul'; if (!list || list.tag !== tag) { if (list) flush(); list = { tag, items: [] }; } list.items.push(li[2]); continue; }
      if (list) flush();
      // une ligne courte qui finit par « ? » est un intertitre de question
      if (line.length < 110 && /\?$/.test(line) && !para.length) { out.push(`<h2>${inline(line)}</h2>`); continue; }
      para.push(line);
    }
    flush();
    return `<!doctype html><html><head><title>${esc(title || h1 || '')}</title></head><body><main>${out.join('\n')}</main></body></html>`;
  }

  /** Note un article face à un mot-clé et à des pages de référence (concurrents). */
  function scoreArticle(p, keyword, refs) {
    const kw = [...T.terms(keyword)];
    const has = (s) => { const set = T.terms(s); return kw.length && kw.filter((w) => set.has(w)).length / kw.length >= 0.6; };
    const refWords = T.median(refs.map((r) => r.words)) || 0;
    const target = Math.max(800, Math.round(refWords * 1.1));
    const body = p.keywords.map(([w]) => w);
    const checks = [];
    const add = (ok, weight, label, tip) => checks.push({ ok: !!ok, weight, label, tip });
    add(has(p.title), 10, 'Le mot-clé est dans le title', 'Placez le mot-clé au début du title (50 à 60 caractères).');
    add(has(p.h1[0] || ''), 8, 'Le mot-clé est dans le titre H1', 'Reprenez le mot-clé dans le grand titre de la page.');
    add(has(p.geo.firstParagraph), 8, 'Le mot-clé apparaît dès le premier paragraphe', 'Répondez à la question dès les deux premières phrases, avec le mot-clé.');
    add(p.headings.filter((h) => h.level === 2).some((h) => has(h.text)), 5, 'Un intertitre reprend le sujet', 'Ajoutez un intertitre H2 qui contient le mot-clé ou une variante.');
    add(p.mainWordCount >= target * 0.8, 10, `Longueur suffisante (${fmt(p.mainWordCount)} mots, objectif ${fmt(target)})`, refWords ? `Les pages de référence font ${fmt(refWords)} mots en médiane : développez les points qui manquent (voir ci-dessous).` : 'Visez au moins 800 mots utiles.');
    add(p.geo.answerFirst, 8, 'La réponse arrive dès le début', 'Commencez par un paragraphe de 2 ou 3 phrases qui répond directement : c’est ce que reprennent les IA.');
    add(p.questionHeadings >= 2, 7, `Intertitres sous forme de questions (${p.questionHeadings})`, 'Formulez au moins 2 intertitres comme les questions que se posent les gens.');
    add((p.geo.qa || []).length >= 3 || p.schema.hasFAQ, 7, 'Une FAQ d’au moins 3 questions', 'Terminez par 3 à 6 questions-réponses courtes.');
    add(p.geo.lists + p.geo.tables > 0, 5, 'Listes ou tableau', 'Ajoutez une liste à puces ou un tableau comparatif : plus lisible, plus souvent cité.');
    add(p.geo.stats >= 3, 5, `Chiffres précis (${p.geo.stats})`, 'Donnez des chiffres : prix, durées, distances, pourcentages.');
    add(p.geo.sources >= 2, 6, `Sources externes (${p.geo.sources})`, 'Citez 2 sources fiables (sites officiels, études) avec un lien.');
    add(p.links.filter((l) => l.internal && l.kind === 'page').length >= 3, 5, 'Liens vers vos autres pages', 'Ajoutez au moins 3 liens vers vos pages proches.');
    add(p.readability == null || p.readability >= 45, 4, 'Lecture facile', 'Raccourcissez les phrases et les paragraphes.');
    add(!p.geo.longParagraphs, 4, 'Pas de paragraphe trop long', 'Coupez les paragraphes de plus de 120 mots.');
    add(p.geo.dated, 4, 'Date visible', 'Affichez la date de publication ou de mise à jour.');
    add(p.geo.author, 4, 'Auteur indiqué', 'Indiquez qui écrit : les moteurs et les IA valorisent l’expertise.');
    const total = checks.reduce((s, c) => s + c.weight, 0), got = checks.reduce((s, c) => s + (c.ok ? c.weight : 0), 0);
    // notions et intertitres des références absents de l'article
    const df = new Map();
    for (const r of refs) for (const w of new Set([...r.keywords.map(([x]) => x), ...T.terms(r.h2.join(' '))])) df.set(w, (df.get(w) || 0) + 1);
    const mine = new Set([...body, ...T.terms(p.headings.map((h) => h.text).join(' ') + ' ' + p.title)]);
    const notions = [...df.entries()].filter(([w, n]) => n >= Math.max(1, Math.ceil(refs.length / 2)) && !mine.has(w) && w.length > 3 && !kw.includes(w)).sort((a, b) => b[1] - a[1]).slice(0, 30).map(([w, n]) => ({ word: w, refs: n }));
    const myH = T.terms(p.headings.map((h) => h.text).join(' '));
    const headings = [];
    for (const r of refs) for (const h of r.h2) { const s = T.terms(h); if (s.size >= 2 && [...s].filter((w) => myH.has(w)).length / s.size < 0.5 && !headings.some((x) => x.text.toLowerCase() === h.toLowerCase())) headings.push({ text: h, site: T.host(r.url) }); }
    return { score: Math.round((got / total) * 100), checks, notions, headings: headings.slice(0, 30), target, refWords };
  }

  async function openOptimizer(el) {
    const comp = await T.load('competitors');
    el.innerHTML = `<div class="radar"><span class="label">Optimiseur d’article</span><h1>Votre article est-il prêt pour Google et les IA ?</h1>
      <p class="lede">Collez un brouillon ou l’adresse d’une page, indiquez le mot-clé visé : VANTIX le note, le compare aux pages qui traitent le même sujet et vous dit quoi ajouter.</p>
      <form class="rform" id="opForm" novalidate>
        <div class="grid2"><label class="opt"><span>Mot-clé visé</span><input class="field" id="opKw" placeholder="que faire à lisbonne en 3 jours"></label>
        <label class="opt"><span>Adresse de la page (ou collez le texte ci-dessous)</span><input class="field" id="opUrl" placeholder="https://monsite.fr/article" spellcheck="false"></label></div>
        <label class="opt"><span>Texte de l’article (Markdown, texte ou HTML)</span><textarea class="field" id="opText" rows="10" placeholder="# Que faire à Lisbonne en 3 jours&#10;&#10;Trois jours suffisent pour…&#10;&#10;## Jour 1 : l’Alfama&#10;…"></textarea></label>
        <label class="opt"><span>Pages de référence à battre (facultatif, une adresse par ligne : par exemple les 3 premiers résultats Google)</span><textarea class="field" id="opRefs" rows="3" spellcheck="false"></textarea></label>
        <p class="muted" style="font-size:13px;margin:0">${comp ? `Les pages de vos concurrents lues le ${new Date(comp.date).toLocaleDateString('fr-FR')} servent aussi de référence quand elles traitent le même sujet.` : 'Astuce : lancez d’abord l’outil Concurrents, ses pages servent ensuite de référence automatiquement.'}</p>
        <p class="err" id="opErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Analyser l’article</button></div>
      </form><div id="opOut"></div></div>`;
    $('#opForm', el).addEventListener('input', () => { $('#opErr', el).textContent = ''; });
    $('#opForm', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const kw = $('#opKw', el).value.trim(), url = $('#opUrl', el).value.trim(), text = $('#opText', el).value.trim();
      if (!kw) { $('#opErr', el).textContent = 'Indiquez le mot-clé visé.'; return; }
      if (!url && !text) { $('#opErr', el).textContent = 'Collez le texte de l’article ou indiquez son adresse.'; return; }
      const btn = $('#opForm button[type=submit]', el); btn.disabled = true; btn.textContent = 'Analyse…';
      try {
        let res;
        if (text) res = { url: 'https://exemple.local/brouillon', finalUrl: 'https://exemple.local/brouillon', status: 200, contentType: 'text/html', body: draftToHtml(text, ''), bytes: text.length, headers: {} };
        else { res = await api.fetchPage({ url: T.origin(url) ? (/^https?:/i.test(url) ? url : 'https://' + url) : url }); if (!res.ok || !res.body) throw new Error('Page illisible : ' + (res.error || res.status)); }
        const page = VX.parse.analyzePage(res, { depth: 0, startHost: new URL(res.finalUrl || res.url).hostname, includeSubdomains: false });
        const refs = [];
        const refUrls = $('#opRefs', el).value.split(/\s+/).filter((u) => /^https?:\/\//i.test(u)).slice(0, 5);
        for (const u of refUrls) { const r = await api.fetchPage({ url: u }); if (r.ok && r.body) refs.push(T.slim(VX.parse.analyzePage(r, { depth: 0, startHost: new URL(r.finalUrl || u).hostname, includeSubdomains: false }))); }
        if (comp && comp.pagesForRefs) { const kt = T.terms(kw); for (const p of comp.pagesForRefs) { const s = T.terms(p.h1 || p.title); const inter = [...kt].filter((w) => s.has(w)).length; if (kt.size && inter / kt.size >= 0.5) refs.push(p); } }
        showScore($('#opOut', el), page, kw, refs.slice(0, 12));
        $('#opOut', el).scrollIntoView({ behavior: 'smooth', block: 'start' });
      } catch (err) { $('#opErr', el).textContent = err.message; }
      btn.disabled = false; btn.textContent = 'Analyser l’article';
    });
  }
  function showScore(out, page, kw, refs) {
    const r = scoreArticle(page, kw, refs);
    const col = r.score >= 80 ? 'var(--ok)' : r.score >= 55 ? 'var(--warn)' : 'var(--crit)';
    out.innerHTML = `<div class="sec"><div class="scorehead"><div class="bigscore" style="color:${col}">${r.score}<small>/100</small></div><div><h2 style="margin:0">${r.score >= 80 ? 'Prêt à publier' : r.score >= 55 ? 'Bonne base, quelques ajouts' : 'À retravailler'}</h2><p class="muted" style="margin:6px 0 0">${refs.length ? `Comparé à ${refs.length} page${refs.length > 1 ? 's' : ''} de référence (${fmt(r.refWords)} mots en médiane).` : 'Aucune page de référence : la note se base sur les bonnes pratiques.'}</p></div></div></div>
      <div class="sec words"><div class="card"><h3>Points vérifiés</h3><ul class="checks2">${r.checks.map((c) => `<li class="${c.ok ? 'ok' : 'ko'}"><span class="ic">${c.ok ? '✓' : '✕'}</span><div><b>${esc(c.label)}</b>${c.ok ? '' : `<p>${esc(c.tip)}</p>`}</div></li>`).join('')}</ul></div>
      <div class="card"><h3>Notions à aborder</h3>${r.notions.length ? `<div class="chips">${r.notions.map((n) => `<span class="kchip">${esc(n.word)} <small>${n.refs}</small></span>`).join('')}</div><p class="muted" style="font-size:13px;margin-top:10px">Mots présents dans la plupart des pages de référence et absents de votre article.</p>` : '<p class="empty">Rien de notable, ou pas de page de référence.</p>'}
        <h3 style="margin-top:22px">Intertitres des pages de référence</h3>${r.headings.length ? `<ul class="bul">${r.headings.map((h) => `<li>${esc(h.text)} <span class="muted">· ${esc(h.site)}</span></li>`).join('')}</ul>` : '<p class="empty">Aucun intertitre manquant.</p>'}</div></div>`;
  }

  // =====================================================================================
  // 5. PLAN DE CONTENU (gratuit : suggestions de recherche Google + concurrents + Search Console)
  // =====================================================================================
  const MODIFIERS = { fr: ['comment', 'pourquoi', 'quel', 'meilleur', 'pas cher', 'avis', 'ou', 'quand', 'combien', 'vs', 'gratuit', 'idée'], en: ['how', 'why', 'best', 'cheap', 'vs', 'review', 'where', 'when', 'what', 'free'], es: ['cómo', 'mejor', 'barato', 'dónde', 'cuándo', 'qué', 'gratis'] };
  async function suggest(q, lang) {
    const r = await api.fetchPage({ url: `https://suggestqueries.google.com/complete/search?client=firefox&ie=utf-8&oe=utf-8&hl=${lang}&q=${encodeURIComponent(q)}` });
    try { const j = JSON.parse(r.body || '[]'); return Array.isArray(j[1]) ? j[1].map(String) : []; } catch { return []; }
  }
  function clusterKeywords(list) {
    const groups = [];
    for (const k of list) {
      const s = T.terms(k.q); if (!s.size) continue;
      let g = groups.find((x) => { const inter = [...s].filter((w) => x.set.has(w)).length; return inter / Math.min(s.size, x.set.size) >= 0.75; });
      if (!g) { g = { set: s, items: [] }; groups.push(g); }
      g.items.push(k);
    }
    return groups.map((g) => { const items = g.items.sort((a, b) => b.score - a.score); return { main: items[0].q, variants: items.slice(1, 8).map((x) => x.q), questions: items.filter((x) => /^(comment|pourquoi|quel|quelle|quels|ou|où|quand|combien|que |qu|est-ce|how|why|what|where|when|which|cómo|qué|dónde|cuándo)/i.test(x.q)).map((x) => x.q).slice(0, 6), score: items.reduce((s, x) => s + x.score, 0) }; }).sort((a, b) => b.score - a.score);
  }
  async function openPlan(el) {
    const saved = await T.load('plan');
    el.innerHTML = `<div class="radar"><span class="label">Plan de contenu</span><h1>Les articles à écrire, dans l’ordre</h1>
      <p class="lede">Donnez vos sujets : VANTIX récupère ce que les gens tapent vraiment dans Google, le croise avec vos concurrents et vos données Search Console, puis vous prépare un plan avec un brief par article. Gratuit.</p>
      <form class="rform" id="plForm" novalidate>
        <div class="grid2"><label class="opt"><span>Votre site</span><input class="field" id="plSite" value="${esc(saved ? saved.site : '')}" placeholder="getspotiq.com" spellcheck="false"></label>
        <label class="opt"><span>Langue</span><select class="field" id="plLang"><option value="fr">Français</option><option value="en">Anglais</option><option value="es">Espagnol</option></select></label></div>
        <label class="opt"><span>Sujets de départ, un par ligne</span><textarea class="field" id="plSeeds" rows="5" placeholder="week-end pas cher&#10;que faire à lisbonne&#10;road trip portugal">${esc(saved ? saved.seeds.join('\n') : '')}</textarea></label>
        <p class="err" id="plErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Construire le plan</button>${saved ? `<button class="ghostbtn" id="plLast" type="button">Revoir le plan du ${new Date(saved.date).toLocaleDateString('fr-FR')}</button>` : ''}</div></form></div>`;
    if (saved) $('#plLang', el).value = saved.lang || 'fr';
    const last = $('#plLast', el); if (last) last.addEventListener('click', () => showPlan(el, saved));
    $('#plForm', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const seeds = $('#plSeeds', el).value.split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 15), lang = $('#plLang', el).value, site = $('#plSite', el).value.trim();
      if (!seeds.length) { $('#plErr', el).textContent = 'Ajoutez au moins un sujet.'; return; }
      const pg = T.progress(el, 'Plan de contenu'); pg.title('Recherche des mots-clés');
      const found = new Map();
      const addK = (q, w) => { q = q.toLowerCase().trim(); if (q.length < 4) return; found.set(q, { q, score: (found.get(q) ? found.get(q).score : 0) + w }); };
      const mods = MODIFIERS[lang] || MODIFIERS.fr;
      const queries = seeds.flatMap((s) => [s, ...mods.map((m) => (/^(pas cher|avis|vs|gratuit|idée|cheap|review|free|barato|gratis)$/.test(m) ? `${s} ${m}` : `${m} ${s}`))]);
      for (let i = 0; i < queries.length; i++) {
        if (pg.stopped) break;
        pg.bar(i / queries.length); pg.cur(queries[i]);
        const list = await suggest(queries[i], lang);
        list.forEach((x, rank) => addK(x, 10 - rank));
        await U.sleep(150);
      }
      pg.log(`${found.size} recherches réelles trouvées`);
      const gsc = await T.load('gsc'), comp = await T.load('competitors');
      const gscQ = gsc ? gsc.data.queries : [];
      for (const q of gscQ) if (q.position > 7 && q.impressions >= 10) addK(q.key, Math.min(30, q.impressions / 20));
      let clusters = clusterKeywords([...found.values()]);
      // déjà couvert par votre site ? (pages lues lors de l'analyse des concurrents)
      const own = comp && comp.ownTitles ? comp.ownTitles.map((t) => T.terms(t)) : [];
      clusters = clusters.map((c) => {
        const s = T.terms(c.main);
        const covered = own.some((o) => [...s].filter((w) => o.has(w)).length / Math.max(1, s.size) >= 0.75);
        const gq = gscQ.find((q) => q.key.toLowerCase() === c.main);
        const rival = comp ? comp.topics.find((t) => { const ts = T.terms(t.label); return [...s].filter((w) => ts.has(w)).length / Math.max(1, s.size) >= 0.6; }) : null;
        return { ...c, covered, gsc: gq ? { position: gq.position, impressions: gq.impressions } : null, rival: rival ? { sites: rival.sites, h2: [] } : null, priority: Math.round(c.score + (rival ? 25 * rival.sites.length : 0) + (gq ? 20 : 0) - (covered ? 40 : 0)) };
      }).sort((a, b) => b.priority - a.priority).slice(0, 60);
      const rec = { date: new Date().toISOString(), site, lang, seeds, clusters };
      await T.save('plan', rec); showPlan(el, rec);
    });
  }
  function brief(c, lang) {
    const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
    const outline = [...new Set([...c.questions.map(cap), ...c.variants.filter((v) => !c.questions.includes(v)).slice(0, 3).map(cap)])].filter((h) => h.toLowerCase() !== c.main.toLowerCase()).slice(0, 7);
    return `# ${cap(c.main)}\n\nMot-clé principal : ${c.main}\nVariantes à placer : ${c.variants.join(', ') || '—'}\nLongueur conseillée : 1 000 à 1 500 mots\n\n## L’essentiel (2 à 3 phrases qui répondent directement)\n\n${outline.map((h) => '## ' + h).join('\n')}\n\n## Questions fréquentes\n${(c.questions.length ? c.questions : c.variants.slice(0, 3)).map((q) => '- ' + cap(q) + (/\?$/.test(q) ? '' : ' ?')).join('\n')}\n\nÀ inclure : 2 sources fiables, 3 liens vers vos pages proches, des chiffres précis, une date de mise à jour.`;
  }
  function showPlan(el, rec) {
    el.innerHTML = `<header class="rhead"><div><span class="label">Plan de contenu · ${new Date(rec.date).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })}</span><h1>${fmt(rec.clusters.length)} articles à écrire</h1><p class="rmeta">${esc(rec.site || '')} · à partir de : ${rec.seeds.map(esc).join(', ')}</p></div>
      <div class="ractions"><button class="ghostbtn" id="plNew" type="button">Nouveau plan</button><button class="ghostbtn" id="plCsv" type="button">Exporter (CSV)</button><button class="btn" id="plMd" type="button">Exporter les briefs</button></div></header>
      <div class="tabbody"><div class="sec">${T.table(['Priorité', 'Article à écrire', 'Variantes', 'Signal'], rec.clusters.map((c, i) => [i + 1, `<button class="linkbtn" type="button" data-brief="${i}">${esc(c.main)}</button>${c.covered ? ' <span class="muted">(déjà traité ?)</span>' : ''}`, esc(c.variants.slice(0, 4).join(' · ')), [c.rival ? `traité par ${esc(c.rival.sites.join(', '))}` : '', c.gsc ? `vous êtes ${c.gsc.position.toLocaleString('fr-FR')}e sur Google` : '', c.questions.length ? `${c.questions.length} question${c.questions.length > 1 ? 's' : ''}` : ''].filter(Boolean).join(' · ')]), 'Aucun sujet trouvé.')}</div>
      <p class="muted" style="font-size:13px">Cliquez sur un article pour voir son brief : plan, questions et variantes, prêt à rédiger ou à confier.</p></div>`;
    $$('[data-brief]', el).forEach((b) => b.addEventListener('click', () => UI.modal(`<span class="label">Brief</span><pre class="brief">${esc(brief(rec.clusters[+b.dataset.brief], rec.lang))}</pre><div class="acts"><button class="ghostbtn" id="bCopy" type="button">Copier</button><button class="btn" data-close type="button">Fermer</button></div>`, (m) => { $('.modal-card').classList.add('wide'); $('#bCopy', m).addEventListener('click', () => navigator.clipboard.writeText(brief(rec.clusters[+b.dataset.brief], rec.lang)).then(() => toast('Brief copié'))); })));
    $('#plNew', el).addEventListener('click', () => openPlan(el));
    $('#plCsv', el).addEventListener('click', () => api.exportFile({ defaultName: 'plan-de-contenu.csv', content: csv([['Priorité', 'Article', 'Variantes', 'Questions', 'Déjà traité', 'Concurrents', 'Position Google'], ...rec.clusters.map((c, i) => [i + 1, c.main, c.variants.join(' | '), c.questions.join(' | '), c.covered ? 'peut-être' : 'non', c.rival ? c.rival.sites.join(' ') : '', c.gsc ? c.gsc.position : ''])]), filters: [{ name: 'CSV', extensions: ['csv'] }] }).catch((e) => toast(e.message)));
    $('#plMd', el).addEventListener('click', () => api.exportFile({ defaultName: 'briefs-articles.md', content: rec.clusters.map((c) => brief(c, rec.lang)).join('\n\n---\n\n'), filters: [{ name: 'Markdown', extensions: ['md'] }] }).catch((e) => toast(e.message)));
  }

  // =====================================================================================
  // 7. DONNÉES STRUCTURÉES
  // =====================================================================================
  const SCHEMAS = {
    FAQPage: { label: 'FAQ', fields: [['faq', 'Questions et réponses (une question par ligne, puis sa réponse à la ligne suivante)', 'textarea']] },
    Article: { label: 'Article de blog', fields: [['headline', 'Titre'], ['description', 'Résumé'], ['image', 'Image (adresse)'], ['author', 'Auteur'], ['datePublished', 'Date de publication (AAAA-MM-JJ)'], ['dateModified', 'Date de mise à jour (AAAA-MM-JJ)'], ['publisher', 'Nom du site'], ['url', 'Adresse de la page']] },
    Organization: { label: 'Organisation / marque', fields: [['name', 'Nom'], ['url', 'Site'], ['logo', 'Logo (adresse)'], ['description', 'Description'], ['sameAs', 'Réseaux sociaux (une adresse par ligne)', 'textarea'], ['email', 'E-mail de contact']] },
    LocalBusiness: { label: 'Commerce local', fields: [['name', 'Nom'], ['url', 'Site'], ['image', 'Image'], ['telephone', 'Téléphone'], ['streetAddress', 'Adresse'], ['postalCode', 'Code postal'], ['addressLocality', 'Ville'], ['addressCountry', 'Pays (FR)'], ['priceRange', 'Gamme de prix (€€)'], ['openingHours', 'Horaires (ex. Mo-Fr 09:00-18:00)']] },
    Product: { label: 'Produit', fields: [['name', 'Nom'], ['description', 'Description'], ['image', 'Image'], ['brand', 'Marque'], ['price', 'Prix'], ['priceCurrency', 'Devise (EUR)'], ['availability', 'Disponible (oui/non)'], ['ratingValue', 'Note moyenne (facultatif)'], ['reviewCount', 'Nombre d’avis (facultatif)']] },
    SoftwareApplication: { label: 'Application', fields: [['name', 'Nom'], ['description', 'Description'], ['url', 'Site'], ['operatingSystem', 'Systèmes (iOS, Android, Web)'], ['applicationCategory', 'Catégorie (TravelApplication…)'], ['price', 'Prix (0 si gratuit)'], ['priceCurrency', 'Devise (EUR)']] },
    BreadcrumbList: { label: 'Fil d’Ariane', fields: [['crumbs', 'Une étape par ligne : « Nom | adresse »', 'textarea']] },
    HowTo: { label: 'Guide pas à pas', fields: [['name', 'Titre'], ['description', 'Résumé'], ['totalTime', 'Durée (ex. PT30M)'], ['steps', 'Une étape par ligne', 'textarea']] },
    Event: { label: 'Événement', fields: [['name', 'Nom'], ['startDate', 'Début (AAAA-MM-JJTHH:MM)'], ['endDate', 'Fin'], ['locationName', 'Lieu'], ['addressLocality', 'Ville'], ['url', 'Adresse de la page'], ['price', 'Prix'], ['priceCurrency', 'Devise (EUR)']] },
  };
  function buildSchema(type, v) {
    const clean = (o) => { for (const k of Object.keys(o)) { if (o[k] && typeof o[k] === 'object' && !Array.isArray(o[k])) clean(o[k]); if (o[k] === '' || o[k] == null || (Array.isArray(o[k]) && !o[k].length) || (typeof o[k] === 'object' && !Array.isArray(o[k]) && !Object.keys(o[k]).filter((x) => x !== '@type').length)) delete o[k]; } return o; };
    const lines = (s) => String(s || '').split('\n').map((x) => x.trim()).filter(Boolean);
    const base = { '@context': 'https://schema.org', '@type': type };
    if (type === 'FAQPage') { const l = lines(v.faq), qa = []; for (let i = 0; i < l.length; i += 2) if (l[i + 1]) qa.push({ '@type': 'Question', name: l[i], acceptedAnswer: { '@type': 'Answer', text: l[i + 1] } }); return { ...base, mainEntity: qa }; }
    if (type === 'Article') return clean({ ...base, '@type': 'BlogPosting', headline: v.headline, description: v.description, image: v.image, datePublished: v.datePublished, dateModified: v.dateModified || v.datePublished, author: { '@type': 'Person', name: v.author }, publisher: { '@type': 'Organization', name: v.publisher }, mainEntityOfPage: v.url });
    if (type === 'Organization') return clean({ ...base, name: v.name, url: v.url, logo: v.logo, description: v.description, email: v.email, sameAs: lines(v.sameAs) });
    if (type === 'LocalBusiness') return clean({ ...base, name: v.name, url: v.url, image: v.image, telephone: v.telephone, priceRange: v.priceRange, openingHours: v.openingHours, address: { '@type': 'PostalAddress', streetAddress: v.streetAddress, postalCode: v.postalCode, addressLocality: v.addressLocality, addressCountry: v.addressCountry } });
    if (type === 'Product') return clean({ ...base, name: v.name, description: v.description, image: v.image, brand: { '@type': 'Brand', name: v.brand }, offers: { '@type': 'Offer', price: v.price, priceCurrency: v.priceCurrency || 'EUR', availability: /non|no/i.test(v.availability || '') ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock' }, aggregateRating: v.ratingValue ? { '@type': 'AggregateRating', ratingValue: v.ratingValue, reviewCount: v.reviewCount } : null });
    if (type === 'SoftwareApplication') return clean({ ...base, name: v.name, description: v.description, url: v.url, operatingSystem: v.operatingSystem, applicationCategory: v.applicationCategory, offers: { '@type': 'Offer', price: v.price || '0', priceCurrency: v.priceCurrency || 'EUR' } });
    if (type === 'BreadcrumbList') return { ...base, itemListElement: lines(v.crumbs).map((l, i) => { const [name, item] = l.split(/\s*\|\s*/); return clean({ '@type': 'ListItem', position: i + 1, name, item }); }) };
    if (type === 'HowTo') return clean({ ...base, name: v.name, description: v.description, totalTime: v.totalTime, step: lines(v.steps).map((s, i) => ({ '@type': 'HowToStep', position: i + 1, text: s })) });
    if (type === 'Event') return clean({ ...base, name: v.name, startDate: v.startDate, endDate: v.endDate, url: v.url, location: { '@type': 'Place', name: v.locationName, address: { '@type': 'PostalAddress', addressLocality: v.addressLocality } }, offers: v.price ? { '@type': 'Offer', price: v.price, priceCurrency: v.priceCurrency || 'EUR', url: v.url } : null });
    return base;
  }
  function openSchema(el) {
    el.innerHTML = `<div class="radar"><span class="label">Données structurées</span><h1>Aidez Google et les IA à comprendre vos pages</h1>
      <p class="lede">Choisissez un type, remplissez les champs (ou partez d’une page existante) : VANTIX génère le bloc JSON-LD à coller dans la page.</p>
      <div class="grid2"><label class="opt"><span>Type</span><select class="field" id="scType">${Object.entries(SCHEMAS).map(([k, s]) => `<option value="${k}">${esc(s.label)}</option>`).join('')}</select></label>
      <label class="opt"><span>Pré-remplir depuis une page (facultatif)</span><div class="urlrow" style="padding:4px 4px 4px 14px"><input id="scUrl" placeholder="https://monsite.fr/page" spellcheck="false"><button class="ghostbtn" id="scFetch" type="button">Lire</button></div></label></div>
      <div class="grid2" style="margin-top:6px"><div id="scFields" class="rform"></div><div><div class="secrow" style="margin:0 0 10px"><b style="font-weight:400">Code à coller dans la page</b><button class="ghostbtn" id="scCopy" type="button">Copier</button></div><pre class="brief" id="scOut"></pre><p class="muted" style="font-size:13px">À placer dans le &lt;head&gt; ou à la fin du &lt;body&gt;. Vérifiez ensuite avec l’outil de test des résultats enrichis de Google.</p></div></div></div>`;
    let values = {};
    const render = () => {
      const type = $('#scType', el).value;
      $('#scFields', el).innerHTML = SCHEMAS[type].fields.map(([k, l, kind]) => `<label class="opt"><span>${esc(l)}</span>${kind === 'textarea' ? `<textarea class="field" rows="5" data-k="${k}">${esc(values[k] || '')}</textarea>` : `<input class="field" data-k="${k}" value="${esc(values[k] || '')}">`}</label>`).join('');
      $$('[data-k]', el).forEach((i) => i.addEventListener('input', () => { values[i.dataset.k] = i.value; out(); }));
      out();
    };
    const code = () => '<script type="application/ld+json">\n' + JSON.stringify(buildSchema($('#scType', el).value, values), null, 2) + '\n</script>';
    const out = () => { $('#scOut', el).textContent = code(); };
    $('#scType', el).addEventListener('change', render);
    $('#scCopy', el).addEventListener('click', () => navigator.clipboard.writeText(code()).then(() => toast('Code copié')));
    $('#scFetch', el).addEventListener('click', async () => {
      const u = $('#scUrl', el).value.trim(); if (!u) return;
      const r = await api.fetchPage({ url: /^https?:/i.test(u) ? u : 'https://' + u });
      if (!r.ok || !r.body) return toast('Page illisible.');
      const p = VX.parse.analyzePage(r, { depth: 0, startHost: new URL(r.finalUrl || r.url).hostname, includeSubdomains: false });
      const host = new URL(r.finalUrl || r.url);
      values = Object.assign(values, { headline: p.h1[0] || p.title, name: p.h1[0] || p.title, description: p.description || '', image: (p.og && p.og.image) || '', url: p.url, datePublished: (p.published || '').slice(0, 10), dateModified: (p.modified || '').slice(0, 10), publisher: host.hostname.replace(/^www\./, ''), author: p.author || '',
        faq: (p.geo.qa || []).map((x) => x.q + '\n' + x.a).join('\n'), crumbs: [['Accueil', host.origin + '/'], [p.h1[0] || p.title, p.url]].map((x) => x.join(' | ')).join('\n'), steps: p.headings.filter((h) => h.level === 2).map((h) => h.text).join('\n') });
      render(); toast('Champs pré-remplis : vérifiez-les');
    });
    render();
  }

  // =====================================================================================
  // 6. MAILLAGE INTERNE (onglet du rapport)
  // =====================================================================================
  function linkSuggestions(report) {
    const pages = report.pages.filter((p) => p.html && p.status < 300 && !p.noindex && (p.mainWordCount || 0) >= 150);
    const linked = new Map(pages.map((p) => [p.url, new Set((p.links || []).filter((l) => l.kind === 'page' && l.internal).map((l) => l.url))]));
    const topicOf = (p) => [...T.terms(p.h1 && p.h1[0] ? p.h1[0] : String(p.title || '').split(/\s[|–—·-]\s/)[0])];
    const out = [];
    for (const target of pages) {
      const t = topicOf(target); if (t.length < 2) continue;
      for (const src of pages) {
        if (src === target || linked.get(src.url).has(target.url)) continue;
        const kw = new Set((src.keywords || []).map(([w]) => w));
        const hit = t.filter((w) => kw.has(w)).length / t.length;
        if (hit < 0.6) continue;
        const weight = hit * 2 + ((target.inlinks || 0) <= 1 ? 2 : 0) + Math.min(2, (src.inlinks || 0) / 5);
        out.push({ from: src.url, to: target.url, anchor: (target.h1 && target.h1[0]) || target.title, targetInlinks: target.inlinks || 0, weight });
      }
    }
    // au plus 3 suggestions par page cible et 5 par page source
    const perT = new Map(), perS = new Map();
    return out.sort((a, b) => b.weight - a.weight).filter((s) => { const a = perT.get(s.to) || 0, b = perS.get(s.from) || 0; if (a >= 3 || b >= 5) return false; perT.set(s.to, a + 1); perS.set(s.from, b + 1); return true; }).slice(0, 300);
  }
  VX.linking = {
    tab(el, report) {
      const list = linkSuggestions(report), host = report.host;
      const short = (u) => { try { const x = new URL(u); return x.pathname + x.search; } catch { return u; } };
      el.innerHTML = `<div class="sec"><h2>Liens internes à ajouter <small>${fmt(list.length)} suggestions</small></h2>
        <p class="muted" style="max-width:80ch;margin:-6px 0 18px">Chaque ligne propose d’ajouter, sur une page qui parle déjà du sujet, un lien vers la page qui le traite. Les pages qui reçoivent peu de liens passent en premier : c’est là que le gain est le plus fort.</p>
        ${T.table(['Sur la page', 'Ajoutez un lien vers', 'Texte du lien conseillé', 'Liens reçus aujourd’hui'], list.map((s) => [`<span class="mono">${esc(short(s.from))}</span>`, `<span class="mono">${esc(short(s.to))}</span>`, esc(String(s.anchor).slice(0, 80)), s.targetInlinks]), 'Votre maillage est déjà bien fait : aucune suggestion.', 700)}
        ${list.length ? '<div class="toolbar" style="margin-top:14px"><button class="ghostbtn" id="mlCsv" type="button">Exporter (CSV)</button></div>' : ''}</div>`;
      const b = $('#mlCsv', el); if (b) b.addEventListener('click', () => api.exportFile({ defaultName: `maillage-${host}.csv`, content: csv([['Page source', 'Page cible', 'Texte du lien', 'Liens reçus'], ...list.map((s) => [s.from, s.to, s.anchor, s.targetInlinks])]), filters: [{ name: 'CSV', extensions: ['csv'] }] }).catch((e) => toast(e.message)));
    },
    linkSuggestions,
  };

  T.register({ id: 'optimizer', label: 'Optimiseur d’article', group: 'Contenu', icon: 'M5 19h4l10-10-4-4L5 15v4zM13 7l4 4', open: openOptimizer });
  T.register({ id: 'plan', label: 'Plan de contenu', group: 'Contenu', icon: 'M5 6h14M5 12h14M5 18h9', open: openPlan });
  T.register({ id: 'schema', label: 'Données structurées', group: 'Contenu', icon: 'M8 7l-4 5 4 5M16 7l4 5-4 5', open: openSchema });
  VX.content = { draftToHtml, scoreArticle, clusterKeywords, buildSchema, brief };
})();
