// VANTIX — assistant (questions en français simple sur vos rapports, avec lecture à voix haute) et extension navigateur
(function () {
  'use strict';
  const VX = window.VX, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T || !VX.geo) return;
  const G = VX.geo;
  const { $, $$, esc, toast, fmt } = UI;
  const hostOf = (u) => { try { return new URL(/^https?:/i.test(u) ? u : 'https://' + u).hostname.replace(/^www\./, ''); } catch { return ''; } };
  const SEVW = { critique: 3, important: 2, mineur: 1, info: 0 };

  // =====================================================================================
  // 12. ASSISTANT
  // =====================================================================================
  async function contextFor(host) {
    const reps = (await api.listReports().catch(() => [])).filter((r) => r.host === host);
    const ctx = { host, report: null, radar: null, gsc: null };
    if (reps[0]) ctx.report = await api.loadReport(reps[0].id);
    try { const rl = await api.radarList(); const hit = rl.find((p) => hostOf(p.site) === host.replace(/^www\./, '')); if (hit) { const p = await api.radarLoad(hit.id); const run = G.lastRun(p); if (run) ctx.radar = { brand: p.brand, date: run.date, ...run.summary, sources: undefined, opportunities: (run.summary.opportunities || []).slice(0, 8).map((o) => o.domain) }; } } catch {}
    try { const g = await T.load('gsc'); if (g && g.data && VX.gsc) ctx.gsc = VX.gsc.analyze(g.data); } catch {}
    return ctx;
  }
  function topIssues(r, n = 12) { return [...r.issues].filter((i) => i.sev !== 'info').sort((a, b) => (SEVW[b.sev] - SEVW[a.sev]) || (b.items.length - a.items.length)).slice(0, n); }
  function contextText(ctx) {
    const r = ctx.report; const parts = [];
    if (r) {
      parts.push(`Site ${r.host}, analysé le ${new Date(r.date).toLocaleDateString('fr-FR')}. Scores sur 100 : global ${r.scores.global}, SEO ${r.scores.seo}, visibilité IA ${r.scores.geo}, technique ${r.scores.technique}, contenu ${r.scores.contenu}, liens ${r.scores.liens}. ${r.stats.pages} adresses, ${r.stats.indexable} indexables, ${r.stats.brokenLinks} liens cassés, temps de réponse moyen ${r.stats.avgTime} ms.`);
      parts.push('Problèmes (gravité · titre · nombre · correction) :\n' + topIssues(r, 20).map((i) => `- ${i.sev} · ${i.title} · ${i.items.length} · ${i.fix}`).join('\n'));
      const blocked = (r.robots && r.robots.ai || []).filter((x) => !x.home).map((x) => x.bot);
      parts.push(blocked.length ? 'Robots IA bloqués : ' + blocked.join(', ') : 'Aucun robot IA bloqué.');
      parts.push(r.llms && r.llms.ok ? 'llms.txt présent.' : 'llms.txt absent.');
    }
    if (ctx.radar) parts.push(`Radar IA (${new Date(ctx.radar.date).toLocaleDateString('fr-FR')}) : la marque ${ctx.radar.brand} est citée dans ${ctx.radar.share} % de ${ctx.radar.answers} réponses, rang ${ctx.radar.rank}. Par IA : ${Object.entries(ctx.radar.providers || {}).map(([k, v]) => `${k} ${v.share} %`).join(', ')}. Concurrents : ${(ctx.radar.ranking || []).filter((x) => !x.own).slice(0, 5).map((x) => `${x.name} ${x.share} %`).join(', ')}. Sources à conquérir : ${(ctx.radar.opportunities || []).join(', ')}.`);
    if (ctx.gsc) parts.push(`Search Console : ${ctx.gsc.clicks} clics, ${ctx.gsc.impressions} affichages, position moyenne ${ctx.gsc.position}. Mots-clés proches de la première page : ${ctx.gsc.striking.slice(0, 8).map((q) => `${q.key} (pos. ${q.position})`).join(', ')}.`);
    return parts.join('\n\n');
  }
  /** Réponses sans IA pour les questions les plus courantes */
  function localAnswer(q, ctx) {
    const r = ctx.report, s = q.toLowerCase();
    if (!r) return 'Je n’ai pas encore d’analyse pour ce site : lancez « Nouvelle analyse », puis reposez votre question.';
    if (/premier|priorit|d['’]abord|commencer|urgent/.test(s)) { const t = topIssues(r, 3); return t.length ? `Commencez par ceci : ${t.map((i, n) => `${n + 1}) ${i.title.toLowerCase()} (${i.items.length}) : ${i.fix}`).join(' ')}` : 'Rien d’urgent : votre site est en bon état.'; }
    if (/score|note|où en|bilan|résumé|resume/.test(s)) return `Votre site obtient ${r.scores.global}/100 : SEO ${r.scores.seo}, visibilité dans les IA ${r.scores.geo}, technique ${r.scores.technique}. ${r.stats.critical ? r.stats.critical + ' problèmes critiques restent à corriger.' : 'Aucun problème critique.'}`;
    if (/ia|chatgpt|perplexity|gemini|claude|cit/.test(s)) return ctx.radar ? `Les IA vous citent dans ${String(ctx.radar.share).replace('.', ',')} % des réponses, au rang ${ctx.radar.rank} face à vos concurrents. Pour progresser, soyez présent sur : ${(ctx.radar.opportunities || []).slice(0, 3).join(', ') || 'les sources listées dans « Où être cité »'}.` : `Votre score de visibilité IA est de ${r.scores.geo}/100. Créez un Radar IA pour savoir si ChatGPT et les autres vous recommandent vraiment.`;
    return 'Pour des réponses à toutes vos questions, ajoutez une clé Claude ou ChatGPT dans le Radar IA. Sans clé, je peux vous dire quoi corriger en premier, votre score, ou votre visibilité dans les IA.';
  }
  let speaking = false;
  function speak(text, on) {
    if (!on || !window.speechSynthesis) return;
    try { speechSynthesis.cancel(); const u = new SpeechSynthesisUtterance(text.replace(/[*#_`]/g, '')); u.lang = 'fr-FR'; const v = speechSynthesis.getVoices().find((x) => /^fr/i.test(x.lang)); if (v) u.voice = v; u.rate = 1.02; speaking = true; u.onend = () => { speaking = false; }; speechSynthesis.speak(u); } catch {}
  }
  async function openAssistant(el) {
    const reps = await api.listReports().catch(() => []);
    const hosts = [...new Set(reps.map((r) => r.host))];
    const prefs = (await T.load('assistant')) || { voice: false };
    el.innerHTML = `<div class="radar"><span class="label">Assistant</span><h1>Posez vos questions, en français simple</h1>
      <p class="lede">L’assistant connaît vos analyses, votre Radar IA et vos données Search Console. Il répond en trois phrases, sans jargon, et peut lire ses réponses à voix haute.</p>
      <div class="toolbar"><label class="opt" style="min-width:260px"><span>Site</span><select class="field" id="asHost">${hosts.length ? hosts.map((h) => `<option>${esc(h)}</option>`).join('') : '<option value="">Aucune analyse</option>'}</select></label>
      <label class="switch" style="align-self:end"><input type="checkbox" id="asVoice" ${prefs.voice ? 'checked' : ''}><span>Lire les réponses à voix haute</span></label></div>
      <div class="chat" id="asChat" aria-live="polite"></div>
      <div class="chips" id="asChips">${['Qu’est-ce que je dois corriger en premier ?', 'Où en est mon site ?', 'Est-ce que les IA me recommandent ?', 'Quel article écrire cette semaine ?', 'Explique-moi le GEO simplement'].map((q) => `<button class="kchip" type="button" data-ask="${esc(q)}">${esc(q)}</button>`).join('')}</div>
      <form class="askrow" id="asForm"><input class="field" id="asQ" placeholder="Votre question…" autocomplete="off">${('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) ? '<button class="ghostbtn" id="asMic" type="button" aria-label="Dicter">🎙</button>' : ''}<button class="btn" type="submit">Envoyer</button></form></div>`;
    const chat = $('#asChat', el), history = [];
    let ctx = null;
    const loadCtx = async () => { ctx = hosts.length ? await contextFor($('#asHost', el).value) : { report: null }; };
    const bubble = (who, text) => { const d = document.createElement('div'); d.className = 'msg ' + who; d.textContent = text; chat.appendChild(d); chat.scrollTop = chat.scrollHeight; return d; };
    const ask = async (q) => {
      q = q.trim(); if (!q) return;
      if (!ctx) await loadCtx();
      bubble('me', q); $('#asQ', el).value = '';
      const wait = bubble('bot', '…');
      let answer;
      if (await G.aiReady()) {
        const r = await api.aiText({ maxTokens: 600,
          system: 'Tu es l’assistant de VANTIX, un outil de référencement (SEO) et de visibilité dans les IA (GEO). Tu parles à un débutant. Réponds en français simple, en 3 phrases maximum, sans jargon (ou en l’expliquant), avec des actions concrètes. Appuie-toi uniquement sur les données fournies ; si elles ne suffisent pas, dis quel outil de VANTIX lancer (Nouvelle analyse, Radar IA, Simulateur de citation, Où être cité, Erreurs des IA, FAQ réelles, Rafraîchir un article, Plan d’attaque). Pas de Markdown.',
          prompt: `Données du site :\n${contextText(ctx) || 'Aucune analyse disponible.'}\n\n${history.slice(-6).map((h) => (h.me ? 'Utilisateur : ' : 'Assistant : ') + h.t).join('\n')}\nUtilisateur : ${q}\nAssistant :` });
        answer = r.ok ? r.text : localAnswer(q, ctx) + (r.error ? ` (IA indisponible : ${r.error})` : '');
      } else answer = localAnswer(q, ctx);
      wait.textContent = answer;
      history.push({ me: true, t: q }, { me: false, t: answer });
      speak(answer, $('#asVoice', el).checked);
    };
    $('#asHost', el).addEventListener('change', () => { ctx = null; chat.innerHTML = ''; history.length = 0; });
    $('#asVoice', el).addEventListener('change', (e) => { prefs.voice = e.target.checked; T.save('assistant', prefs); if (!e.target.checked && window.speechSynthesis) speechSynthesis.cancel(); });
    $$('[data-ask]', el).forEach((b) => b.addEventListener('click', () => ask(b.dataset.ask)));
    $('#asForm', el).addEventListener('submit', (e) => { e.preventDefault(); ask($('#asQ', el).value); });
    const mic = $('#asMic', el);
    if (mic) mic.addEventListener('click', () => {
      try {
        const R = window.SpeechRecognition || window.webkitSpeechRecognition; const rec = new R(); rec.lang = 'fr-FR'; rec.interimResults = false;
        rec.onresult = (e) => { const t = e.results[0][0].transcript; ask(t); };
        rec.onerror = () => toast('La dictée n’est pas disponible sur cet ordinateur : tapez votre question.');
        rec.start(); toast('Parlez…');
      } catch { toast('La dictée n’est pas disponible sur cet ordinateur.'); }
    });
    bubble('bot', hosts.length ? `Bonjour ! Je connais votre analyse de ${hosts[0]}. Que voulez-vous savoir ?` : 'Bonjour ! Lancez d’abord une analyse de votre site (« Nouvelle analyse ») pour que je puisse vous conseiller.');
    void speaking;
  }

  // =====================================================================================
  // 11. EXTENSION NAVIGATEUR
  // =====================================================================================
  function openExtension(el) {
    el.innerHTML = `<div class="radar"><span class="label">Extension navigateur</span><h1>Le score SEO et IA de n’importe quel site, en un clic</h1>
      <p class="lede">Sur n’importe quelle page, cliquez sur l’icône VANTIX : score SEO, score de visibilité IA, robots d’IA autorisés, llms.txt, données structurées et points à corriger. Gratuit, rien n’est envoyé nulle part.</p>
      <div class="sec words"><div class="card"><h3>Installation (2 minutes)</h3><ol class="steps2">
        <li>Cliquez sur <b>Enregistrer l’extension</b> et choisissez un dossier que vous ne supprimerez pas (par exemple Documents).</li>
        <li>Dans Chrome, ouvrez l’adresse <b>chrome://extensions</b> (Edge : edge://extensions, Brave : brave://extensions).</li>
        <li>Activez le <b>Mode développeur</b> en haut à droite.</li>
        <li>Cliquez sur <b>Charger l’extension non empaquetée</b> et choisissez le dossier <b>vantix-extension</b>.</li>
        <li>Épinglez l’icône VANTIX (pièce de puzzle, puis punaise). C’est prêt.</li></ol>
        <div class="toolbar" style="margin-top:14px"><button class="btn" id="exSave" type="button">Enregistrer l’extension</button></div></div>
      <div class="card"><h3>Ce qu’elle vérifie</h3><ul class="minilist"><li>Title, description, H1, langue, adresse canonique, indexation</li><li>Images sans texte alternatif, nombre de mots</li><li>Réponse directe en ouverture, FAQ, listes et tableaux, sources, date, auteur</li><li>Données structurées (Schema.org)</li><li>Robots d’IA autorisés dans robots.txt, présence de llms.txt</li></ul>
        <p class="muted" style="font-size:13px">Après une mise à jour de VANTIX, réenregistrez l’extension dans le même dossier puis cliquez sur ⟳ dans chrome://extensions.</p></div></div></div>`;
    $('#exSave', el).addEventListener('click', async () => {
      try { const files = await api.extensionFiles(); if (!files.length) throw new Error('Fichiers de l’extension introuvables.'); const dir = await api.exportFolder('vantix-extension', files, 'Où enregistrer l’extension ?'); if (dir) toast('Extension enregistrée'); } catch (x) { toast(x.message); }
    });
  }

  T.register({ id: 'assistant', label: 'Assistant', group: 'Outils', icon: 'M21 12a8 8 0 0 1-11.8 7L3 21l2-6.2A8 8 0 1 1 21 12z', open: openAssistant });
  T.register({ id: 'extension', label: 'Extension navigateur', group: 'Outils', icon: 'M14 4a2 2 0 1 0-4 0v2H6v4h-2a2 2 0 1 0 0 4h2v4h4v-2a2 2 0 1 0 4 0v2h4v-4h-2a2 2 0 1 1 0-4h2V6h-4z', open: openExtension });

  VX.assist = { contextText, localAnswer, topIssues };
})();
