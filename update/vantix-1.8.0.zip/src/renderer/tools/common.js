// VANTIX — socle commun des outils : registre, page d'outil, progression, lecture d'un échantillon de pages d'un site
(function () {
  'use strict';
  const VX = window.VX, U = VX.util, api = window.vantix, UI = window.__vxUi;
  if (!UI) return;
  const { $, $$, esc, show, toast, fmt } = UI;
  const tools = [];

  const T = VX.toolkit = {
    tools,
    /** Déclare un outil : { id, label, group, icon (svg path), open(el) } */
    register(tool) { tools.push(tool); renderSide(); },
    open(id) {
      const t = tools.find((x) => x.id === id); if (!t) return;
      show('v-tool'); $$('.sidetool').forEach((b) => b.setAttribute('aria-current', String(b.dataset.tool === id)));
      const el = $('#toolBody'); el.innerHTML = ''; t.open(el);
    },
    median(arr) { const a = arr.filter((x) => x != null && !isNaN(x)).sort((x, y) => x - y); if (!a.length) return null; const m = Math.floor(a.length / 2); return a.length % 2 ? a[m] : Math.round((a[m - 1] + a[m]) / 2); },
    share(arr, fn) { return arr.length ? Math.round((arr.filter(fn).length / arr.length) * 100) : 0; },
    origin(input) { const v = String(input || '').trim(); if (!v) return null; try { const u = new URL(/^https?:\/\//i.test(v) ? v : 'https://' + v); return u.origin; } catch { return null; } },
    host(input) { try { return new URL(T.origin(input)).hostname.replace(/^www\./, ''); } catch { return ''; } },
    load: (name) => api.storeGet(name).catch(() => null),
    save: (name, data) => api.storeSet(name, data).catch(() => toast('Enregistrement impossible.')),
    /** Bloc de progression réutilisable */
    progress(el, title) {
      el.innerHTML = `<div class="run"><span class="label">${esc(title)}</span><h1 class="pgTitle"></h1><div class="bar"><i class="pgBar"></i></div><p class="current pgCur"></p><div class="log pgLog" aria-live="polite"></div><button class="ghostbtn pgStop" type="button">Arrêter</button></div>`;
      const st = { stopped: false };
      $('.pgStop', el).addEventListener('click', () => { st.stopped = true; $('.pgStop', el).textContent = 'Arrêt en cours…'; });
      return Object.assign(st, {
        title: (t) => { $('.pgTitle', el).textContent = t; },
        bar: (v) => { $('.pgBar', el).style.width = Math.max(0, Math.min(100, v * 100)) + '%'; },
        cur: (t) => { $('.pgCur', el).textContent = t || ''; },
        log: (m) => { const l = $('.pgLog', el); if (!l) return; const d = document.createElement('div'); d.textContent = new Date().toLocaleTimeString('fr-FR') + '  ' + m; l.appendChild(d); while (l.childNodes.length > 200) l.firstChild.remove(); l.scrollTop = l.scrollHeight; },
      });
    },
    /** Tableau HTML simple ; les cellules sont du HTML déjà échappé, les nombres sont formatés. */
    table(head, rows, empty, maxH) {
      return rows.length ? `<div class="tablewrap" ${maxH ? `style="max-height:${maxH}px"` : ''}><table><thead><tr>${head.map((h) => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td${typeof c === 'number' ? ' class="num"' : ''}>${typeof c === 'number' ? fmt(c) : c == null ? '' : c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>` : `<p class="empty">${esc(empty || 'Rien à afficher.')}</p>`;
    },
    ext(url, label) { return `<button class="linkbtn" type="button" data-ext="${esc(url)}">${esc(label || url)}</button>`; },
    bindExt(el) { $$('[data-ext]', el).forEach((b) => b.addEventListener('click', () => api.openExternal(b.dataset.ext))); },

    /**
     * Lit un échantillon représentatif des pages d'un site (sitemap d'abord, liens de l'accueil sinon),
     * en respectant robots.txt, et renvoie une fiche légère par page.
     */
    async sitePages(input, { max = 40, log = () => {}, onPage = () => {}, isStopped = () => false, concurrency = 3 } = {}) {
      const origin = T.origin(input); if (!origin) throw new Error('Adresse invalide : ' + input);
      const fetchPage = (o) => api.fetchPage(o);
      const startHost = new URL(origin).hostname;
      const rr = await fetchPage({ url: origin + '/robots.txt' });
      const robotsText = rr.ok && rr.status === 200 && !/<html/i.test(rr.body || '') ? rr.body || '' : '';
      const robots = VX.crawler.parseRobots(robotsText);
      const sm = await VX.crawler.readSitemaps(origin, robots.sitemaps, fetchPage, log, 30000);
      const sameSite = (u) => { try { const h = new URL(u).hostname; return h === startHost || h.replace(/^www\./, '') === startHost.replace(/^www\./, ''); } catch { return false; } };
      const noise = /\/(tag|tags|category|categories|categorie|author|auteur|page\/\d+|search|recherche|wp-json|feed|cart|panier|account|compte|login|connexion)(\/|$)|\?/i;
      let cands = [...sm.urls.entries()].filter(([u]) => sameSite(u) && U.isLikelyPage(u) && !noise.test(u) && VX.crawler.allowed(robots, 'VANTIXBot', u));
      const home = await fetchPage({ url: origin + '/' });
      let homePage = null;
      if (home.ok && /html/i.test(home.contentType || '') && home.body) homePage = VX.parse.analyzePage(home, { depth: 0, startHost, includeSubdomains: false });
      if (cands.length < 5 && homePage) {
        const linked = [...new Set(homePage.links.filter((l) => l.kind === 'page' && l.internal && !noise.test(l.url)).map((l) => l.url))];
        cands = [...cands, ...linked.map((u) => [u, { lastmod: null }])];
      }
      // les plus récentes d'abord, puis un échantillon réparti sur le reste
      cands.sort((a, b) => String(b[1].lastmod || '').localeCompare(String(a[1].lastmod || '')));
      const pick = [];
      const half = Math.ceil(max / 2);
      pick.push(...cands.slice(0, half));
      const rest = cands.slice(half), need = max - pick.length;
      if (rest.length && need > 0) { const step = rest.length / need; for (let i = 0; i < need && Math.floor(i * step) < rest.length; i++) pick.push(rest[Math.floor(i * step)]); }
      const urls = [...new Set(pick.map(([u]) => u))].slice(0, max);
      log(`${startHost} : ${fmt(sm.urls.size)} adresses dans le sitemap, ${urls.length} pages lues`);
      const pages = [];
      await U.pool(urls, concurrency, async (url) => {
        const res = await fetchPage({ url });
        if (res.ok && /html/i.test(res.contentType || '') && res.body && res.status < 300) {
          const p = VX.parse.analyzePage(res, { depth: 1, startHost, includeSubdomains: false });
          pages.push(T.slim(p));
        }
        onPage(pages.length, urls.length, url);
      }, isStopped);
      const llms = await fetchPage({ url: origin + '/llms.txt' });
      return {
        origin, host: startHost.replace(/^www\./, ''), sitemapCount: sm.urls.size, robotsText,
        aiAccess: VX.crawler.aiBotAccess(robotsText ? robots : null, origin),
        llms: !!(llms.ok && llms.status === 200 && /^#\s|\n#\s/.test(llms.body || '')),
        home: homePage ? T.slim(homePage) : null,
        pages,
      };
    },
    slim(p) {
      return {
        url: p.url, title: p.title || '', h1: p.h1[0] || '', h2: p.headings.filter((h) => h.level === 2).map((h) => h.text).slice(0, 30),
        description: p.description || '', words: p.mainWordCount, faq: !!(p.schema.hasFAQ || (p.geo.qa && p.geo.qa.length >= 2)),
        faqSchema: !!p.schema.hasFAQ, questions: p.questionHeadings, schema: p.schema.types.slice(0, 12), article: !!p.schema.hasArticle,
        answerFirst: !!p.geo.answerFirst, sources: p.geo.sources, lists: p.geo.lists, tables: p.geo.tables, author: p.geo.author, dated: p.geo.dated,
        timeMs: p.timeMs || 0, streamed: p.streamedWords || 0, keywords: (p.keywords || []).slice(0, 20), images: p.images ? p.images.total : 0, imagesNoDims: p.images ? p.images.noDims : 0,
        internalLinks: p.links.filter((l) => l.internal && l.kind === 'page').length, lang: p.lang || '', canonical: p.canonical, noindex: p.noindex,
        imagesNoAlt: p.images ? p.images.noAlt || 0 : 0, firstParagraph: (p.geo.firstParagraph || '').slice(0, 300),
      };
    },
    /** Jetons significatifs d'un texte (sans mots vides) */
    terms(text) { return new Set(U.tokenize(String(text || '')).filter((w) => w.length >= 3 && !U.STOP.has(w) && !/^\d+$/.test(w))); },
  };

  function renderSide() {
    const box = $('#sideTools'); if (!box) return;
    const ORDER = ['Aujourd’hui', 'IA', 'Analyser', 'Contenu', 'Technique', 'Agence', 'Outils'];
    const rank = (g) => { const i = ORDER.indexOf(g); return i < 0 ? 99 : i; };
    const groups = [...new Set(tools.map((t) => t.group))].sort((a, b) => rank(a) - rank(b));
    box.innerHTML = groups.map((g) => `<div class="side-label">${esc(g)}</div>` + tools.filter((t) => t.group === g).map((t) => `<button class="sidetool" type="button" data-tool="${t.id}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${t.icon}" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>${esc(t.label)}</button>`).join('')).join('');
    $$('.sidetool', box).forEach((b) => b.addEventListener('click', () => T.open(b.dataset.tool)));
  }
})();
