// VANTIX — Technique : vitesse réelle (PageSpeed), ce que voient les robots d'IA, audits programmés avec alertes
(function () {
  'use strict';
  const VX = window.VX, U = VX.util, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T) return;
  const { $, $$, esc, toast, fmt } = UI;
  const scoreCol = (v) => (v >= 90 ? 'var(--ok)' : v >= 50 ? 'var(--warn)' : 'var(--crit)');

  // =====================================================================================
  // 8. VITESSE (PageSpeed Insights)
  // =====================================================================================
  function readPsi(data) {
    const lh = data.lighthouseResult || {}, au = lh.audits || {}, cats = lh.categories || {};
    const m = (id) => (au[id] ? { value: au[id].displayValue || '', score: au[id].score, num: au[id].numericValue } : null);
    const savings = (a) => (a.details && a.details.overallSavingsMs) || (a.metricSavings ? Math.max(a.metricSavings.LCP || 0, a.metricSavings.FCP || 0, a.metricSavings.TBT || 0, a.metricSavings.INP || 0) : 0);
    const fixes = Object.values(au).filter((a) => a.score !== null && a.score < 0.9 && (savings(a) > 0 || (a.details && a.details.overallSavingsBytes > 0))).map((a) => ({ id: a.id, title: a.title, value: a.displayValue || '', ms: Math.round(savings(a)), bytes: (a.details && a.details.overallSavingsBytes) || 0 })).sort((a, b) => b.ms - a.ms || b.bytes - a.bytes).slice(0, 12);
    const field = (data.loadingExperience && data.loadingExperience.metrics) || null;
    const f = (k) => (field && field[k] ? { p: field[k].percentile, cat: field[k].category } : null);
    return {
      perf: cats.performance ? Math.round(cats.performance.score * 100) : null, seo: cats.seo ? Math.round(cats.seo.score * 100) : null,
      a11y: cats.accessibility ? Math.round(cats.accessibility.score * 100) : null, bp: cats['best-practices'] ? Math.round(cats['best-practices'].score * 100) : null,
      lcp: m('largest-contentful-paint'), cls: m('cumulative-layout-shift'), tbt: m('total-blocking-time'), fcp: m('first-contentful-paint'), si: m('speed-index'), ttfb: au['server-response-time'] ? { value: Math.round(au['server-response-time'].numericValue || 0).toLocaleString('fr-FR') + ' ms', score: au['server-response-time'].score } : null,
      field: field ? { lcp: f('LARGEST_CONTENTFUL_PAINT_MS'), inp: f('INTERACTION_TO_NEXT_PAINT'), cls: f('CUMULATIVE_LAYOUT_SHIFT_SCORE'), overall: data.loadingExperience.overall_category } : null,
      fixes,
    };
  }
  async function openSpeed(el) {
    const saved = await T.load('speed');
    let reports = []; try { reports = await api.listReports(); } catch {}
    const keys = await api.keysStatus().catch(() => ({}));
    el.innerHTML = `<div class="radar"><span class="label">Vitesse</span><h1>Vos pages sont-elles rapides ?</h1>
      <p class="lede">VANTIX interroge PageSpeed Insights, l’outil gratuit de Google : note de performance, signaux Web essentiels mesurés chez de vrais visiteurs, et ce qui ralentit chaque page.</p>
      <form class="rform" id="spForm" novalidate>
        <label class="opt"><span>Pages à tester, une par ligne (10 au maximum)</span><textarea class="field" id="spUrls" rows="5" spellcheck="false" placeholder="https://getspotiq.com/&#10;https://getspotiq.com/city/paris">${esc(saved ? saved.urls.join('\n') : '')}</textarea></label>
        <div class="toolbar">${reports.length ? `<select class="sel" id="spFromReport"><option value="">Ajouter les pages les plus lentes d’une analyse…</option>${reports.slice(0, 15).map((r) => `<option value="${esc(r.id)}">${esc(r.host)} · ${new Date(r.date).toLocaleDateString('fr-FR')}</option>`).join('')}</select>` : ''}
        <label class="chk"><input type="radio" name="spDev" value="mobile" checked><span>Mobile</span></label><label class="chk"><input type="radio" name="spDev" value="desktop"><span>Ordinateur</span></label></div>
        <p class="muted" style="font-size:13px;margin:0">Chaque test prend 15 à 40 secondes. Google limite le nombre de tests sans clé : ${keys.psi ? 'votre clé gratuite est enregistrée.' : '<button class="linkbtn" type="button" id="spKey">ajouter une clé gratuite</button> si vous voyez « quota dépassé ».'}</p>
        <p class="err" id="spErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Tester la vitesse</button>${saved ? `<button class="ghostbtn" id="spLast" type="button">Revoir les résultats du ${new Date(saved.date).toLocaleDateString('fr-FR')}</button>` : ''}</div></form></div>`;
    const fr = $('#spFromReport', el);
    if (fr) fr.addEventListener('change', async () => {
      if (!fr.value) return; const r = await api.loadReport(fr.value);
      const slow = r.pages.filter((p) => p.html && p.status < 300 && !p.noindex).sort((a, b) => (b.timeMs || 0) - (a.timeMs || 0)).slice(0, 6).map((p) => p.url);
      const cur = $('#spUrls', el).value.split('\n').map((x) => x.trim()).filter(Boolean);
      $('#spUrls', el).value = [...new Set([r.home || r.origin + '/', ...cur, ...slow])].slice(0, 10).join('\n'); fr.value = '';
    });
    const k = $('#spKey', el); if (k) k.addEventListener('click', () => UI.modal(`<h2>Clé PageSpeed (gratuite)</h2><p>Sur <b>console.cloud.google.com</b> : créez un projet, activez « PageSpeed Insights API », puis <b>Identifiants</b>, <b>Créer une clé API</b>. C’est gratuit (25 000 tests par jour).</p><input type="password" id="pk" placeholder="AIza…" autocomplete="off"><div class="acts"><button class="ghostbtn" data-close type="button">Annuler</button><button class="btn" id="pkSave" type="button">Enregistrer</button></div>`, (m, close) => { $('#pkSave', m).addEventListener('click', async () => { const v = $('#pk', m).value.trim(); if (!v) return; await api.setProviderKey('psi', v); toast('Clé enregistrée'); close(); openSpeed(el); }); }));
    const last = $('#spLast', el); if (last) last.addEventListener('click', () => showSpeed(el, saved));
    $('#spForm', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      const urls = [...new Set($('#spUrls', el).value.split('\n').map((x) => x.trim()).filter(Boolean).map((u) => (/^https?:\/\//i.test(u) ? u : 'https://' + u)))].slice(0, 10);
      if (!urls.length) { $('#spErr', el).textContent = 'Ajoutez au moins une adresse.'; return; }
      const strategy = $('input[name=spDev]:checked', el).value;
      const pg = T.progress(el, 'Test de vitesse');
      const results = [];
      for (let i = 0; i < urls.length; i++) {
        if (pg.stopped) break;
        pg.title(urls[i].replace(/^https?:\/\//, '')); pg.bar(i / urls.length); pg.cur('Google mesure la page…');
        const r = await api.psi({ url: urls[i], strategy });
        if (r.ok) { results.push({ url: urls[i], ...readPsi(r.data) }); pg.log(`${urls[i]} : performance ${results[results.length - 1].perf}/100`); }
        else { results.push({ url: urls[i], error: r.error }); pg.log(`${urls[i]} : ${r.error}`); if (/quota/i.test(r.error || '')) break; }
      }
      const rec = { date: new Date().toISOString(), strategy, urls, results };
      await T.save('speed', rec); showSpeed(el, rec);
    });
  }
  function showSpeed(el, rec) {
    const cat = (c) => (c === 'FAST' ? '<span style="color:var(--ok)">bon</span>' : c === 'AVERAGE' ? '<span style="color:var(--warn)">moyen</span>' : c === 'SLOW' ? '<span style="color:var(--crit)">lent</span>' : '');
    const all = new Map();
    for (const r of rec.results) for (const f of r.fixes || []) { const e = all.get(f.id) || { title: f.title, pages: 0, ms: 0 }; e.pages++; e.ms += f.ms; all.set(f.id, e); }
    el.innerHTML = `<header class="rhead"><div><span class="label">Vitesse · ${rec.strategy === 'desktop' ? 'ordinateur' : 'mobile'} · ${new Date(rec.date).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' })}</span><h1>${rec.results.length} page${rec.results.length > 1 ? 's' : ''} testée${rec.results.length > 1 ? 's' : ''}</h1></div><div class="ractions"><button class="ghostbtn" id="spNew" type="button">Nouveau test</button></div></header>
      <div class="tabbody">
      ${all.size ? `<div class="sec"><h2>Ce qui ralentit le plus votre site</h2>${T.table(['Correction', 'Pages concernées', 'Gain estimé'], [...all.values()].sort((a, b) => b.ms - a.ms).slice(0, 10).map((f) => [esc(f.title), f.pages, f.ms ? (f.ms / 1000).toLocaleString('fr-FR', { maximumFractionDigits: 1 }) + ' s' : '—']), '')}</div>` : ''}
      ${rec.results.map((r) => `<div class="sec"><div class="card">${r.error ? `<h3>${esc(r.url)}</h3><p class="err">${esc(r.error)}</p>` : `
        <div class="secrow" style="margin-bottom:14px"><h3 style="margin:0;overflow-wrap:anywhere">${esc(r.url)}</h3><div class="minis">${[['Performance', r.perf], ['SEO', r.seo], ['Accessibilité', r.a11y], ['Bonnes pratiques', r.bp]].map(([l, v]) => `<span><b style="color:${scoreCol(v)}">${v ?? '–'}</b>${l}</span>`).join('')}</div></div>
        <div class="tiles">${[['Affichage du contenu principal (LCP)', r.lcp], ['Décalages visuels (CLS)', r.cls], ['Blocage du navigateur (TBT)', r.tbt], ['Premier affichage (FCP)', r.fcp], ['Réponse du serveur', r.ttfb]].filter(([, v]) => v).map(([l, v]) => `<div class="tile"><b style="font-size:22px;color:${v.score == null ? 'var(--text)' : scoreCol(v.score * 100)}">${esc(v.value || '–')}</b><span>${l}</span></div>`).join('')}</div>
        ${r.field ? `<p style="margin:14px 0 0;font-size:14px;color:var(--text-2)">Chez vos vrais visiteurs (28 derniers jours) : LCP ${r.field.lcp ? (r.field.lcp.p / 1000).toLocaleString('fr-FR') + ' s ' + cat(r.field.lcp.cat) : '–'} · INP ${r.field.inp ? r.field.inp.p + ' ms ' + cat(r.field.inp.cat) : '–'} · CLS ${r.field.cls ? (r.field.cls.p / 100).toLocaleString('fr-FR') + ' ' + cat(r.field.cls.cat) : '–'}</p>` : '<p class="muted" style="font-size:13px;margin:14px 0 0">Pas encore assez de visiteurs pour les mesures réelles de Google : seule la mesure en laboratoire est disponible.</p>'}
        ${r.fixes.length ? `<h3 style="margin-top:18px;font-size:16px">À corriger sur cette page</h3><ul class="bul">${r.fixes.map((f) => `<li>${esc(f.title)}${f.ms ? ` <span class="muted">· jusqu’à ${(f.ms / 1000).toLocaleString('fr-FR', { maximumFractionDigits: 1 })} s gagnées</span>` : ''}</li>`).join('')}</ul>` : ''}`}</div></div>`).join('')}
      </div>`;
    $('#spNew', el).addEventListener('click', () => openSpeed(el));
  }

  // =====================================================================================
  // 9. CE QUE L'IA VOIT
  // =====================================================================================
  function extract(html) {
    const doc = new DOMParser().parseFromString(html || '', 'text/html');
    doc.querySelectorAll('script:not([type="application/ld+json"]),style,noscript,template,svg,[hidden],[aria-hidden="true"]').forEach((e) => e.remove());
    const txt = (e) => (e ? e.textContent.replace(/\s+/g, ' ').trim() : '');
    const blocks = [...doc.querySelectorAll('h1,h2,h3,p,li,td,blockquote,dd')].map(txt).filter((t) => t.length >= 30);
    return {
      title: txt(doc.querySelector('title')), description: (doc.querySelector('meta[name="description" i]') || { getAttribute: () => '' }).getAttribute('content') || '',
      h1: [...doc.querySelectorAll('h1')].map(txt), headings: [...doc.querySelectorAll('h2,h3')].map(txt).filter(Boolean),
      blocks: [...new Set(blocks)], words: U.tokenize(txt(doc.body)).length, links: doc.querySelectorAll('a[href]').length,
      jsonld: doc.querySelectorAll('script[type="application/ld+json"]').length,
    };
  }
  function compareViews(raw, rendered) {
    const norm = (s) => s.toLowerCase().replace(/\s+/g, ' ');
    const rawText = norm(raw.blocks.join(' ') + ' ' + raw.headings.join(' ') + ' ' + raw.h1.join(' '));
    const missing = rendered.blocks.filter((b) => !rawText.includes(norm(b).slice(0, 80)));
    const missH = rendered.headings.filter((h) => !rawText.includes(norm(h)));
    const coverage = rendered.blocks.length ? Math.round(((rendered.blocks.length - missing.length) / rendered.blocks.length) * 100) : 100;
    return { coverage, missing, missH, wordsRaw: raw.words, wordsRendered: rendered.words };
  }
  function openAiView(el) {
    el.innerHTML = `<div class="radar"><span class="label">Ce que l’IA voit</span><h1>Votre page, vue par ChatGPT</h1>
      <p class="lede">La plupart des robots d’IA ne lancent pas JavaScript. VANTIX compare la page telle qu’un visiteur la voit et telle qu’un robot la reçoit, puis surligne ce qui manque au robot.</p>
      <form class="rform" id="avForm" novalidate><div class="grid2"><label class="opt"><span>Adresse de la page</span><input class="field" id="avUrl" placeholder="https://getspotiq.com/city/paris" spellcheck="false"></label>
        <label class="opt"><span>Robot à simuler</span><select class="field" id="avAgent"><option value="gptbot">GPTBot (ChatGPT)</option><option value="oaisearch">OAI-SearchBot (recherche ChatGPT)</option><option value="claudebot">ClaudeBot (Claude)</option><option value="perplexitybot">PerplexityBot</option><option value="googlebot">Googlebot</option></select></label></div>
        <p class="err" id="avErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Comparer</button></div></form><div id="avOut"></div></div>`;
    $('#avForm', el).addEventListener('submit', async (e) => {
      e.preventDefault();
      let url = $('#avUrl', el).value.trim(); if (!url) { $('#avErr', el).textContent = 'Indiquez une adresse.'; return; }
      if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
      const agent = $('#avAgent', el).value, label = $('#avAgent option:checked', el).textContent;
      const btn = $('#avForm button[type=submit]', el); btn.disabled = true; btn.textContent = 'Comparaison…';
      try {
        const [raw, rend, robots] = await Promise.all([api.fetchPage({ url, agent }), api.renderPage({ url }), api.fetchPage({ url: new URL(url).origin + '/robots.txt' })]);
        if (!raw.ok) throw new Error('Le robot n’a pas pu lire la page : ' + raw.error);
        if (!rend.ok) throw new Error('Rendu impossible : ' + rend.error);
        const botName = { gptbot: 'GPTBot', oaisearch: 'OAI-SearchBot', claudebot: 'ClaudeBot', perplexitybot: 'PerplexityBot', googlebot: 'Googlebot' }[agent];
        const allowed = robots.ok && robots.status === 200 ? VX.crawler.allowed(VX.crawler.parseRobots(robots.body || ''), botName, url) : true;
        const a = extract(raw.body), b = extract(rend.html), c = compareViews(a, b);
        const col = c.coverage >= 90 ? 'var(--ok)' : c.coverage >= 60 ? 'var(--warn)' : 'var(--crit)';
        $('#avOut', el).innerHTML = `<div class="sec"><div class="scorehead"><div class="bigscore" style="color:${col}">${c.coverage}<small>%</small></div><div><h2 style="margin:0">${c.coverage >= 90 ? `${esc(label)} voit l’essentiel de la page` : c.coverage >= 60 ? `${esc(label)} ne voit qu’une partie de la page` : `${esc(label)} ne voit presque rien`}</h2><p class="muted" style="margin:6px 0 0">Part du contenu visible par un visiteur qui est aussi lisible par le robot, sans JavaScript.${!allowed ? ' <b style="color:var(--crit)">Attention : robots.txt interdit cette page à ce robot.</b>' : ''}${raw.status >= 400 ? ` <b style="color:var(--crit)">Le site répond ${raw.status} à ce robot.</b>` : ''}</p></div></div></div>
          <div class="sec"><div class="tablewrap"><table><thead><tr><th></th><th>Visiteur (avec JavaScript)</th><th>${esc(label)}</th></tr></thead><tbody>
            ${[['Title', esc(b.title), esc(a.title)], ['Meta description', esc(b.description.slice(0, 160)), esc(a.description.slice(0, 160))], ['Titre H1', esc(b.h1.join(' / ')), esc(a.h1.join(' / ')) || '<span style="color:var(--crit)">absent</span>'], ['Mots lisibles', fmt(c.wordsRendered), fmt(c.wordsRaw)], ['Intertitres', fmt(b.headings.length), fmt(a.headings.length)], ['Liens', fmt(b.links), fmt(a.links)], ['Données structurées', fmt(b.jsonld), fmt(a.jsonld)], ['Code HTTP', '—', raw.status]].map(([l, x, y]) => `<tr><td>${l}</td><td>${x}</td><td>${y}</td></tr>`).join('')}</tbody></table></div></div>
          <div class="sec"><h2>Invisible pour ${esc(label)} <small>${c.missing.length} passages</small></h2>${c.missing.length ? `<div class="card"><ul class="missing">${c.missH.map((h) => `<li class="h">${esc(h)}</li>`).join('')}${c.missing.slice(0, 60).map((m) => `<li>${esc(m.slice(0, 280))}</li>`).join('')}</ul></div><p class="muted" style="font-size:13px;margin-top:10px">Pour corriger : envoyer ce contenu directement dans le HTML (rendu côté serveur), au lieu de le charger par JavaScript après l’affichage.</p>` : '<p class="empty">Rien ne manque : le robot reçoit tout le contenu.</p>'}</div>`;
      } catch (err) { $('#avErr', el).textContent = err.message; }
      btn.disabled = false; btn.textContent = 'Comparer';
    });
  }

  // =====================================================================================
  // 10. AUDITS PROGRAMMÉS + ALERTES
  // =====================================================================================
  const SCHED = 'schedules';
  function alertsBetween(prev, cur) {
    const out = [];
    if (prev.scores.global - cur.scores.global >= 5) out.push(`Score VANTIX en baisse : ${prev.scores.global} → ${cur.scores.global}`);
    const prevCrit = new Set(prev.issues.filter((i) => i.sev === 'critique').map((i) => i.id));
    for (const i of cur.issues.filter((x) => x.sev === 'critique' && x.id !== 'ai_blocked' && !prevCrit.has(x.id))) out.push(`Nouveau problème critique : ${i.title} (${i.items.length})`);
    const home = (r) => r.pages.find((p) => p.url === r.home);
    const h0 = home(prev), h1 = home(cur);
    if (h1 && h1.status >= 400) out.push(`La page d’accueil répond ${h1.status}`);
    if (h1 && h1.noindex && !(h0 && h0.noindex)) out.push('La page d’accueil est passée en noindex : elle va disparaître de Google');
    if (cur.stats.errors - prev.stats.errors >= 3) out.push(`${cur.stats.errors - prev.stats.errors} pages de plus en erreur (${cur.stats.errors} au total)`);
    if (cur.stats.brokenLinks - prev.stats.brokenLinks >= 5) out.push(`${cur.stats.brokenLinks - prev.stats.brokenLinks} liens cassés de plus`);
    if (prev.stats.indexable && (prev.stats.indexable - cur.stats.indexable) / prev.stats.indexable >= 0.1) out.push(`Pages indexables en baisse : ${prev.stats.indexable} → ${cur.stats.indexable}`);
    if (cur.issues.some((i) => i.id === 'ai_blocked') && !prev.issues.some((i) => i.id === 'ai_blocked')) out.push('Des robots d’IA viennent d’être bloqués dans robots.txt');
    return out;
  }
  const due = (s) => !s.lastRun || Date.now() - new Date(s.lastRun).getTime() >= (s.freq === 'weekly' ? 7 * 24 : 24) * 3600 * 1000 - 30 * 60 * 1000;
  let running = false;
  async function runSchedule(s, list) {
    const raw = await VX.crawler.crawl({ url: s.url, maxPages: s.maxPages || 500, concurrency: 4, respectRobots: true, useSitemaps: true, checkExternal: false, includeSubdomains: false }, { fetchPage: (o) => api.fetchPage(o), log: () => {}, progress: () => {}, isCancelled: () => false });
    const rep = VX.analyze.buildReport(raw);
    await api.saveReport(rep);
    let prev = null; if (s.lastReportId) { try { prev = await api.loadReport(s.lastReportId); } catch {} }
    const alerts = prev ? alertsBetween(prev, rep) : [];
    s.lastRun = new Date().toISOString(); s.lastReportId = rep.id; s.lastScore = rep.scores.global;
    s.history = [{ date: s.lastRun, score: rep.scores.global, alerts }, ...(s.history || [])].slice(0, 60);
    await T.save(SCHED, list);
    if (alerts.length) api.notify(`VANTIX : ${alerts.length} alerte${alerts.length > 1 ? 's' : ''} sur ${rep.host}`, alerts.slice(0, 3).join(' · '));
    return { rep, alerts };
  }
  async function tick(force) {
    if (running || !api.storeGet) return;
    const list = (await T.load(SCHED)) || [];
    const todo = list.filter((s) => s.active !== false && (force === s.id || due(s)));
    if (!todo.length) return;
    running = true;
    try { for (const s of todo) { try { await runSchedule(s, list); } catch (e) { console.error(e); } } } finally { running = false; }
    if (!$('#v-tool').hidden && $('#schList')) openSchedules($('#toolBody'));
  }
  setTimeout(() => tick(), 20000);
  setInterval(() => tick(), 15 * 60 * 1000);

  async function openSchedules(el) {
    const list = (await T.load(SCHED)) || [];
    let login = false; try { login = await api.getLoginItem(); } catch {}
    el.innerHTML = `<div class="radar"><span class="label">Audits programmés</span><h1>VANTIX surveille vos sites</h1>
      <p class="lede">Chaque jour ou chaque semaine, VANTIX analyse vos sites tout seul et vous prévient par une notification si quelque chose se dégrade : page d’accueil en erreur, noindex, nouveaux liens cassés, robots d’IA bloqués, score en baisse.</p>
      <div class="card"><label class="chk"><input type="checkbox" id="schLogin" ${login ? 'checked' : ''}><span>Lancer VANTIX en arrière-plan au démarrage de l’ordinateur (conseillé : les audits ne tournent que quand VANTIX est ouvert)</span></label></div>
      <form class="rform" id="schForm" novalidate><div class="grid2"><label class="opt"><span>Site à surveiller</span><input class="field" id="schUrl" placeholder="getspotiq.com" spellcheck="false"></label>
        <div class="grid2"><label class="opt"><span>Fréquence</span><select class="field" id="schFreq"><option value="daily">Chaque jour</option><option value="weekly">Chaque semaine</option></select></label>
        <label class="opt"><span>Pages</span><select class="field" id="schMax"><option value="200">200</option><option value="500" selected>500</option><option value="2000">2 000</option></select></label></div></div>
        <p class="err" id="schErr" role="alert"></p><div class="toolbar"><button class="btn" type="submit">Ajouter</button></div></form>
      <div class="sec" id="schList">${list.length ? list.map((s) => `<div class="card schcard"><div class="secrow" style="margin:0"><div><b style="font-weight:400;font-size:18px">${esc(s.url.replace(/^https?:\/\//, ''))}</b><p class="muted" style="margin:4px 0 0;font-size:13px">${s.freq === 'weekly' ? 'Chaque semaine' : 'Chaque jour'} · ${fmt(s.maxPages)} pages · ${s.lastRun ? 'dernier audit ' + new Date(s.lastRun).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' }) + ' · score ' + s.lastScore : 'jamais lancé'}${s.active === false ? ' · en pause' : ''}</p></div>
        <div class="toolbar" style="margin:0"><button class="ghostbtn" data-run="${esc(s.id)}" type="button">${running ? 'En cours…' : 'Lancer maintenant'}</button><button class="ghostbtn" data-pause="${esc(s.id)}" type="button">${s.active === false ? 'Reprendre' : 'Pause'}</button><button class="ghostbtn" data-del="${esc(s.id)}" type="button">Supprimer</button></div></div>
        ${(s.history || []).length ? `<div class="hist">${s.history.slice(0, 8).map((h) => `<div><span class="mono">${new Date(h.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}</span><b style="color:${scoreCol(h.score)}">${h.score}</b><span>${h.alerts.length ? h.alerts.map(esc).join(' · ') : '<span class="muted">rien à signaler</span>'}</span></div>`).join('')}</div>` : ''}</div>`).join('') : '<p class="empty">Aucun site surveillé pour l’instant.</p>'}</div></div>`;
    $('#schLogin', el).addEventListener('change', async (e) => { try { await api.setLoginItem(e.target.checked); toast(e.target.checked ? 'VANTIX se lancera au démarrage' : 'Lancement au démarrage désactivé'); } catch (err) { toast(err.message); } });
    $('#schForm', el).addEventListener('submit', async (e) => {
      e.preventDefault(); const o = T.origin($('#schUrl', el).value);
      if (!o) { $('#schErr', el).textContent = 'Indiquez l’adresse du site.'; return; }
      list.push({ id: 's' + Date.now().toString(36), url: o, freq: $('#schFreq', el).value, maxPages: +$('#schMax', el).value, active: true, history: [] });
      await T.save(SCHED, list); toast('Site ajouté : premier audit dans quelques instants'); openSchedules(el); setTimeout(() => tick(), 1500);
    });
    $$('[data-run]', el).forEach((b) => b.addEventListener('click', () => { if (running) return toast('Un audit est déjà en cours.'); toast('Audit lancé en arrière-plan'); b.textContent = 'En cours…'; tick(b.dataset.run); }));
    $$('[data-pause]', el).forEach((b) => b.addEventListener('click', async () => { const s = list.find((x) => x.id === b.dataset.pause); s.active = s.active === false; await T.save(SCHED, list); openSchedules(el); }));
    $$('[data-del]', el).forEach((b) => b.addEventListener('click', async () => { await T.save(SCHED, list.filter((x) => x.id !== b.dataset.del)); openSchedules(el); }));
  }

  T.register({ id: 'speed', label: 'Vitesse', group: 'Technique', icon: 'M12 13l4-4M4 17a8 8 0 1 1 16 0', open: openSpeed });
  T.register({ id: 'aiview', label: 'Ce que l’IA voit', group: 'Technique', icon: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z', open: openAiView });
  T.register({ id: 'schedules', label: 'Audits programmés', group: 'Technique', icon: 'M12 7v5l3 2M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z', open: openSchedules });
  VX.technical = { readPsi, extract, compareViews, alertsBetween };
})();
