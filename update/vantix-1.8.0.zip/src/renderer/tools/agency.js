// VANTIX — Agences : rapport PDF à votre marque, gestion des clients et de leurs sites
(function () {
  'use strict';
  const VX = window.VX, T = VX.toolkit, api = window.vantix, UI = window.__vxUi;
  if (!T) return;
  const { $, $$, esc, toast, fmt } = UI;
  const BRAND = 'brand', CLIENTS = 'clients';
  const SEV = { critique: ['Critique', '#d93a4f'], important: ['Important', '#c27a00'], mineur: ['Mineur', '#6b6b78'], info: ['Info', '#3b6fd8'] };
  const hostOf = (u) => { try { return new URL(/^https?:/i.test(u) ? u : 'https://' + u).host.replace(/^www\./, ''); } catch { return String(u || '').replace(/^www\./, ''); } };

  // =====================================================================================
  // 11. RAPPORT PDF À VOTRE MARQUE
  // =====================================================================================
  function pdfHtml(r, brand, extra) {
    const b = Object.assign({ agency: 'VANTIX', color: '#ff6363', logo: '', contact: '' }, brand || {});
    const col = /^#[0-9a-f]{6}$/i.test(b.color) ? b.color : '#ff6363';
    const scoreCol = (v) => (v >= 80 ? '#1f9d6f' : v >= 55 ? '#c27a00' : '#d93a4f');
    const ring = (v, label) => `<div class="ring"><svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="42" fill="none" stroke="#ececf1" stroke-width="8"/><circle cx="50" cy="50" r="42" fill="none" stroke="${scoreCol(v)}" stroke-width="8" stroke-linecap="round" stroke-dasharray="${(2 * Math.PI * 42 * v / 100).toFixed(1)} 999" transform="rotate(-90 50 50)"/><text x="50" y="58" text-anchor="middle" font-size="26" fill="#111">${v}</text></svg><span>${label}</span></div>`;
    const top = r.issues.filter((i) => i.sev !== 'info').slice(0, 10);
    const date = new Date(r.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
    const verdict = (v) => (v >= 85 ? 'Excellent' : v >= 70 ? 'Bon, quelques réglages' : v >= 50 ? 'À améliorer' : 'Prioritaire');
    const blocked = r.robots.ai.filter((x) => !x.home).map((x) => x.bot);
    return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Audit ${esc(r.host)}</title><style>
      @page{size:A4;margin:0} *{box-sizing:border-box} body{margin:0;font:11pt/1.5 -apple-system,'Segoe UI',Roboto,Arial,sans-serif;color:#15151a;-webkit-print-color-adjust:exact;print-color-adjust:exact}
      .page{width:210mm;min-height:297mm;padding:18mm 18mm 16mm;position:relative;page-break-after:always} .page:last-child{page-break-after:auto}
      .cover{background:${col};color:#fff;display:flex;flex-direction:column;justify-content:space-between} .cover h1{font-size:40pt;font-weight:300;letter-spacing:-.02em;margin:0;line-height:1.05;word-break:break-word}
      .cover .k{font-size:9pt;letter-spacing:.14em;text-transform:uppercase;opacity:.85} .logo{max-height:22mm;max-width:70mm;object-fit:contain} .agency{font-size:16pt;font-weight:500}
      h2{font-size:18pt;font-weight:400;margin:0 0 6mm;color:${col}} h3{font-size:12pt;margin:0 0 2mm;font-weight:600}
      .rings{display:flex;gap:6mm;flex-wrap:wrap;margin:4mm 0 8mm} .ring{display:flex;flex-direction:column;align-items:center;width:26mm;font-size:8pt;color:#555;text-transform:uppercase;letter-spacing:.06em} .ring svg{width:24mm}
      .big{display:flex;align-items:center;gap:8mm;margin-bottom:6mm} .big .n{font-size:54pt;font-weight:200;line-height:1} .big p{margin:0;font-size:13pt}
      .stats{display:grid;grid-template-columns:repeat(4,1fr);gap:3mm;margin:6mm 0} .stat{background:#f4f4f8;border-radius:3mm;padding:3mm 4mm} .stat b{display:block;font-size:15pt;font-weight:400} .stat span{font-size:8.5pt;color:#555}
      .issue{border:1px solid #e6e6ee;border-radius:3mm;padding:4mm 5mm;margin-bottom:3.5mm;page-break-inside:avoid} .sev{display:inline-block;font-size:7.5pt;text-transform:uppercase;letter-spacing:.06em;padding:.6mm 2.2mm;border-radius:9mm;margin-right:2mm;color:#fff;vertical-align:1px}
      .issue p{margin:1.5mm 0;color:#444;font-size:9.5pt} .fix{border-left:2.5px solid ${col};padding-left:3mm;font-size:9.5pt} .ex{font-size:8pt;color:#777;word-break:break-all;margin-top:1.5mm}
      table{width:100%;border-collapse:collapse;font-size:9pt} td,th{padding:2mm 2.5mm;border-bottom:1px solid #ececf1;text-align:left} th{color:#777;font-weight:400}
      .foot{position:absolute;left:18mm;right:18mm;bottom:9mm;display:flex;justify-content:space-between;font-size:8pt;color:#888}
      .note{background:#f7f5ff;border-radius:3mm;padding:4mm 5mm;font-size:10pt;color:#333}
    </style></head><body>
      <section class="page cover"><div>${b.logo ? `<img class="logo" src="${esc(b.logo)}" alt="">` : `<div class="agency">${esc(b.agency)}</div>`}</div>
        <div><div class="k">Audit SEO et visibilité dans les IA</div><h1>${esc(extra.client || r.host)}</h1><p style="font-size:14pt;margin:4mm 0 0;opacity:.9">${esc(r.host)} · ${esc(date)}</p></div>
        <div style="font-size:10pt;opacity:.9">Préparé par ${esc(b.agency)}${b.contact ? ' · ' + esc(b.contact) : ''}</div></section>
      <section class="page"><h2>En résumé</h2>
        <div class="big"><div class="n" style="color:${scoreCol(r.scores.global)}">${r.scores.global}<span style="font-size:20pt;color:#999">/100</span></div><p><b>${verdict(r.scores.global)}</b><br><span style="color:#555;font-size:10.5pt">${fmt(r.stats.pages)} adresses analysées, ${fmt(r.stats.issues)} types de problèmes dont ${fmt(r.stats.critical)} critiques.</span></p></div>
        <div class="rings">${ring(r.scores.seo, 'SEO')}${ring(r.scores.geo, 'Visibilité IA')}${ring(r.scores.technique, 'Technique')}${ring(r.scores.contenu, 'Contenu')}${ring(r.scores.liens, 'Liens')}</div>
        <div class="stats">${[[r.stats.indexable, 'pages indexables'], [r.stats.words, 'mots analysés'], [r.stats.brokenLinks, 'liens cassés'], [r.stats.avgTime + ' ms', 'temps de réponse moyen']].map(([v, l]) => `<div class="stat"><b>${typeof v === 'number' ? fmt(v) : v}</b><span>${l}</span></div>`).join('')}</div>
        ${extra.radar ? `<h3 style="margin-top:6mm">Recommandation par les IA</h3><p class="note">Sur ${fmt(extra.radar.answers)} réponses de ChatGPT, Claude, Perplexity et Gemini, la marque est citée dans <b>${String(extra.radar.share).replace('.', ',')} %</b> des cas${extra.radar.rank ? `, au rang ${extra.radar.rank} face à ses concurrents` : ''}.</p>` : ''}
        <h3 style="margin-top:6mm">Accès des robots d’IA</h3><p class="note">${blocked.length ? `Le site bloque ${esc(blocked.join(', '))} : ces IA ne peuvent pas le lire ni le citer.` : 'Aucun robot d’IA n’est bloqué : ChatGPT, Claude, Perplexity et Gemini peuvent lire le site.'}${r.llms && r.llms.ok ? ' Le fichier llms.txt est présent.' : ' Le fichier llms.txt, qui présente le site aux IA, est absent.'}</p>
        <div class="foot"><span>${esc(b.agency)}</span><span>${esc(r.host)} · ${esc(date)}</span></div></section>
      <section class="page"><h2>Les priorités</h2>${top.map((i, n) => `<div class="issue"><h3><span class="sev" style="background:${SEV[i.sev][1]}">${SEV[i.sev][0]}</span>${n + 1}. ${esc(i.title)} <span style="color:#888;font-weight:400">· ${fmt(i.items.length)}</span></h3><p>${esc(i.why)}</p><div class="fix">${esc(i.fix)}</div><div class="ex">${i.items.slice(0, 3).map((it) => esc(it.url) + (it.detail ? ' · ' + esc(String(it.detail).slice(0, 90)) : '')).join('<br>')}</div></div>`).join('') || '<p>Aucun problème notable.</p>'}
        <div class="foot"><span>${esc(b.agency)}</span><span>${esc(r.host)} · ${esc(date)}</span></div></section>
      ${extra.speed && extra.speed.length ? `<section class="page"><h2>Vitesse</h2><table><tr><th>Page</th><th>Performance</th><th>LCP</th><th>CLS</th><th>TBT</th></tr>${extra.speed.map((s) => `<tr><td style="word-break:break-all">${esc(s.url)}</td><td style="color:${scoreCol(s.perf)}">${s.perf ?? '–'}</td><td>${esc(s.lcp ? s.lcp.value : '–')}</td><td>${esc(s.cls ? s.cls.value : '–')}</td><td>${esc(s.tbt ? s.tbt.value : '–')}</td></tr>`).join('')}</table><div class="foot"><span>${esc(b.agency)}</span><span>${esc(r.host)} · ${esc(date)}</span></div></section>` : ''}
    </body></html>`;
  }
  async function exportPdf(report, client) {
    const brand = (await T.load(BRAND)) || {};
    const extra = { client: client || '' };
    try {
      const list = await api.radarList();
      const hit = list.find((p) => hostOf(p.site) === report.host.replace(/^www\./, ''));
      if (hit) { const p = await api.radarLoad(hit.id); const run = (p.runs || []).slice(-1)[0]; if (run && run.summary) extra.radar = { share: run.summary.share, answers: run.summary.answers, rank: run.summary.rank }; }
    } catch {}
    try { const sp = await T.load('speed'); if (sp) extra.speed = sp.results.filter((x) => !x.error && hostOf(x.url) === report.host.replace(/^www\./, '')); } catch {}
    try { const p = await api.printPdf(pdfHtml(report, brand, extra), `audit-${report.host}-${report.date.slice(0, 10)}.pdf`); if (p) toast('PDF enregistré'); } catch (e) { toast('PDF impossible : ' + e.message); }
  }

  function brandModal(after) {
    T.load(BRAND).then((b0) => {
      const b = b0 || { agency: '', color: '#ff6363', logo: '', contact: '' };
      UI.modal(`<h2>Votre marque sur les rapports</h2><p>Vos clients reçoivent un PDF à votre nom, sans mention de VANTIX.</p>
        <label class="opt"><span>Nom de votre agence ou de votre activité</span><input class="field" id="bAg" value="${esc(b.agency)}"></label>
        <label class="opt"><span>Contact affiché (e-mail, téléphone, site)</span><input class="field" id="bCt" value="${esc(b.contact)}"></label>
        <label class="opt"><span>Couleur principale</span><input type="color" id="bCol" value="${esc(b.color || '#ff6363')}" style="width:80px;height:38px;background:none;border:0"></label>
        <label class="opt"><span>Logo (PNG, JPG ou SVG, moins de 500 Ko)</span><input type="file" id="bLogo" accept="image/png,image/jpeg,image/svg+xml"></label>
        ${b.logo ? `<img src="${esc(b.logo)}" alt="Logo actuel" style="max-height:48px;max-width:200px;object-fit:contain;align-self:flex-start;background:#fff;padding:6px;border-radius:8px">` : ''}
        <div class="acts"><button class="ghostbtn" data-close type="button">Annuler</button><button class="btn" id="bSave" type="button">Enregistrer</button></div>`, (m, close) => {
        let logo = b.logo;
        $('#bLogo', m).addEventListener('change', (e) => { const f = e.target.files[0]; if (!f) return; if (f.size > 500000) { toast('Logo trop lourd (500 Ko maximum).'); return; } const rd = new FileReader(); rd.onload = () => { logo = rd.result; toast('Logo prêt'); }; rd.readAsDataURL(f); });
        $('#bSave', m).addEventListener('click', async () => { await T.save(BRAND, { agency: $('#bAg', m).value.trim(), contact: $('#bCt', m).value.trim(), color: $('#bCol', m).value, logo }); toast('Marque enregistrée'); close(); after && after(); });
      });
    });
  }

  // =====================================================================================
  // 12. CLIENTS
  // =====================================================================================
  async function openClients(el, focusId) {
    const clients = (await T.load(CLIENTS)) || [];
    let reports = []; try { reports = await api.listReports(); } catch {}
    const latest = (site) => reports.filter((r) => hostOf(r.host) === hostOf(site)).sort((a, b) => b.date.localeCompare(a.date))[0];
    const brand = await T.load(BRAND);
    if (focusId) { const c = clients.find((x) => x.id === focusId); if (c) return clientPage(el, c, clients, latest); }
    el.innerHTML = `<div class="radar"><span class="label">Clients</span><h1>Tous vos clients, au même endroit</h1>
      <p class="lede">Regroupez les sites de chaque client, suivez leur score, lancez une analyse et envoyez un rapport PDF à votre marque en un clic.</p>
      <div class="sec"><div class="secrow"><h2>Vos clients</h2><div class="toolbar" style="margin:0"><button class="ghostbtn" id="clBrand" type="button">${brand && brand.agency ? 'Marque : ' + esc(brand.agency) : 'Votre marque sur les rapports'}</button><button class="btn" id="clNew" type="button">Nouveau client</button></div></div>
      ${clients.length ? `<div class="cards">${clients.map((c) => { const scores = c.sites.map(latest).filter(Boolean); const avg = scores.length ? Math.round(scores.reduce((s, r) => s + r.scores.global, 0) / scores.length) : null; return `<button class="rcard" data-cl="${esc(c.id)}"><b>${esc(c.name)}</b><div class="row"><span>${c.sites.length} site${c.sites.length > 1 ? 's' : ''}</span>${avg != null ? `<span style="color:var(--text)">score moyen ${avg}</span>` : '<span>jamais analysé</span>'}</div><span class="muted" style="font-size:12px">${esc(c.sites.map(hostOf).join(', '))}</span></button>`; }).join('')}</div>` : '<p class="empty">Ajoutez votre premier client, par exemple SPOTIQ avec getspotiq.com.</p>'}</div></div>`;
    $('#clBrand', el).addEventListener('click', () => brandModal(() => openClients(el)));
    $('#clNew', el).addEventListener('click', () => editClient(el, null, clients));
    $$('[data-cl]', el).forEach((b) => b.addEventListener('click', () => openClients(el, b.dataset.cl)));
  }
  function editClient(el, c, clients) {
    const isNew = !c; c = c || { id: 'c' + Date.now().toString(36), name: '', sites: [], contact: '', notes: '' };
    UI.modal(`<h2>${isNew ? 'Nouveau client' : 'Modifier le client'}</h2>
      <label class="opt"><span>Nom</span><input class="field" id="cName" value="${esc(c.name)}"></label>
      <label class="opt"><span>Sites, un par ligne</span><textarea class="field" id="cSites" rows="4" spellcheck="false">${esc(c.sites.join('\n'))}</textarea></label>
      <label class="opt"><span>Contact</span><input class="field" id="cContact" value="${esc(c.contact)}"></label>
      <label class="opt"><span>Notes</span><textarea class="field" id="cNotes" rows="3">${esc(c.notes)}</textarea></label>
      <p class="err" id="cErr"></p>
      <div class="acts">${isNew ? '' : '<button class="ghostbtn" id="cDel" type="button">Supprimer</button>'}<button class="ghostbtn" data-close type="button">Annuler</button><button class="btn" id="cSave" type="button">Enregistrer</button></div>`, (m, close) => {
      const del = $('#cDel', m); if (del) del.addEventListener('click', async () => { await T.save(CLIENTS, clients.filter((x) => x.id !== c.id)); close(); openClients(el); });
      $('#cSave', m).addEventListener('click', async () => {
        const name = $('#cName', m).value.trim(), sites = [...new Set($('#cSites', m).value.split(/\s+/).map((s) => T.origin(s)).filter(Boolean))];
        if (!name) { $('#cErr', m).textContent = 'Indiquez un nom.'; return; }
        Object.assign(c, { name, sites, contact: $('#cContact', m).value.trim(), notes: $('#cNotes', m).value.trim() });
        const list = clients.filter((x) => x.id !== c.id).concat([c]).sort((a, b) => a.name.localeCompare(b.name, 'fr'));
        await T.save(CLIENTS, list); close(); openClients(el, c.id);
      });
    });
  }
  async function clientPage(el, c, clients, latest) {
    const schedules = (await T.load('schedules')) || [];
    let radars = []; try { radars = await api.radarList(); } catch {}
    el.innerHTML = `<header class="rhead"><div><span class="label">Client</span><h1>${esc(c.name)}</h1><p class="rmeta">${esc(c.contact || '')}${c.notes ? ' · ' + esc(c.notes) : ''}</p></div>
      <div class="ractions"><button class="ghostbtn" id="cBack" type="button">Tous les clients</button><button class="ghostbtn" id="cEdit" type="button">Modifier</button></div></header>
      <div class="tabbody">${c.sites.length ? c.sites.map((s) => { const r = latest(s), sch = schedules.find((x) => hostOf(x.url) === hostOf(s)), rad = radars.find((x) => hostOf(x.site) === hostOf(s)); return `<div class="card schcard"><div class="secrow" style="margin:0"><div><b style="font-weight:400;font-size:20px">${esc(hostOf(s))}</b>
        <p class="muted" style="margin:4px 0 0;font-size:13px">${r ? `Score <b style="color:var(--text);font-weight:400">${r.scores.global}</b> · SEO ${r.scores.seo} · GEO ${r.scores.geo} · analysé le ${new Date(r.date).toLocaleDateString('fr-FR')}` : 'Jamais analysé'}${rad && rad.lastShare != null ? ` · cité par les IA dans ${String(rad.lastShare).replace('.', ',')} % des réponses` : ''}${sch ? ` · surveillé ${sch.freq === 'weekly' ? 'chaque semaine' : 'chaque jour'}` : ''}</p></div>
        <div class="toolbar" style="margin:0">${r ? `<button class="ghostbtn" data-open="${esc(r.id)}" type="button">Rapport</button><button class="ghostbtn" data-pdf="${esc(r.id)}" type="button">PDF</button>` : ''}<button class="btn" data-an="${esc(s)}" type="button">Analyser</button>${sch ? '' : `<button class="ghostbtn" data-watch="${esc(s)}" type="button">Surveiller</button>`}</div></div></div>`; }).join('') : '<p class="empty">Aucun site pour ce client.</p>'}</div>`;
    $('#cBack', el).addEventListener('click', () => openClients(el));
    $('#cEdit', el).addEventListener('click', () => editClient(el, c, clients));
    $$('[data-open]', el).forEach((b) => b.addEventListener('click', async () => { try { window.__vxOpenReport(await api.loadReport(b.dataset.open)); } catch { toast('Rapport introuvable.'); } }));
    $$('[data-pdf]', el).forEach((b) => b.addEventListener('click', async () => { try { exportPdf(await api.loadReport(b.dataset.pdf), c.name); } catch { toast('Rapport introuvable.'); } }));
    $$('[data-an]', el).forEach((b) => b.addEventListener('click', () => { UI.show('v-home'); $('#url').value = b.dataset.an; $('#launch').requestSubmit(); }));
    $$('[data-watch]', el).forEach((b) => b.addEventListener('click', async () => { const list = (await T.load('schedules')) || []; list.push({ id: 's' + Date.now().toString(36), url: b.dataset.watch, freq: 'weekly', maxPages: 500, active: true, history: [] }); await T.save('schedules', list); toast('Surveillance hebdomadaire ajoutée'); clientPage(el, c, clients, latest); }));
  }

  T.register({ id: 'clients', label: 'Clients', group: 'Agence', icon: 'M16 19v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1M9.5 10a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zM21 19v-1a4 4 0 0 0-3-3.9M16 3.1a3.5 3.5 0 0 1 0 6.8', open: openClients });
  VX.agency = { exportPdf, pdfHtml, brandModal };
})();
