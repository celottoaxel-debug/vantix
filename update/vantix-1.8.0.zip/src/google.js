// VANTIX — connexion à Google Search Console (processus principal).
// OAuth « application de bureau » : le navigateur s'ouvre, l'utilisateur accepte, Google renvoie vers une adresse locale
// (127.0.0.1) que VANTIX écoute un court instant. Le jeton de rafraîchissement est chiffré par le système.
'use strict';
const http = require('http');
const crypto = require('crypto');

const SCOPE = 'https://www.googleapis.com/auth/webmasters.readonly';
const AUTH = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN = 'https://oauth2.googleapis.com/token';
const API = 'https://www.googleapis.com/webmasters/v3';

const b64url = (buf) => buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');

function page(title, text) {
  return `<!doctype html><html lang="fr"><meta charset="utf-8"><title>VANTIX</title><body style="margin:0;display:grid;place-items:center;height:100vh;background:#040506;color:#e6e6e6;font:16px/1.6 -apple-system,Segoe UI,Roboto,sans-serif"><div style="max-width:440px;padding:24px;text-align:center"><div style="color:#ff6363;font-size:28px">▼</div><h1 style="font-weight:400;font-size:26px">${title}</h1><p style="color:#9c9c9d">${text}</p></div></body></html>`;
}

/**
 * Ouvre la page d'autorisation Google et attend le retour sur 127.0.0.1.
 * openUrl : fonction qui ouvre le navigateur ; renvoie { refresh_token, access_token, expires_in }.
 */
function authorize({ clientId, clientSecret, openUrl, fetcher = fetch, timeoutMs = 5 * 60 * 1000 }) {
  if (!clientId) return Promise.reject(new Error('Connexion Google non configurée.'));
  const verifier = b64url(crypto.randomBytes(48));
  const challenge = b64url(crypto.createHash('sha256').update(verifier).digest());
  const state = b64url(crypto.randomBytes(16));
  return new Promise((resolve, reject) => {
    let done = false;
    const finish = (err, val) => { if (done) return; done = true; clearTimeout(timer); setTimeout(() => server.close(), 300); err ? reject(err) : resolve(val); };
    const server = http.createServer(async (req, res) => {
      const u = new URL(req.url, 'http://127.0.0.1');
      if (u.pathname !== '/') { res.writeHead(404); res.end(); return; }
      const code = u.searchParams.get('code'), err = u.searchParams.get('error');
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
      if (err || u.searchParams.get('state') !== state || !code) {
        res.end(page('Connexion annulée', 'Vous pouvez fermer cet onglet et réessayer depuis VANTIX.'));
        finish(new Error(err === 'access_denied' ? 'Connexion refusée.' : 'Connexion interrompue.'));
        return;
      }
      try {
        const port = server.address().port;
        const body = new URLSearchParams({ code, client_id: clientId, redirect_uri: `http://127.0.0.1:${port}`, grant_type: 'authorization_code', code_verifier: verifier });
        if (clientSecret) body.set('client_secret', clientSecret);
        const r = await fetcher(TOKEN, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: body.toString() });
        const j = await r.json().catch(() => ({}));
        if (!r.ok || !j.refresh_token) throw new Error(j.error_description || j.error || 'jeton refusé par Google');
        res.end(page('C’est connecté', 'Votre Search Console est reliée à VANTIX. Vous pouvez fermer cet onglet.'));
        finish(null, j);
      } catch (e) { res.end(page('Connexion impossible', String(e.message || e))); finish(e); }
    });
    const timer = setTimeout(() => finish(new Error('Délai dépassé : la connexion n’a pas été terminée.')), timeoutMs);
    server.on('error', (e) => finish(e));
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      const q = new URLSearchParams({ client_id: clientId, redirect_uri: `http://127.0.0.1:${port}`, response_type: 'code', scope: SCOPE, access_type: 'offline', prompt: 'consent', code_challenge: challenge, code_challenge_method: 'S256', state });
      openUrl(`${AUTH}?${q}`);
    });
  });
}

/** Client API avec rafraîchissement automatique du jeton d'accès. */
function client({ clientId, clientSecret, refreshToken, fetcher = fetch }) {
  let access = null, until = 0;
  async function token() {
    if (access && Date.now() < until - 60000) return access;
    const body = new URLSearchParams({ client_id: clientId, refresh_token: refreshToken, grant_type: 'refresh_token' });
    if (clientSecret) body.set('client_secret', clientSecret);
    const r = await fetcher(TOKEN, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: body.toString() });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.access_token) { const e = new Error(j.error === 'invalid_grant' ? 'La connexion Google a expiré : reconnectez la Search Console.' : (j.error_description || 'jeton refusé')); e.expired = j.error === 'invalid_grant'; throw e; }
    access = j.access_token; until = Date.now() + (j.expires_in || 3600) * 1000;
    return access;
  }
  async function call(path, body) {
    const t = await token();
    const r = await fetcher(API + path, { method: body ? 'POST' : 'GET', headers: { authorization: 'Bearer ' + t, ...(body ? { 'content-type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error((j.error && j.error.message) || 'erreur Search Console ' + r.status); e.status = r.status; throw e; }
    return j;
  }
  return {
    sites: async () => ((await call('/sites')).siteEntry || []).filter((s) => s.permissionLevel !== 'siteUnverifiedUser').map((s) => ({ siteUrl: s.siteUrl, permission: s.permissionLevel })),
    /** Requête searchAnalytics avec pagination (25 000 lignes par page, `max` lignes au total). */
    async query(siteUrl, body, max = 100000) {
      const rows = [];
      for (let start = 0; start < max; start += 25000) {
        const j = await call(`/sites/${encodeURIComponent(siteUrl)}/searchAnalytics/query`, { ...body, rowLimit: Math.min(25000, max - start), startRow: start });
        rows.push(...(j.rows || []));
        if (!j.rows || j.rows.length < 25000) break;
      }
      return rows;
    },
  };
}

module.exports = { authorize, client, SCOPE };
