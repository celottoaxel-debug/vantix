// VANTIX — fond animé sobre : deux halos de lumière (corail et bleu nuit) qui dérivent très lentement,
// une poussière de petits triangles qui monte doucement, et un balayage de lumière discret toutes les 24 s.
// Léger : rendu en basse résolution, 30 images/s au plus (10 quand la fenêtre n'est pas au premier plan),
// pause quand VANTIX est réduit, image fixe si « réduire les animations » est activé. Désactivable (vx-bg = off).
(function () {
  'use strict';
  const canvas = document.getElementById('vxbg');
  if (!canvas) return;
  const ctx = canvas.getContext('2d', { alpha: false });
  const RM = matchMedia('(prefers-reduced-motion: reduce)');
  const BG = '#040506';
  const SCALE = 0.6; // le flou des halos rend la basse résolution invisible
  let W = 0, H = 0, raf = 0, last = 0, t0 = performance.now(), enabled = true;
  try { enabled = localStorage.getItem('vx-bg') !== 'off'; } catch {}

  // halos : couleur, opacité, rayon (part de la diagonale), trajectoire lente (périodes en secondes)
  const GLOWS = [
    { c: [255, 99, 99], a: 0.11, r: 0.42, x: [0.78, 0.16, 71], y: [0.12, 0.12, 53] },
    { c: [20, 60, 163], a: 0.22, r: 0.55, x: [0.18, 0.14, 89], y: [0.82, 0.12, 61] },
    { c: [69, 35, 36], a: 0.22, r: 0.35, x: [0.55, 0.25, 113], y: [0.5, 0.2, 97] },
  ];
  const glowSprites = GLOWS.map((g) => {
    const c = document.createElement('canvas'); c.width = c.height = 256;
    const x = c.getContext('2d'); const gr = x.createRadialGradient(128, 128, 0, 128, 128, 128);
    gr.addColorStop(0, `rgba(${g.c.join(',')},${g.a})`); gr.addColorStop(0.45, `rgba(${g.c.join(',')},${g.a * 0.45})`); gr.addColorStop(1, `rgba(${g.c.join(',')},0)`);
    x.fillStyle = gr; x.fillRect(0, 0, 256, 256); return c;
  });

  // poussière de triangles : surtout gris, quelques-uns corail
  const N = 46;
  const parts = [];
  const rand = (a, b) => a + Math.random() * (b - a);
  function spawn(p, anywhere) {
    p.x = Math.random(); p.y = anywhere ? Math.random() : 1.05;
    p.s = rand(3, 9); p.v = rand(0.004, 0.012); p.drift = rand(-0.004, 0.004);
    p.rot = rand(0, Math.PI * 2); p.vr = rand(-0.15, 0.15);
    p.coral = Math.random() < 0.14; p.a = p.coral ? rand(0.16, 0.32) : rand(0.05, 0.14);
    p.tw = rand(0, Math.PI * 2);
    return p;
  }
  for (let i = 0; i < N; i++) parts.push(spawn({}, true));

  function resize() {
    W = Math.max(1, Math.round(innerWidth * SCALE)); H = Math.max(1, Math.round(innerHeight * SCALE));
    canvas.width = W; canvas.height = H;
  }

  function tri(x, y, s, rot) {
    ctx.beginPath();
    for (let i = 0; i < 3; i++) { const a = rot + (i * 2 * Math.PI) / 3; ctx[i ? 'lineTo' : 'moveTo'](x + s * Math.cos(a), y + s * Math.sin(a)); }
    ctx.closePath();
  }

  function frame(now, dt) {
    const t = (now - t0) / 1000;
    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = BG; ctx.fillRect(0, 0, W, H);
    // halos
    ctx.globalCompositeOperation = 'lighter';
    const diag = Math.hypot(W, H);
    GLOWS.forEach((g, i) => {
      const cx = (g.x[0] + g.x[1] * Math.sin((t * 2 * Math.PI) / g.x[2])) * W;
      const cy = (g.y[0] + g.y[1] * Math.cos((t * 2 * Math.PI) / g.y[2])) * H;
      const r = g.r * diag * (1 + 0.06 * Math.sin(t / 7 + i));
      ctx.drawImage(glowSprites[i], cx - r, cy - r, r * 2, r * 2);
    });
    // balayage de lumière, une fois toutes les 24 s
    const sweep = (t % 24) / 24;
    if (sweep < 0.35) {
      const k = sweep / 0.35, x = (-0.3 + k * 1.6) * W, a = Math.sin(k * Math.PI) * 0.035;
      const gr = ctx.createLinearGradient(x - W * 0.25, 0, x + W * 0.25, H * 0.4);
      gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, `rgba(255,236,236,${a})`); gr.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = gr; ctx.fillRect(0, 0, W, H);
    }
    // triangles
    ctx.globalCompositeOperation = 'source-over';
    ctx.lineWidth = 1; ctx.lineJoin = 'round';
    for (const p of parts) {
      if (dt) { p.y -= p.v * dt; p.x += p.drift * dt; p.rot += p.vr * dt; if (p.y < -0.05 || p.x < -0.05 || p.x > 1.05) spawn(p, false); }
      const fade = Math.min(1, (1.05 - p.y) * 6, (p.y + 0.05) * 6);
      const a = p.a * fade * (0.75 + 0.25 * Math.sin(t * 0.8 + p.tw));
      ctx.strokeStyle = p.coral ? `rgba(255,99,99,${a})` : `rgba(198,198,200,${a})`;
      tri(p.x * W, p.y * H, p.s * SCALE * 1.4, p.rot); ctx.stroke();
    }
    // vignette : les bords restent très sombres, le contenu reste lisible
    const v = ctx.createRadialGradient(W * 0.55, H * 0.45, Math.min(W, H) * 0.2, W * 0.55, H * 0.45, diag * 0.7);
    v.addColorStop(0, 'rgba(4,5,6,0)'); v.addColorStop(1, 'rgba(4,5,6,.72)');
    ctx.fillStyle = v; ctx.fillRect(0, 0, W, H);
  }

  function loop(now) {
    raf = requestAnimationFrame(loop);
    const minGap = document.hasFocus() ? 1000 / 30 : 1000 / 10;
    if (now - last < minGap) return;
    const dt = last ? Math.min(0.2, (now - last) / 1000) : 0;
    last = now; frame(now, dt);
  }
  function start() { stop(); if (!enabled) { ctx.fillStyle = BG; ctx.fillRect(0, 0, W, H); return; } if (RM.matches) { frame(performance.now(), 0); return; } last = 0; raf = requestAnimationFrame(loop); }
  function stop() { if (raf) cancelAnimationFrame(raf); raf = 0; }

  resize(); start();
  addEventListener('resize', () => { resize(); if (!raf) frame(performance.now(), 0); });
  document.addEventListener('visibilitychange', () => (document.hidden ? stop() : start()));
  (RM.addEventListener ? RM.addEventListener('change', start) : RM.addListener(start));

  // interrupteur dans la barre latérale
  window.__vxBg = {
    get enabled() { return enabled; },
    set(on) { enabled = !!on; try { localStorage.setItem('vx-bg', enabled ? 'on' : 'off'); } catch {} start(); },
  };
  const sw = document.getElementById('bgToggle');
  if (sw) { sw.checked = enabled; sw.addEventListener('change', () => window.__vxBg.set(sw.checked)); }
})();
