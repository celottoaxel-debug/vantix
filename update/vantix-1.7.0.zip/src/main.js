// VANTIX Desktop — processus principal (Electron)
// Rôle : fenêtre, accès réseau sans restriction CORS, sauvegarde des rapports, export.
'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, safeStorage, Notification, session } = require('electron');
const fixer = require('./fixer');
const path = require('path');
const fs = require('fs');
const zlib = require('zlib');

// version réelle du code chargé (peut être plus récente que l'installateur, grâce aux mises à jour)
const APP_VERSION = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'package.json'), 'utf8')).version; } catch { return app.getVersion(); } })();
const UA = 'Mozilla/5.0 (compatible; VANTIXBot/1.0; +https://vantix.fr/bot)';
const MAX_REDIRECTS = 10;

let mainWin = null;
function createWindow() {
  const win = mainWin = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1024,
    minHeight: 680,
    backgroundColor: '#000000',
    title: 'VANTIX',
    titleBarStyle: process.platform === 'darwin' ? 'hiddenInset' : 'default',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  // liens externes : navigateur du système, jamais dans l'app
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://')) { e.preventDefault(); if (/^https?:\/\//.test(url)) shell.openExternal(url); }
  });
}

const updater = require('./updater').create({ getWindow: () => mainWin, version: APP_VERSION });
app.whenReady().then(() => {
  createWindow();
  updater.start();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// ---------- réseau ----------
function headersToObject(h) {
  const o = {};
  h.forEach((v, k) => { o[k.toLowerCase()] = v; });
  return o;
}

async function readLimited(res, maxBytes) {
  if (!res.body) return { buf: Buffer.alloc(0), truncated: false };
  const reader = res.body.getReader();
  const chunks = []; let total = 0; let truncated = false;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > maxBytes) { truncated = true; chunks.push(Buffer.from(value.slice(0, value.length - (total - maxBytes)))); try { await reader.cancel(); } catch {} break; }
    chunks.push(Buffer.from(value));
  }
  return { buf: Buffer.concat(chunks), truncated };
}

function decodeBody(buf, contentType) {
  let charset = 'utf-8';
  const m = /charset=([^;]+)/i.exec(contentType || '');
  if (m) charset = m[1].trim().toLowerCase();
  else {
    const head = buf.slice(0, 2048).toString('latin1');
    const mm = /<meta[^>]+charset=["']?([\w-]+)/i.exec(head);
    if (mm) charset = mm[1].toLowerCase();
  }
  try { return new TextDecoder(charset).decode(buf); } catch { return new TextDecoder('utf-8').decode(buf); }
}

// signatures de robots qu'on peut simuler (outil « Ce que l'IA voit »)
const AGENTS = {
  gptbot: 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; GPTBot/1.2; +https://openai.com/gptbot)',
  oaisearch: 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; OAI-SearchBot/1.0; +https://openai.com/searchbot)',
  claudebot: 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; ClaudeBot/1.0; +claudebot@anthropic.com)',
  perplexitybot: 'Mozilla/5.0 AppleWebKit/537.36 (KHTML, like Gecko; compatible; PerplexityBot/1.0; +https://perplexity.ai/perplexitybot)',
  googlebot: 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)',
};
async function fetchPage({ url, method = 'GET', maxBytes = 8 * 1024 * 1024, timeoutMs = 20000, wantBody = true, agent = null }) {
  const ua = (agent && AGENTS[agent]) || UA;
  const redirects = [];
  let current = url;
  const t0 = performance.now();
  let ttfb = null;
  try {
    for (let i = 0; i <= MAX_REDIRECTS; i++) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeoutMs);
      let res;
      try {
        res = await fetch(current, {
          method,
          redirect: 'manual',
          signal: ctrl.signal,
          headers: { 'user-agent': ua, accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'accept-encoding': 'gzip, deflate, br' },
        });
      } finally { clearTimeout(timer); }
      if (ttfb === null) ttfb = Math.round(performance.now() - t0);
      const headers = headersToObject(res.headers);
      if (res.status >= 300 && res.status < 400 && headers.location) {
        redirects.push({ url: current, status: res.status });
        current = new URL(headers.location, current).href;
        continue;
      }
      const contentType = headers['content-type'] || '';
      let body = null, bytes = Number(headers['content-length']) || 0, truncated = false;
      const isText = /text\/|html|xml|json|javascript/i.test(contentType) || contentType === '';
      if (wantBody && method === 'GET' && isText) {
        const r = await readLimited(res, maxBytes);
        bytes = r.buf.length; truncated = r.truncated;
        body = decodeBody(r.buf, contentType);
      } else {
        try { await res.body?.cancel(); } catch {}
      }
      return {
        ok: true, url, finalUrl: current, status: res.status, redirects, headers,
        contentType, timeMs: Math.round(performance.now() - t0), ttfbMs: ttfb, bytes, truncated, body,
      };
    }
    return { ok: false, url, finalUrl: current, status: 0, redirects, error: 'Trop de redirections (boucle probable)', timeMs: Math.round(performance.now() - t0) };
  } catch (e) {
    const code = (e.cause && e.cause.code) || '';
    const FR = { ENOTFOUND: 'Adresse introuvable', EAI_AGAIN: 'Adresse introuvable', ECONNREFUSED: 'Connexion refusée', ECONNRESET: 'Connexion coupée', ETIMEDOUT: 'Délai dépassé', UND_ERR_CONNECT_TIMEOUT: 'Délai de connexion dépassé', CERT_HAS_EXPIRED: 'Certificat SSL expiré', DEPTH_ZERO_SELF_SIGNED_CERT: 'Certificat SSL non reconnu', ERR_TLS_CERT_ALTNAME_INVALID: 'Certificat SSL invalide pour ce domaine', UNABLE_TO_VERIFY_LEAF_SIGNATURE: 'Certificat SSL incomplet' };
    const msg = e.name === 'AbortError' ? 'Délai dépassé' : FR[code] || code || e.message;
    return { ok: false, url, finalUrl: current, status: 0, redirects, error: msg, timeMs: Math.round(performance.now() - t0) };
  }
}

ipcMain.handle('vx:fetch', (_e, opts) => fetchPage({ ...opts, timeoutMs: Math.min(120000, Number(opts && opts.timeoutMs) || 20000) }));

// ---------- rapports ----------
const reportsDir = () => {
  const d = path.join(app.getPath('userData'), 'reports');
  fs.mkdirSync(d, { recursive: true });
  return d;
};

ipcMain.handle('vx:saveReport', (_e, report) => {
  const id = report.id;
  if (!/^[\w-]+$/.test(id)) throw new Error('identifiant invalide');
  const file = path.join(reportsDir(), id + '.json.gz');
  fs.writeFileSync(file, zlib.gzipSync(JSON.stringify(report)));
  return true;
});

ipcMain.handle('vx:listReports', () => {
  const d = reportsDir();
  const out = [];
  for (const f of fs.readdirSync(d)) {
    if (!f.endsWith('.json.gz')) continue;
    try {
      const r = JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(d, f))).toString('utf8'));
      out.push({ id: r.id, start: r.start, host: r.host, date: r.date, scores: r.scores, pages: r.pages.length });
    } catch {}
  }
  return out.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
});

ipcMain.handle('vx:loadReport', (_e, id) => {
  if (!/^[\w-]+$/.test(id)) throw new Error('identifiant invalide');
  return JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(reportsDir(), id + '.json.gz'))).toString('utf8'));
});

ipcMain.handle('vx:deleteReport', (_e, id) => {
  if (!/^[\w-]+$/.test(id)) throw new Error('identifiant invalide');
  const f = path.join(reportsDir(), id + '.json.gz');
  if (fs.existsSync(f)) fs.unlinkSync(f);
  return true;
});

ipcMain.handle('vx:export', async (e, { defaultName, content, filters }) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const { canceled, filePath } = await dialog.showSaveDialog(win, { defaultPath: defaultName, filters });
  if (canceled || !filePath) return null;
  fs.writeFileSync(filePath, content, 'utf8');
  shell.showItemInFolder(filePath);
  return filePath;
});

ipcMain.handle('vx:openExternal', (_e, url) => {
  if (/^https?:\/\//.test(url)) shell.openExternal(url);
});

ipcMain.handle('vx:version', () => APP_VERSION);
ipcMain.handle('vx:updateStatus', () => updater.status());
ipcMain.handle('vx:updateCheck', () => updater.check(true));
ipcMain.handle('vx:updateRestart', () => updater.restart());
ipcMain.handle('vx:updateHealthy', () => updater.healthy());

// ---------- corrections dans un dossier local ----------
ipcMain.handle('vx:pickFolder', async (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const { canceled, filePaths } = await dialog.showOpenDialog(win, { title: 'Dossier du site (celui qui contient la page d’accueil)', properties: ['openDirectory'] });
  return canceled ? null : filePaths[0];
});
ipcMain.handle('vx:scanFolder', (_e, { root, paths }) => fixer.scan(root, paths));
ipcMain.handle('vx:applyLocal', (_e, { root, ops }) => fixer.apply(root, ops));
ipcMain.handle('vx:undoLocal', (_e, { root, id }) => fixer.undo(root, id));
ipcMain.handle('vx:revealFolder', (_e, root) => shell.openPath(root));

// pack de corrections : un sous-dossier avec tous les fichiers
ipcMain.handle('vx:exportFolder', async (e, { name, files, title }) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const { canceled, filePaths } = await dialog.showOpenDialog(win, { title: title || 'Où enregistrer le pack de corrections ?', properties: ['openDirectory', 'createDirectory'] });
  if (canceled || !filePaths[0]) return null;
  const dir = path.join(filePaths[0], name.replace(/[^\w.-]/g, '_'));
  for (const f of files) {
    const abs = path.resolve(dir, f.rel);
    if (!abs.startsWith(path.resolve(dir))) continue;
    fs.mkdirSync(path.dirname(abs), { recursive: true });
    if (f.base64) fs.writeFileSync(abs, Buffer.from(String(f.content), 'base64')); else fs.writeFileSync(abs, f.content, 'utf8');
  }
  shell.openPath(dir);
  return dir;
});

// ---------- IA (optionnelle) : clé chiffrée par le système ----------
const keyFile = () => path.join(app.getPath('userData'), 'ai-key.bin');
ipcMain.handle('vx:aiHasKey', () => fs.existsSync(keyFile()));
ipcMain.handle('vx:aiSetKey', (_e, key) => {
  key = String(key || '').trim();
  if (!key) { if (fs.existsSync(keyFile())) fs.unlinkSync(keyFile()); return false; }
  if (!safeStorage.isEncryptionAvailable()) throw new Error('Le chiffrement du système n’est pas disponible.');
  fs.writeFileSync(keyFile(), safeStorage.encryptString(key));
  return true;
});
function readKey() {
  if (!fs.existsSync(keyFile())) return null;
  return safeStorage.decryptString(fs.readFileSync(keyFile()));
}
ipcMain.handle('vx:aiRewrite', async (_e, { model, items, brand, lang }) => {
  const key = readKey();
  if (!key) throw new Error('Aucune clé API enregistrée.');
  const out = [];
  for (let i = 0; i < items.length; i += 15) {
    const batch = items.slice(i, i + 15);
    const prompt = `Tu es un expert SEO et GEO. Pour chaque page ci-dessous, écris un nouveau title (50 à 60 caractères, sujet principal au début, puis " | ${brand}") et une meta description (130 à 155 caractères, phrase naturelle, bénéfice concret, sans guillemets ni emoji). Langue : ${lang}. Chaque title et chaque description doivent être uniques. N'invente aucun fait absent des données.
Réponds uniquement avec un tableau JSON : [{"url":"...","title":"...","description":"..."}]

Pages :
${JSON.stringify(batch)}`;
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: model || 'claude-haiku-5-5', max_tokens: 4000, messages: [{ role: 'user', content: prompt }] }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error((data.error && data.error.message) || ('Erreur API ' + res.status));
    const text = (data.content || []).map(c => c.text || '').join('');
    const m = text.match(/\[[\s\S]*\]/);
    if (!m) throw new Error('Réponse de l’IA illisible.');
    out.push(...JSON.parse(m[0]));
  }
  return out;
});

// ---------- Radar IA ----------
const radar = require('./radar');
const providerKeyFile = (p) => p === 'anthropic' ? keyFile() : path.join(app.getPath('userData'), `key-${p}.bin`);
function readProviderKey(p) {
  const f = providerKeyFile(p);
  if (!fs.existsSync(f)) return null;
  try { return safeStorage.decryptString(fs.readFileSync(f)); } catch { return null; }
}
ipcMain.handle('vx:keysStatus', () => Object.fromEntries([...Object.keys(radar.PROVIDERS), 'psi'].map((p) => [p, fs.existsSync(providerKeyFile(p))])));
ipcMain.handle('vx:setProviderKey', (_e, { provider, key }) => {
  if (!radar.PROVIDERS[provider] && provider !== 'psi') throw new Error('IA inconnue');
  const f = providerKeyFile(provider);
  key = String(key || '').trim();
  if (!key) { if (fs.existsSync(f)) fs.unlinkSync(f); return false; }
  if (!safeStorage.isEncryptionAvailable()) throw new Error('Le chiffrement du système n’est pas disponible.');
  fs.writeFileSync(f, safeStorage.encryptString(key));
  return true;
});
ipcMain.handle('vx:radarAsk', async (_e, { provider, model, question, lang }) => {
  try {
    return { ok: true, ...(await radar.ask({ provider, key: readProviderKey(provider), model, question, lang })) };
  } catch (e) {
    return { ok: false, provider, error: e.message || String(e), status: e.status || null };
  }
});
// ---------- IA générique pour les outils (Claude, sinon ChatGPT) ----------
const ai = require('./ai');
ipcMain.handle('vx:aiAvailable', () => ({ anthropic: !!readProviderKey('anthropic'), openai: !!readProviderKey('openai') }));
ipcMain.handle('vx:aiText', async (_e, opts) => {
  try {
    const r = await ai.complete({ ...(opts || {}), keys: { anthropic: readProviderKey('anthropic'), openai: readProviderKey('openai') } });
    return { ok: true, ...r, json: opts && opts.json ? ai.extractJson(r.text) : undefined };
  } catch (e) { return { ok: false, error: e.message || String(e), status: e.status || null }; }
});
// fichiers de l'extension navigateur (livrée avec l'application et ses mises à jour)
ipcMain.handle('vx:extensionFiles', () => {
  const root = path.join(__dirname, 'extension');
  const out = [];
  const walk = (d) => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { const abs = path.join(d, f.name); if (f.isDirectory()) walk(abs); else { const rel = path.relative(root, abs).split(path.sep).join('/'); const bin = /\.(png|ico)$/i.test(f.name); out.push({ rel, content: fs.readFileSync(abs).toString(bin ? 'base64' : 'utf8'), base64: bin }); } } };
  if (fs.existsSync(root)) walk(root);
  return out;
});
ipcMain.handle('vx:radarSuggest', async (_e, opts) => {
  const key = readProviderKey('anthropic');
  if (!key) throw new Error('Ajoutez d’abord une clé Claude pour générer des questions.');
  return radar.suggestQuestions({ ...opts, key });
});
const radarDir = () => { const d = path.join(app.getPath('userData'), 'radar'); fs.mkdirSync(d, { recursive: true }); return d; };
const radarFile = (id) => { if (!/^[\w-]+$/.test(id)) throw new Error('identifiant invalide'); return path.join(radarDir(), id + '.json'); };
ipcMain.handle('vx:radarList', () => {
  const out = [];
  for (const f of fs.readdirSync(radarDir())) {
    if (!f.endsWith('.json')) continue;
    try { const p = JSON.parse(fs.readFileSync(path.join(radarDir(), f), 'utf8')); const last = (p.runs || []).slice(-1)[0]; out.push({ id: p.id, brand: p.brand, site: p.site, auto: !!p.auto, runs: (p.runs || []).length, lastDate: last ? last.date : null, lastShare: last && last.summary ? last.summary.share : null }); } catch {}
  }
  return out.sort((a, b) => (b.lastDate || '').localeCompare(a.lastDate || ''));
});
ipcMain.handle('vx:radarLoad', (_e, id) => JSON.parse(fs.readFileSync(radarFile(id), 'utf8')));
ipcMain.handle('vx:radarSave', (_e, project) => {
  if (project.runs && project.runs.length > 90) project.runs = project.runs.slice(-90); // environ 3 mois d'historique quotidien
  fs.writeFileSync(radarFile(project.id), JSON.stringify(project));
  return true;
});
ipcMain.handle('vx:radarDelete', (_e, id) => { const f = radarFile(id); if (fs.existsSync(f)) fs.unlinkSync(f); return true; });

// ---------- Trafic : lecture des statistiques d'un site (ex. getspotiq.com/api/stats/traffic) ----------
const trafficFile = () => path.join(app.getPath('userData'), 'traffic.json');
const trafficTokenFile = (id) => { if (!/^[\w-]+$/.test(id)) throw new Error('identifiant invalide'); return path.join(app.getPath('userData'), `key-traffic-${id}.bin`); };
const trafficCacheFile = (id) => { if (!/^[\w-]+$/.test(id)) throw new Error('identifiant invalide'); return path.join(app.getPath('userData'), `traffic-cache-${id}.json`); };
const readTraffic = () => { try { return JSON.parse(fs.readFileSync(trafficFile(), 'utf8')); } catch { return []; } };
ipcMain.handle('vx:trafficList', () => readTraffic().map((c) => ({ ...c, hasToken: fs.existsSync(trafficTokenFile(c.id)) })));
ipcMain.handle('vx:trafficSave', (_e, { id, name, url, token }) => {
  if (!/^[\w-]+$/.test(id || '')) throw new Error('identifiant invalide');
  let u; try { u = new URL(/^https?:\/\//i.test(url) ? url : 'https://' + url); } catch { throw new Error('Adresse du site invalide.'); }
  const list = readTraffic().filter((c) => c.id !== id);
  list.push({ id, name: String(name || u.hostname).slice(0, 80), url: u.origin });
  fs.writeFileSync(trafficFile(), JSON.stringify(list));
  if (token) {
    if (!safeStorage.isEncryptionAvailable()) throw new Error('Le chiffrement du système n’est pas disponible.');
    fs.writeFileSync(trafficTokenFile(id), safeStorage.encryptString(String(token).trim()));
  }
  return true;
});
ipcMain.handle('vx:trafficDelete', (_e, id) => {
  fs.writeFileSync(trafficFile(), JSON.stringify(readTraffic().filter((c) => c.id !== id)));
  for (const f of [trafficTokenFile(id), trafficCacheFile(id)]) if (fs.existsSync(f)) fs.unlinkSync(f);
  return true;
});
async function trafficRequest(url, token, days) {
  const ctrl = new AbortController(); const timer = setTimeout(() => ctrl.abort(), 45000);
  try {
    const res = await fetch(`${url}/api/stats/traffic?days=${days}`, { headers: { authorization: 'Bearer ' + token, 'user-agent': UA }, signal: ctrl.signal });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data) return { ok: false, status: res.status, error: (data && data.error) || (res.status === 404 ? 'Le site ne propose pas encore les statistiques (la mise à jour SPOTIQ est-elle en ligne ?).' : 'Erreur ' + res.status) };
    return { ok: true, data };
  } catch (e) {
    return { ok: false, status: 0, error: e.name === 'AbortError' ? 'Le site n’a pas répondu à temps.' : 'Connexion impossible : ' + e.message };
  } finally { clearTimeout(timer); }
}
ipcMain.handle('vx:trafficTest', (_e, { url, token }) => trafficRequest(new URL(/^https?:\/\//i.test(url) ? url : 'https://' + url).origin, String(token || '').trim(), 7));
ipcMain.handle('vx:trafficFetch', async (_e, { id, days }) => {
  const c = readTraffic().find((x) => x.id === id);
  if (!c) return { ok: false, error: 'Connexion introuvable.' };
  let token = null; try { token = safeStorage.decryptString(fs.readFileSync(trafficTokenFile(id))); } catch {}
  if (!token) return { ok: false, error: 'Aucune clé d’accès enregistrée.' };
  days = Math.min(365, Math.max(1, Math.round(Number(days) || 30)));
  const r = await trafficRequest(c.url, token, days);
  let cache = {}; try { cache = JSON.parse(fs.readFileSync(trafficCacheFile(id), 'utf8')); } catch {}
  if (r.ok) { cache[days] = { fetchedAt: new Date().toISOString(), data: r.data }; fs.writeFileSync(trafficCacheFile(id), JSON.stringify(cache)); return { ...r, fetchedAt: cache[days].fetchedAt }; }
  // hors ligne ou erreur : on montre les derniers chiffres connus
  if (cache[days]) return { ok: true, data: cache[days].data, fetchedAt: cache[days].fetchedAt, stale: true, error: r.error };
  return r;
});

// ---------- stockage générique des outils (concurrents, Search Console, plans…) ----------
const toolFile = (name) => { if (!/^[\w-]{1,60}$/.test(name)) throw new Error('nom invalide'); const d = path.join(app.getPath('userData'), 'tools'); fs.mkdirSync(d, { recursive: true }); return path.join(d, name + '.json.gz'); };
ipcMain.handle('vx:storeGet', (_e, name) => { const f = toolFile(name); if (!fs.existsSync(f)) return null; try { return JSON.parse(zlib.gunzipSync(fs.readFileSync(f)).toString('utf8')); } catch { return null; } });
ipcMain.handle('vx:storeSet', (_e, { name, data }) => { const f = toolFile(name); if (data == null) { if (fs.existsSync(f)) fs.unlinkSync(f); return true; } fs.writeFileSync(f, zlib.gzipSync(JSON.stringify(data))); return true; });

// ---------- rendu d'une page comme un vrai navigateur (JavaScript exécuté) ----------
let _renderSes = null;
function renderSession() {
  if (_renderSes) return _renderSes;
  _renderSes = session.fromPartition('vantix-render'); // en mémoire, séparée de l'application
  _renderSes.setPermissionRequestHandler((_wc, _perm, cb) => cb(false));
  _renderSes.on('will-download', (e) => e.preventDefault());
  return _renderSes;
}
ipcMain.handle('vx:renderPage', async (_e, { url, waitMs = 2500 }) => {
  if (!/^https?:\/\//i.test(url || '')) throw new Error('Adresse invalide');
  const ses = renderSession();
  const win = new BrowserWindow({ show: false, width: 1280, height: 900, webPreferences: { session: ses, sandbox: true, contextIsolation: true, nodeIntegration: false, javascript: true, images: false } });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.setAudioMuted(true);
  const t0 = Date.now();
  try {
    await Promise.race([win.loadURL(url), new Promise((_, rej) => setTimeout(() => rej(new Error('Délai dépassé')), 45000))]);
    await new Promise((r) => setTimeout(r, Math.min(10000, waitMs)));
    const html = await win.webContents.executeJavaScript('document.documentElement.outerHTML', true);
    return { ok: true, url, finalUrl: win.webContents.getURL(), html, ms: Date.now() - t0 };
  } catch (e) {
    return { ok: false, url, error: e.message || String(e) };
  } finally { if (!win.isDestroyed()) win.destroy(); }
});

// ---------- notifications et lancement au démarrage (audits programmés) ----------
ipcMain.handle('vx:notify', (_e, { title, body }) => { if (Notification.isSupported()) new Notification({ title: String(title).slice(0, 120), body: String(body || '').slice(0, 400) }).show(); return true; });
ipcMain.handle('vx:getLoginItem', () => app.getLoginItemSettings().openAtLogin);
ipcMain.handle('vx:setLoginItem', (_e, on) => { app.setLoginItemSettings({ openAtLogin: !!on, openAsHidden: true }); return app.getLoginItemSettings().openAtLogin; });

// ---------- vitesse : PageSpeed Insights de Google (gratuit ; clé facultative pour plus de quota) ----------
ipcMain.handle('vx:psi', async (_e, { url, strategy = 'mobile' }) => {
  const key = readProviderKey('psi');
  const q = new URLSearchParams({ url, strategy: strategy === 'desktop' ? 'desktop' : 'mobile', locale: 'fr' });
  for (const c of ['performance', 'seo', 'accessibility', 'best-practices']) q.append('category', c);
  if (key) q.set('key', key);
  const r = await fetchPage({ url: 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?' + q.toString(), timeoutMs: 120000, maxBytes: 30 * 1024 * 1024 });
  if (!r.ok) return { ok: false, error: r.error };
  let data; try { data = JSON.parse(r.body || '{}'); } catch { return { ok: false, error: 'Réponse illisible de Google.' }; }
  if (data.error) return { ok: false, error: data.error.message || 'Erreur Google', status: data.error.code };
  return { ok: true, data };
});

// ---------- rapport PDF (mise en page imprimable générée par l'interface) ----------
ipcMain.handle('vx:printPdf', async (e, { html, defaultName }) => {
  const os = require('os');
  const tmp = path.join(os.tmpdir(), `vantix-print-${process.pid}-${Date.now()}.html`);
  fs.writeFileSync(tmp, String(html), 'utf8');
  const win = new BrowserWindow({ show: false, width: 1000, height: 1400, webPreferences: { javascript: false, sandbox: true, contextIsolation: true, nodeIntegration: false } });
  try {
    await win.loadFile(tmp);
    const pdf = await win.webContents.printToPDF({ printBackground: true, pageSize: 'A4', margins: { top: 0, bottom: 0, left: 0, right: 0 } });
    const r = await dialog.showSaveDialog(BrowserWindow.fromWebContents(e.sender), { defaultPath: String(defaultName || 'rapport.pdf').replace(/[\\/:*?"<>|]/g, '_'), filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if (r.canceled || !r.filePath) return null;
    fs.writeFileSync(r.filePath, pdf);
    shell.openPath(r.filePath);
    return r.filePath;
  } finally { if (!win.isDestroyed()) win.destroy(); try { fs.unlinkSync(tmp); } catch {} }
});
