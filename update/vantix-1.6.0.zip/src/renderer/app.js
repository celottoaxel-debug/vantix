// VANTIX Desktop — interface
(function () {
  'use strict';
  const VX = window.VX, U = VX.util, esc = VX.report.esc;
  const api = window.vantix;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const fmt = (n) => (n == null ? '' : Number(n).toLocaleString('fr-FR'));
  const short = (url, host) => { try { const u = new URL(url); return (u.host === host ? '' : u.host) + u.pathname + u.search; } catch { return url; } };
  const SEV_LABEL = { critique: 'Critique', important: 'Important', mineur: 'Mineur', info: 'Info' };
  const scoreColor = (v) => v >= 80 ? 'var(--ok)' : v >= 55 ? 'var(--warn)' : 'var(--crit)';
  const verdict = (v) => v >= 85 ? 'Excellent' : v >= 70 ? 'Bon, quelques réglages' : v >= 50 ? 'À améliorer' : 'Prioritaire';

  let report = null, tab = 'overview', cancelled = false, running = false, lastApply = null;
  const pageIndex = new Map();

  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('on'), 2600); }
  function show(id) { $$('.view').forEach(v => { v.hidden = v.id !== id; }); $('#main').scrollTop = 0; }

  if (!api) {
    document.body.insertAdjacentHTML('afterbegin', '<p style="position:fixed;top:0;left:0;right:0;z-index:99;margin:0;padding:10px;background:#ff5a6e;color:#000;text-align:center">Ouvrez VANTIX depuis l’application de bureau pour lancer une analyse.</p>');
  }
  if (api && api.version) api.version().then(v => { $('#sideFoot').textContent = 'VANTIX Desktop ' + v; }).catch(() => {});

  // ---------- historique ----------
  async function refreshHistory() {
    if (!api) return;
    let list = [];
    try { list = await api.listReports(); } catch {}
    $('#history').innerHTML = list.length ? list.map(r => `<button class="hitem" data-id="${esc(r.id)}" aria-current="${report && report.id === r.id}"><b>${esc(r.host)}</b><small>${new Date(r.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} · ${fmt(r.pages)} pages</small><span class="sc" style="color:${scoreColor(r.scores.global)};background:var(--panel-2)">${r.scores.global}</span></button>`).join('') : '<p class="muted" style="padding:0 8px;font-size:13px">Vos analyses apparaîtront ici.</p>';
    const recent = list.slice(0, 6);
    $('#recentWrap').hidden = !recent.length;
    $('#recentCards').innerHTML = recent.map(r => `<button class="rcard" data-id="${esc(r.id)}"><b>${esc(r.host)}</b><div class="row"><span style="color:${scoreColor(r.scores.global)}">Score ${r.scores.global}</span><span>SEO ${r.scores.seo}</span><span>GEO ${r.scores.geo}</span></div><span class="muted" style="font-size:12px">${new Date(r.date).toLocaleString('fr-FR')}</span></button>`).join('');
  }
  document.addEventListener('click', async (e) => {
    const h = e.target.closest('.hitem, .rcard');
    if (!h) return;
    try { openReport(await api.loadReport(h.dataset.id)); } catch { toast('Impossible d’ouvrir ce rapport.'); }
  });
  $('#newBtn').addEventListener('click', () => { if (running) return toast('Une analyse est en cours.'); report = null; show('v-home'); refreshHistory(); setTimeout(() => $('#url').focus(), 50); });

  // ---------- lancement ----------
  $('#launch').addEventListener('submit', (e) => {
    e.preventDefault();
    const v = $('#url').value.trim();
    const n = U.normalizeUrl(/^https?:\/\//i.test(v) ? v : 'https://' + v);
    if (!v || /\s/.test(v) || !n || !/\./.test(new URL(n).hostname) && !/localhost|\d/.test(new URL(n).hostname)) { $('#urlErr').textContent = 'Entrez l’adresse d’un site, par exemple monsite.fr'; return; }
    $('#urlErr').textContent = '';
    runCrawl({
      url: v, maxPages: +$('#o-max').value, concurrency: +$('#o-conc').value,
      respectRobots: $('#o-robots').checked, useSitemaps: $('#o-sitemap').checked,
      checkExternal: $('#o-ext').checked, includeSubdomains: $('#o-sub').checked,
    });
  });

  async function runCrawl(opts) {
    if (!api) return;
    running = true; cancelled = false;
    show('v-run');
    $('#runHost').textContent = opts.url.replace(/^https?:\/\//, '');
    $('#runLog').innerHTML = ''; $('#runPhase').textContent = 'Exploration';
    const t0 = Date.now(); let lastUi = 0;
    const timer = setInterval(() => { $('#runTime').textContent = Math.round((Date.now() - t0) / 1000) + ' s'; }, 500);
    const log = (m) => { const l = $('#runLog'); const d = document.createElement('div'); d.textContent = new Date().toLocaleTimeString('fr-FR') + '  ' + m; l.appendChild(d); while (l.childNodes.length > 300) l.firstChild.remove(); l.scrollTop = l.scrollHeight; };
    const progress = (p) => {
      const now = performance.now(); if (now - lastUi < 100) return; lastUi = now;
      if (p.phase === 'pages') {
        $('#runPhase').textContent = 'Exploration des pages';
        $('#runPages').textContent = fmt(p.done); $('#runQueue').textContent = fmt(p.queued);
        $('#runBar').style.width = Math.min(100, (p.done / Math.max(1, Math.min(p.max, p.done + p.queued))) * 100) + '%';
      } else {
        $('#runPhase').textContent = p.phase === 'external' ? 'Vérification des liens externes' : 'Vérification des liens internes';
        $('#runQueue').textContent = fmt(p.total - p.done);
        $('#runBar').style.width = (p.done / Math.max(1, p.total)) * 100 + '%';
      }
      $('#runCurrent').textContent = p.current || '';
    };
    try {
      const raw = await VX.crawler.crawl(opts, { fetchPage: (o) => api.fetchPage(o), log, progress, isCancelled: () => cancelled });
      log('Analyse des résultats…'); $('#runPhase').textContent = 'Diagnostic';
      await U.sleep(30);
      const r = VX.analyze.buildReport(raw);
      try { await api.saveReport(r); } catch { toast('Le rapport n’a pas pu être enregistré.'); }
      openReport(r);
      toast(cancelled ? 'Analyse arrêtée : résultats partiels' : `Analyse terminée : ${fmt(r.stats.pages)} adresses`);
    } catch (err) {
      show('v-home');
      $('#urlErr').textContent = err.message || String(err);
    } finally {
      clearInterval(timer); running = false; refreshHistory();
    }
  }
  $('#stopBtn').addEventListener('click', () => { cancelled = true; $('#stopBtn').textContent = 'Arrêt en cours…'; setTimeout(() => { $('#stopBtn').textContent = 'Arrêter et voir les résultats'; }, 4000); });

  // ---------- rapport ----------
  function openReport(r) {
    report = r; pageIndex.clear(); lastApply = null;
    try { r.fixes = VX.fixes.buildFixes(r); } catch (e) { console.error(e); r.fixes = null; }
    for (const p of r.pages) pageIndex.set(p.url, p);
    $('#rDate').textContent = new Date(r.date).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' });
    $('#rHost').textContent = r.host;
    $('#rMeta').textContent = `${fmt(r.stats.pages)} adresses explorées · ${fmt(r.stats.words)} mots lus · ${fmt(r.stats.links)} liens indexés · ${Math.round(r.durationMs / 1000)} s` + (r.cancelled ? ' · analyse arrêtée avant la fin' : r.truncated ? ' · limite de pages atteinte' : '');
    const counts = { issues: r.issues.filter(i => i.sev !== 'info').length, fixes: r.fixes ? r.fixes.count : 0, pages: r.pages.length, links: r.links.length };
    $$('#tabs button').forEach(b => { const c = counts[b.dataset.tab]; b.innerHTML = b.textContent.replace(/\s*\d[\d\s ]*$/, '') + (c != null ? `<span class="count">${fmt(c)}</span>` : ''); });
    show('v-report'); setTab('overview'); refreshHistory();
  }
  function setTab(t) {
    tab = t;
    $$('#tabs button').forEach(b => b.setAttribute('aria-selected', String(b.dataset.tab === t)));
    const R = { overview, issues: issuesTab, fixes: fixesTab, pages: pagesTab, links: linksTab, words: wordsTab, geo: geoTab, tech: techTab, maillage: (el) => (VX.linking ? VX.linking.tab(el, report) : (el.innerHTML = '<p class="empty">Indisponible.</p>')) };
    $('#tabbody').innerHTML = ''; R[t]($('#tabbody'));
    $('#main').scrollTop = 0;
  }
  $('#tabs').addEventListener('click', (e) => { const b = e.target.closest('button[data-tab]'); if (b) setTab(b.dataset.tab); });

  const ring = (v, size, color) => { const r = size / 2 - 7, c = 2 * Math.PI * r; return `<svg class="ring" viewBox="0 0 ${size} ${size}" aria-hidden="true"><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="var(--panel-3)" stroke-width="7"/><circle class="arc" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${color}" stroke-width="7" stroke-linecap="round" stroke-dasharray="${(c * v / 100).toFixed(1)} ${c.toFixed(1)}" transform="rotate(-90 ${size / 2} ${size / 2})"/></svg>`; };

  // --- vue d'ensemble ---
  function overview(el) {
    const r = report, s = r.scores, st = r.stats;
    const card = (k, label, color, main) => main
      ? `<div class="score main"><div class="ringwrap">${ring(s[k], 112, color)}<div><span class="t">${label}</span><div class="n">${s[k]}<span class="muted" style="font-size:24px"> / 100</span></div><div class="verdict">${verdict(s[k])}</div></div></div><p class="muted" style="max-width:44ch;margin:0;font-size:14px">Moyenne pondérée : SEO (technique, contenu, liens) pour 65 %, GEO pour 35 %. Corrigez d\u2019abord les problèmes critiques, ils pèsent le plus.</p></div>`
      : `<div class="score"><span class="t">${label}</span><div class="ringwrap">${ring(s[k], 74, color)}<div><div class="n">${s[k]}</div><div class="verdict">${verdict(s[k])}</div></div></div></div>`;
    const top = r.issues.filter(i => i.sev !== 'info').slice(0, 6);
    el.innerHTML = `
      <div class="sec"><div class="scores">${card('global', 'Score VANTIX', 'var(--iris)', true)}${card('seo', 'SEO', '#a98bff')}${card('geo', 'GEO (IA)', 'var(--spark)')}${card('technique', 'Technique', '#4d8bff')}${card('contenu', 'Contenu', 'var(--ok)')}${card('liens', 'Liens', '#d14cff')}</div></div>
      <div class="sec"><h2>Ce qui a été analysé</h2><div class="tiles">
        ${[[st.pages, 'adresses explorées'], [st.indexable, 'pages indexables'], [st.words, 'mots lus'], [st.links, 'liens indexés'], [st.uniqueExternal, 'sites externes vérifiés'], [st.images, 'images'], [st.sitemapUrls, 'adresses dans le sitemap'], [st.avgTime + ' ms', 'temps de réponse moyen']].map(([b, t]) => `<div class="tile"><b>${typeof b === 'number' ? fmt(b) : b}</b><span>${t}</span></div>`).join('')}
        <button class="tile ${st.critical ? 'bad' : 'good'}" data-go="issues"><b>${st.critical}</b><span>problèmes critiques</span></button>
        <button class="tile ${st.brokenLinks ? 'bad' : 'good'}" data-go="links"><b>${fmt(st.brokenLinks)}</b><span>liens cassés</span></button>
        <button class="tile ${st.errors ? 'bad' : 'good'}" data-go="pages"><b>${fmt(st.errors)}</b><span>pages en erreur</span></button>
      </div></div>
      <div class="sec"><h2>À corriger en premier</h2>${top.length ? top.map(issueHtml).join('') : '<p class="empty">Aucun problème détecté. Bravo.</p>'}
      ${r.issues.length > 6 ? `<button class="ghostbtn more" data-go="issues">Voir les ${r.issues.filter(i => i.sev !== 'info').length} problèmes</button>` : ''}</div>`;
    bindIssues(el);
    $$('[data-go]', el).forEach(b => b.addEventListener('click', () => setTab(b.dataset.go)));
  }

  // --- problèmes ---
  const issueState = { cat: 'all', sev: 'all' };
  function issueHtml(i) {
    const idx = report.issues.indexOf(i);
    return `<div class="issue" data-i="${idx}"><button type="button" aria-expanded="false"><span class="sevbar sev-${i.sev}"></span><span><div class="ti">${esc(i.title)}</div><div class="ca">${SEV_LABEL[i.sev]} · ${esc(report.categories[i.cat])}</div></span><span class="nb">${fmt(i.items.length)}</span><span class="chev">›</span></button></div>`;
  }
  function bindIssues(root) {
    $$('.issue > button', root).forEach(b => b.addEventListener('click', () => {
      const box = b.parentElement, i = report.issues[+box.dataset.i];
      const open = !box.classList.contains('open');
      box.classList.toggle('open', open); b.setAttribute('aria-expanded', String(open));
      if (!open) { box.querySelector('.issue-body')?.remove(); return; }
      const body = document.createElement('div'); body.className = 'issue-body';
      let shown = 0;
      const renderItems = () => {
        const next = i.items.slice(shown, shown + 100); shown += next.length;
        $('.items', body).insertAdjacentHTML('beforeend', next.map(it => `<li><span class="u">${pageIndex.has(it.url) ? `<button type="button" data-page="${esc(it.url)}">${esc(short(it.url, report.host))}</button>` : esc(short(it.url, report.host))}</span><span class="d">${esc(it.detail || '')}</span></li>`).join(''));
        const m = $('.more', body); if (m) m.hidden = shown >= i.items.length;
      };
      const fixable = FIXABLE.has(i.id);
      body.innerHTML = `<p class="why">${esc(i.why)}</p><div class="fix"><b>Comment corriger</b>${esc(i.fix)}${fixable ? '<div style="margin-top:10px"><button class="btn" type="button" data-gofix>Voir les corrections prêtes</button></div>' : ''}</div><ul class="items"></ul><button class="ghostbtn more" type="button">Afficher plus</button>`;
      box.appendChild(body); renderItems();
      const gf = $('[data-gofix]', body); if (gf) gf.addEventListener('click', () => setTab('fixes'));
      $('.more', body).addEventListener('click', renderItems);
    }));
  }
  function issuesTab(el) {
    const cats = [['all', 'Tout'], ...Object.entries(report.categories)];
    const sevs = [['all', 'Toutes gravités'], ['critique', 'Critique'], ['important', 'Important'], ['mineur', 'Mineur'], ['info', 'Info']];
    const draw = () => {
      const list = report.issues.filter(i => (issueState.cat === 'all' || i.cat === issueState.cat) && (issueState.sev === 'all' || i.sev === issueState.sev));
      $('#ilist', el).innerHTML = list.length ? list.map(issueHtml).join('') : '<p class="empty">Aucun problème dans ce filtre.</p>';
      bindIssues($('#ilist', el));
      $$('[data-cat]', el).forEach(b => b.setAttribute('aria-pressed', String(b.dataset.cat === issueState.cat)));
      $$('[data-sev]', el).forEach(b => b.setAttribute('aria-pressed', String(b.dataset.sev === issueState.sev)));
    };
    el.innerHTML = `<div class="filters">${cats.map(([k, l]) => `<button class="chip" data-cat="${k}">${esc(l)}</button>`).join('')}<span class="sep"></span>${sevs.map(([k, l]) => `<button class="chip" data-sev="${k}">${l}</button>`).join('')}</div><div id="ilist"></div>`;
    $$('[data-cat]', el).forEach(b => b.addEventListener('click', () => { issueState.cat = b.dataset.cat; draw(); }));
    $$('[data-sev]', el).forEach(b => b.addEventListener('click', () => { issueState.sev = b.dataset.sev; draw(); }));
    draw();
  }

  // --- tableau générique (tri, recherche, pagination) ---
  function table(el, { cols, rows, onRow, empty }) {
    let sortKey = null, dir = -1, limit = 300;
    const draw = () => {
      const data = sortKey ? [...rows].sort((a, b) => { const c = cols.find(x => x.key === sortKey); const va = c.sort ? c.sort(a) : a[sortKey], vb = c.sort ? c.sort(b) : b[sortKey]; return (va > vb ? 1 : va < vb ? -1 : 0) * dir; }) : rows;
      const slice = data.slice(0, limit);
      el.innerHTML = rows.length ? `<div class="tablewrap"><table><thead><tr>${cols.map(c => `<th data-k="${c.key}" ${sortKey === c.key ? `aria-sort="${dir > 0 ? 'ascending' : 'descending'}"` : ''}>${c.label}</th>`).join('')}</tr></thead><tbody>${slice.map((r, i) => `<tr class="${onRow ? 'click' : ''}" data-r="${i}">${cols.map(c => `<td class="${c.cls || ''}">${c.render ? c.render(r) : esc(r[c.key])}</td>`).join('')}</tr>`).join('')}</tbody></table></div><div class="tablefoot"><span>${fmt(slice.length)} sur ${fmt(data.length)}</span>${data.length > limit ? '<button class="ghostbtn" type="button" data-more>Afficher 300 de plus</button>' : ''}</div>` : `<p class="empty">${empty || 'Rien à afficher.'}</p>`;
      $$('th', el).forEach(th => th.addEventListener('click', () => { if (sortKey === th.dataset.k) dir = -dir; else { sortKey = th.dataset.k; dir = -1; } draw(); }));
      const m = $('[data-more]', el); if (m) m.addEventListener('click', () => { limit += 300; draw(); });
      if (onRow) $$('tbody tr', el).forEach(tr => tr.addEventListener('click', () => onRow(slice[+tr.dataset.r])));
    };
    draw();
  }
  const statusCell = (s, redirect) => !s ? '<span class="st-err">aucune réponse</span>' : `<span class="${s >= 400 ? 'st-err' : s >= 300 || redirect ? 'st-redir' : 'st-ok'}">${s}</span>`;

  // --- pages ---
  function pagesTab(el) {
    const host = report.host;
    el.innerHTML = `<div class="toolbar"><input class="search" id="pq" placeholder="Rechercher une adresse, un titre, un mot…" aria-label="Rechercher"><select class="sel" id="pf" aria-label="Filtrer">
      <option value="all">Toutes les adresses</option><option value="indexable">Pages indexables</option><option value="errors">En erreur</option><option value="redirects">Redirections</option><option value="orphans">Orphelines</option><option value="thin">Contenu mince (moins de 300 mots)</option><option value="slow">Lentes (plus de 1,5 s)</option><option value="noindex">Noindex</option><option value="issues">Avec problèmes</option></select></div><div id="pt"></div>`;
    const F = {
      all: () => true, indexable: p => p.html && p.status < 300 && !p.noindex, errors: p => !p.status || p.status >= 400, redirects: p => p.isRedirect,
      orphans: p => p.html && p.status < 300 && p.depth === null && p.url !== report.home, thin: p => p.html && p.status < 300 && p.mainWordCount < 300, slow: p => p.timeMs > 1500, noindex: p => p.noindex, issues: p => (p.issueIds || []).length,
    };
    const draw = () => {
      const q = $('#pq', el).value.trim().toLowerCase(), f = F[$('#pf', el).value];
      const rows = report.pages.filter(p => f(p) && (!q || (p.url + ' ' + (p.title || '') + ' ' + (p.h1 || []).join(' ') + ' ' + (p.keywords || []).map(k => k[0]).join(' ')).toLowerCase().includes(q)));
      table($('#pt', el), {
        rows, onRow: (p) => openPage(p.url),
        cols: [
          { key: 'url', label: 'Adresse', cls: 'url', render: p => esc(short(p.url, host)) },
          { key: 'status', label: 'Statut', render: p => statusCell(p.status, p.isRedirect) },
          { key: 'title', label: 'Title', render: p => p.title ? esc(p.title.slice(0, 90)) : (p.html && p.status < 300 ? '<span class="st-err">manquant</span>' : '') },
          { key: 'mainWordCount', label: 'Mots', cls: 'num', render: p => fmt(p.mainWordCount) },
          { key: 'depth', label: 'Profondeur', cls: 'num', sort: p => p.depth ?? 99, render: p => p.depth ?? (p.html ? '<span class="st-redir">orpheline</span>' : '') },
          { key: 'inlinks', label: 'Liens entrants', cls: 'num', render: p => fmt(p.inlinks) },
          { key: 'timeMs', label: 'Temps', cls: 'num', render: p => p.timeMs ? fmt(p.timeMs) + ' ms' : '' },
          { key: 'issues', label: 'Problèmes', cls: 'num', sort: p => (p.issueIds || []).length, render: p => (p.issueIds || []).length || '' },
        ],
      });
    };
    $('#pq', el).addEventListener('input', draw); $('#pf', el).addEventListener('change', draw); draw();
  }

  // --- liens ---
  function linksTab(el) {
    const host = report.host;
    el.innerHTML = `<div class="toolbar"><input class="search" id="lq" placeholder="Rechercher dans les adresses ou le texte des liens…" aria-label="Rechercher"><select class="sel" id="lf" aria-label="Filtrer">
      <option value="all">Tous les liens</option><option value="broken">Cassés</option><option value="internal">Internes</option><option value="external">Externes</option><option value="redirect">Redirigés</option><option value="nofollow">nofollow / sponsored / ugc</option><option value="empty">Sans texte</option><option value="generic">Texte vague</option><option value="other">mailto, tel, javascript</option></select></div><div id="lt"></div>`;
    const F = {
      all: () => true, broken: l => l.kind === 'page' && l.status !== null && (l.status >= 400 || l.status === 0), internal: l => l.internal, external: l => l.kind === 'page' && !l.internal,
      redirect: l => l.redirect, nofollow: l => l.nofollow || l.sponsored || l.ugc, empty: l => l.empty, generic: l => l.generic, other: l => l.kind !== 'page',
    };
    const draw = () => {
      const q = $('#lq', el).value.trim().toLowerCase(), f = F[$('#lf', el).value];
      const rows = report.links.filter(l => f(l) && (!q || (l.from + ' ' + l.to + ' ' + (l.anchor || '')).toLowerCase().includes(q)));
      table($('#lt', el), {
        rows, onRow: (l) => openPage(l.from),
        cols: [
          { key: 'from', label: 'Depuis', cls: 'url', render: l => esc(short(l.from, host)) },
          { key: 'to', label: 'Vers', cls: 'url', render: l => esc(l.kind === 'page' ? short(l.to, host) : l.to) },
          { key: 'anchor', label: 'Texte du lien', render: l => l.anchor ? esc(l.anchor.slice(0, 70)) : '<span class="muted">(vide)</span>' },
          { key: 'internal', label: 'Type', render: l => l.kind !== 'page' ? l.kind : l.internal ? 'interne' : 'externe' },
          { key: 'status', label: 'Statut', sort: l => l.status ?? -1, render: l => l.kind !== 'page' ? '' : l.status === null ? '<span class="muted">non vérifié</span>' : statusCell(l.status, l.redirect) + (l.error && !l.status ? ' ' + esc(l.error) : '') },
          { key: 'nofollow', label: 'Attributs', render: l => [l.nofollow && 'nofollow', l.sponsored && 'sponsored', l.ugc && 'ugc'].filter(Boolean).join(', ') },
        ],
      });
    };
    $('#lq', el).addEventListener('input', draw); $('#lf', el).addEventListener('change', draw); draw();
  }

  // --- mots ---
  function wordsTab(el) {
    const kw = report.keywords, max = kw[0] ? kw[0][1] : 1, bmax = report.bigrams[0] ? report.bigrams[0][1] : 1;
    el.innerHTML = `<div class="words"><div class="card"><h3>Mots les plus présents <span class="muted mono">occurrences · pages</span></h3>${kw.slice(0, 80).map(([w, c, n]) => `<div class="wbar"><span class="w">${esc(w)}</span><span class="track"><i style="width:${(c / max) * 100}%"></i></span><span class="c">${fmt(c)}</span><span class="p">${n} p.</span></div>`).join('') || '<p class="empty">Pas assez de texte.</p>'}</div>
      <div class="card"><h3>Expressions de deux mots</h3>${report.bigrams.slice(0, 50).map(([w, c]) => `<div class="wbar" style="grid-template-columns:1fr 90px 54px"><span class="w">${esc(w)}</span><span class="track"><i style="width:${(c / bmax) * 100}%"></i></span><span class="c">${fmt(c)}</span></div>`).join('') || '<p class="empty">Aucune expression répétée.</p>'}
      <h3 style="margin-top:28px">Lecture</h3><ul class="checks">
        <li><span></span><span>Mots lus sur l’ensemble du site</span><b>${fmt(report.stats.words)}</b></li>
        <li><span></span><span>Moyenne par page indexable</span><b>${fmt(report.stats.avgWords)}</b></li>
        <li><span></span><span>Pages de moins de 300 mots</span><b>${fmt(report.pages.filter(p => p.html && p.status < 300 && !p.noindex && p.mainWordCount < 300).length)}</b></li>
      </ul></div></div>`;
  }

  // --- GEO ---
  function geoTab(el) {
    const r = report, content = r.pages.filter(p => p.html && p.status < 300 && !p.noindex && p.mainWordCount >= 300);
    const pct = (f) => content.length ? Math.round(content.filter(f).length / content.length * 100) : 0;
    const row = (ok, label, val) => `<li><span class="dot" style="background:${ok === null ? 'var(--text-3)' : ok ? 'var(--ok)' : 'var(--crit)'}"></span><span>${label}</span><b class="mono">${val}</b></li>`;
    el.innerHTML = `<div class="grid2">
      <div class="card"><h3>Les IA peuvent-elles lire le site ?</h3><ul class="checks">${r.robots.ai.map(b => row(b.home, esc(b.bot), b.home ? 'autorisé' : 'bloqué')).join('')}</ul></div>
      <div class="card"><h3>Signaux d’identité</h3><ul class="checks">
        ${row(r.llms.ok, 'Fichier llms.txt', r.llms.ok ? 'présent' : 'absent')}
        ${row(r.llms.full ? true : null, 'Fichier llms-full.txt', r.llms.full ? 'présent' : 'absent')}
        ${row(r.pages.some(p => p.schema && p.schema.hasOrg), 'Balisage Organization', r.pages.some(p => p.schema && p.schema.hasOrg) ? 'présent' : 'absent')}
        ${row(r.stats.schemaTypes.length > 0, 'Types Schema.org trouvés', r.stats.schemaTypes.length)}
        ${row(r.pages.some(p => p.schema && p.schema.hasBreadcrumb), 'Fil d’Ariane balisé', r.pages.some(p => p.schema && p.schema.hasBreadcrumb) ? 'oui' : 'non')}
      </ul>${r.stats.schemaTypes.length ? `<p class="muted" style="font-size:13px;margin:12px 0 0">${r.stats.schemaTypes.map(esc).join(' · ')}</p>` : ''}</div>
      <div class="card"><h3>Pages faciles à citer <span class="muted mono">${content.length} pages de contenu</span></h3><ul class="checks">
        ${row(pct(p => p.geo.answerFirst) >= 60, 'Réponse courte en début de page', pct(p => p.geo.answerFirst) + ' %')}
        ${row(pct(p => p.geo.questionHeadings > 0) >= 50, 'Intertitres en forme de question', pct(p => p.geo.questionHeadings > 0) + ' %')}
        ${row(pct(p => p.geo.lists + p.geo.tables > 0) >= 60, 'Listes ou tableaux', pct(p => p.geo.lists + p.geo.tables > 0) + ' %')}
        ${row(pct(p => p.geo.stats > 0) >= 50, 'Chiffres précis', pct(p => p.geo.stats > 0) + ' %')}
        ${row(pct(p => p.geo.sources > 0) >= 40, 'Sources citées', pct(p => p.geo.sources > 0) + ' %')}
        ${row(pct(p => p.geo.author) >= 50, 'Auteur identifié', pct(p => p.geo.author) + ' %')}
        ${row(pct(p => p.geo.dated) >= 50, 'Date affichée', pct(p => p.geo.dated) + ' %')}
        ${row(pct(p => p.schema.types.length > 0) >= 70, 'Données structurées', pct(p => p.schema.types.length > 0) + ' %')}
      </ul></div>
      <div class="card"><h3>llms.txt</h3>${r.llms.ok ? `<pre class="pre">${esc(r.llms.preview)}</pre>` : `<p class="muted">Pas de fichier. Exemple à placer sur ${esc(r.origin)}/llms.txt :</p><pre class="pre"># ${esc(r.host)}\n\n> Une phrase qui dit qui vous êtes et ce que vous faites.\n\n## Pages principales\n${r.pages.filter(p => p.html && p.depth !== null && p.depth <= 1 && p.title && !p.noindex).slice(0, 8).map(p => `- [${esc(p.title.slice(0, 60))}](${esc(p.url)})`).join('\n')}</pre>`}</div>
    </div>`;
  }

  // --- technique ---
  function techTab(el) {
    const r = report, html = r.pages.filter(p => p.html);
    const codes = {}; for (const p of r.pages) { const k = !p.status ? 'erreur' : String(p.status)[0] + 'xx'; codes[k] = (codes[k] || 0) + 1; }
    const buckets = [[0, 200], [200, 500], [500, 1000], [1000, 1500], [1500, 3000], [3000, 1e9]];
    const counts = buckets.map(([a, b]) => html.filter(p => p.timeMs >= a && p.timeMs < b).length), hmax = Math.max(1, ...counts);
    const blabel = ['< 200 ms', '200-500', '500-1000', '1-1,5 s', '1,5-3 s', '> 3 s'];
    const home = r.pages.find(p => p.url === r.home) || html[0] || { headers: {} };
    const row = (ok, label, val) => `<li><span class="dot" style="background:${ok === null ? 'var(--text-3)' : ok ? 'var(--ok)' : 'var(--crit)'}"></span><span>${label}</span><b class="mono">${esc(val)}</b></li>`;
    el.innerHTML = `<div class="grid2">
      <div class="card"><h3>Codes de réponse</h3><ul class="checks">${Object.entries(codes).sort().map(([k, v]) => row(k === '2xx' ? true : k === '3xx' ? null : false, k, fmt(v))).join('')}</ul></div>
      <div class="card"><h3>Vitesse de réponse des pages</h3><div class="hist">${counts.map((c, i) => `<div><span>${c}</span><i style="height:${(c / hmax) * 100}%"></i><span>${blabel[i]}</span></div>`).join('')}</div><p class="muted" style="font-size:13px">Moyenne ${fmt(r.stats.avgTime)} ms · premier octet ${fmt(r.stats.avgTtfb)} ms · poids HTML moyen ${fmt(Math.round(r.stats.avgBytes / 1024))} Ko</p></div>
      <div class="card"><h3>Sécurité et serveur (accueil)</h3><ul class="checks">
        ${row(r.home.startsWith('https:'), 'HTTPS', r.home.startsWith('https:') ? 'oui' : 'non')}
        ${row(!!home.headers.hsts, 'HSTS', home.headers.hsts ? 'oui' : 'non')}
        ${row(!!home.headers.encoding, 'Compression', home.headers.encoding || 'aucune')}
        ${row(home.headers.cache ? true : null, 'Cache-Control', home.headers.cache || 'absent')}
        ${row(!!home.headers.xcto, 'X-Content-Type-Options', home.headers.xcto ? 'oui' : 'non')}
        ${row(!!home.headers.csp, 'Content-Security-Policy', home.headers.csp ? 'oui' : 'non')}
        ${row(null, 'Serveur', home.headers.server || 'non indiqué')}
      </ul></div>
      <div class="card"><h3>Versions du site</h3><ul class="checks">${r.variants.length ? r.variants.map(v => row(v.redirectsToHome || !v.status ? true : false, esc(v.url), v.redirectsToHome ? 'redirige ✓' : v.status ? 'répond ' + v.status : 'inaccessible')).join('') : '<li><span></span><span class="muted">Rien à vérifier pour cette adresse.</span><b></b></li>'}</ul></div>
      <div class="card"><h3>Sitemaps <span class="muted mono">${fmt(r.sitemap.count)} adresses</span></h3><ul class="checks">${r.sitemap.files.length ? r.sitemap.files.map(f => row(f.ok, esc(short(f.url, r.host)), f.ok ? fmt(f.count) + ' adresses' : 'statut ' + f.status)).join('') : row(false, 'Aucun sitemap trouvé', '')}</ul></div>
      <div class="card"><h3>robots.txt</h3>${r.robots.text ? `<pre class="pre">${esc(r.robots.text)}</pre>` : '<p class="muted">Aucun fichier robots.txt.</p>'}</div>
    </div>`;
  }

  // ---------- détail d'une page ----------
  function openPage(url) {
    const p = pageIndex.get(url); if (!p) return;
    const issues = report.issues.filter(i => (p.issueIds || []).includes(i.id));
    const len = (s, a, b) => s ? `${esc(s)} <span class="tag ${s.length < a || s.length > b ? 'important' : 'ok'}">${s.length} car.</span>` : '<span class="tag critique">manquant</span>';
    const out = (p.links || []).filter(l => l.kind === 'page');
    $('#drawerBody').innerHTML = `
      <div><h2>${esc(p.title || short(p.url, report.host))}</h2><p class="mono muted" style="margin:8px 0 0;overflow-wrap:anywhere">${esc(p.url)}</p>
      <p style="margin:12px 0 0"><button class="ghostbtn" type="button" id="openExt">Ouvrir dans le navigateur</button></p></div>
      ${issues.length ? `<div class="dsec"><h3>Problèmes sur cette page</h3>${issues.map(i => `<div style="display:flex;gap:10px;align-items:baseline;padding:6px 0"><span class="tag ${i.sev}">${SEV_LABEL[i.sev]}</span><span>${esc(i.title)}</span></div>`).join('')}</div>` : ''}
      <div class="dsec"><h3>Essentiel</h3><dl class="kv">
        <dt>Statut</dt><dd>${statusCell(p.status, p.isRedirect)}${p.redirectTo ? ' → ' + esc(p.redirectTo) : ''}${p.error ? ' · ' + esc(p.error) : ''}</dd>
        ${p.html ? `<dt>Title</dt><dd>${len(p.title, 30, 60)}</dd><dt>Description</dt><dd>${len(p.description, 70, 160)}</dd>
        <dt>Canonical</dt><dd>${p.canonical ? esc(p.canonical) + (p.canonical === p.url ? ' <span class="tag ok">elle-même</span>' : '') : '<span class="muted">absente</span>'}</dd>
        <dt>Indexation</dt><dd>${p.noindex ? '<span class="tag important">noindex</span>' : 'autorisée'}${p.nofollow ? ' · nofollow' : ''}</dd>
        <dt>Langue</dt><dd>${esc(p.lang || 'non déclarée')}</dd>
        <dt>Mots</dt><dd>${fmt(p.mainWordCount)} dans le contenu · ${fmt(p.wordCount)} au total · ${fmt(p.uniqueWords)} mots différents</dd>
        <dt>Lisibilité</dt><dd>${p.readability ?? 'n/a'}${p.readability != null ? '/100' : ''}</dd>
        <dt>Profondeur</dt><dd>${p.depth ?? 'orpheline'} · ${fmt(p.inlinks)} liens entrants · ${fmt(out.length)} liens sortants</dd>
        <dt>Dans le sitemap</dt><dd>${p.inSitemap ? 'oui' : 'non'}</dd>` : ''}
        <dt>Temps</dt><dd>${fmt(p.timeMs)} ms${p.ttfbMs ? ' · premier octet ' + fmt(p.ttfbMs) + ' ms' : ''}${p.bytes ? ' · ' + fmt(Math.round(p.bytes / 1024)) + ' Ko' : ''}${p.headers && p.headers.encoding ? ' · ' + esc(p.headers.encoding) : ''}</dd>
      </dl></div>
      ${p.html ? `
      ${p.focus ? `<div class="dsec"><h3>Sujet principal</h3><dl class="kv"><dt>Mot</dt><dd><b>${esc(p.focus.word)}</b> · ${p.focus.count} fois · ${p.focus.density} %</dd><dt>Présent dans</dt><dd>${['Title', 'H1', 'Description', 'URL'].map((l, i) => `<span class="tag ${[p.focus.inTitle, p.focus.inH1, p.focus.inDesc, p.focus.inUrl][i] ? 'ok' : 'mineur'}">${l}</span>`).join(' ')}</dd></dl></div>` : ''}
      <div class="dsec"><h3>Structure des titres</h3><div class="htree">${(p.headings || []).slice(0, 80).map(h => `<div style="padding-left:${(h.level - 1) * 14}px"><b>H${h.level}</b>${esc(h.text) || '<span class="st-err">(vide)</span>'}</div>`).join('') || '<p class="muted">Aucun titre.</p>'}</div></div>
      <div class="dsec"><h3>Mots de la page</h3>${(p.keywords || []).slice(0, 30).map(([w, c]) => `<span class="tag mineur" style="margin:0 6px 6px 0">${esc(w)} · ${c}</span>`).join('')}${(p.bigrams || []).length ? `<p class="muted" style="font-size:13px;margin-top:8px">${p.bigrams.map(([w, c]) => esc(w) + ' (' + c + ')').join(' · ')}</p>` : ''}</div>
      <div class="dsec"><h3>Signaux GEO</h3><dl class="kv">
        <dt>Réponse d’entrée</dt><dd>${p.geo.answerFirst ? '<span class="tag ok">oui</span>' : '<span class="tag mineur">non</span>'} ${esc(p.geo.firstParagraph.slice(0, 200))}</dd>
        <dt>Questions</dt><dd>${p.geo.questionHeadings} intertitres</dd><dt>Listes / tableaux</dt><dd>${p.geo.lists} éléments / ${p.geo.tables} tableaux</dd>
        <dt>Chiffres / sources</dt><dd>${p.geo.stats} / ${p.geo.sources}</dd><dt>Auteur / date</dt><dd>${p.geo.author ? 'oui' : 'non'} / ${p.geo.dated ? 'oui' : 'non'}</dd>
        <dt>Schema.org</dt><dd>${p.schema.types.length ? p.schema.types.map(esc).join(', ') : 'aucun'}${p.schema.errors ? ' <span class="tag critique">' + p.schema.errors + ' erreur(s)</span>' : ''}</dd>
      </dl></div>
      <div class="dsec"><h3>Images</h3><p class="muted" style="margin:0;font-size:13px">${p.images.total} images · ${p.images.noAlt} sans alt · ${p.images.emptyAlt} alt vide · ${p.images.noDims} sans dimensions</p></div>
      <div class="dsec"><h3>Textes des liens qui pointent ici</h3>${(p.anchorsIn || []).map(([a, c]) => `<span class="tag mineur" style="margin:0 6px 6px 0">${esc(a)} · ${c}</span>`).join('') || '<p class="muted" style="font-size:13px">Aucun lien interne n’y mène.</p>'}</div>
      <div class="dsec"><h3>Liens de la page (${out.length})</h3><div class="htree">${out.slice(0, 150).map(l => `<div>${l.internal ? '' : '<b>EXT</b>'}${esc(short(l.url, report.host))} <span class="muted">« ${esc(l.anchor || '') || '(vide)'} »</span></div>`).join('')}</div></div>` : ''}`;
    $('#drawer').hidden = false;
    $('#openExt').addEventListener('click', () => api && api.openExternal(p.url));
  }
  $('#drawerClose').addEventListener('click', () => { $('#drawer').hidden = true; });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { $('#drawer').hidden = true; $('#exportMenu').hidden = true; $('#modal').hidden = true; } });
  document.addEventListener('click', (e) => { const b = e.target.closest('[data-page]'); if (b) openPage(b.dataset.page); });

  // ---------- export ----------
  $('#exportBtn').addEventListener('click', (e) => { e.stopPropagation(); const m = $('#exportMenu'); m.hidden = !m.hidden; $('#exportBtn').setAttribute('aria-expanded', String(!m.hidden)); });
  document.addEventListener('click', (e) => { if (!e.target.closest('.menu')) $('#exportMenu').hidden = true; });
  $('#exportMenu').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-exp]'); if (!b || !report) return;
    $('#exportMenu').hidden = true;
    if (b.dataset.exp === 'pdf') { if (VX.agency) VX.agency.exportPdf(report); return; }
    const base = 'vantix-' + report.host.replace(/[^\w.-]/g, '_') + '-' + report.date.slice(0, 10);
    const R = VX.report;
    const map = {
      html: [base + '.html', R.html(report), [{ name: 'Page web', extensions: ['html'] }]],
      issues: [base + '-problemes.csv', R.issuesCsv(report), [{ name: 'CSV', extensions: ['csv'] }]],
      pages: [base + '-pages.csv', R.pagesCsv(report), [{ name: 'CSV', extensions: ['csv'] }]],
      links: [base + '-liens.csv', R.linksCsv(report), [{ name: 'CSV', extensions: ['csv'] }]],
      json: [base + '.json', JSON.stringify(report), [{ name: 'JSON', extensions: ['json'] }]],
    };
    const [name, content, filters] = map[b.dataset.exp];
    try { const p = await api.exportFile({ defaultName: name, content, filters }); if (p) toast('Exporté : ' + p.split(/[\\/]/).pop()); } catch { toast('L’export a échoué.'); }
  });
  $('#rerunBtn').addEventListener('click', () => { if (!report) return; $('#url').value = report.start; $('#launch').requestSubmit(); });


  // ================= CORRECTIONS =================
  const FIXABLE = new Set(['no_title', 'short_title', 'long_title', 'dup_title', 'no_desc', 'short_desc', 'long_desc', 'dup_desc', 'no_canonical', 'canonical_external', 'bad_canonical', 'multi_canonical', 'no_lang', 'no_viewport', 'no_og', 'img_alt', 'broken_internal', 'redirect_links', 'pages_4xx', 'redirect_chains', 'no_robots', 'robots_no_sitemap', 'ai_blocked', 'no_sitemap', 'sitemap_bad', 'sitemap_noindex', 'not_in_sitemap', 'no_llms', 'no_org', 'faq_schema', 'multi_title', 'no_h1']);
  const TYPE_LABEL = { title: 'title', description: 'description', canonical: 'canonical', lang: 'langue', viewport: 'viewport', head: 'balisage', alt: 'images', href: 'liens', manual: 'à faire à la main' };
  let rfmt = 'htaccess';

  function copyText(text) {
    navigator.clipboard.writeText(text).then(() => toast('Copié'), () => toast('Copie impossible'));
  }
  function modal(html, bind) {
    $('#modalCard').innerHTML = html; $('#modal').hidden = false;
    const close = () => { $('#modal').hidden = true; $('#modalCard').innerHTML = ''; };
    $$('[data-close]', $('#modalCard')).forEach(b => b.addEventListener('click', close));
    bind && bind($('#modalCard'), close);
    const f = $('input, select, button.btn', $('#modalCard')); if (f) f.focus();
    return close;
  }
  $('#modal').addEventListener('click', (e) => { if (e.target.id === 'modal') { $('#modal').hidden = true; } });

  function fixesTab(el) {
    const F = report.fixes;
    if (!F) { el.innerHTML = '<p class="empty">Impossible de préparer les corrections pour ce rapport.</p>'; return; }
    const enabledCount = F.pageFixes.reduce((s, p) => s + p.fixes.filter(f => f.enabled).length, 0);
    const neededFiles = F.siteFiles.filter(f => f.needed);
    const hasTextFixes = F.pageFixes.some(p => p.fixes.some(f => f.type === 'title' || f.type === 'description'));
    el.innerHTML = `
      <div class="fixhero"><div><span class="label">Correcteur</span><h2 style="margin-top:10px">${fmt(F.count)} corrections prêtes</h2>
        <p>${fmt(enabledCount)} sur les pages, ${neededFiles.length} fichier${neededFiles.length > 1 ? 's' : ''} du site, ${fmt(F.redirects.length)} redirection${F.redirects.length > 1 ? 's' : ''}. Vérifiez et modifiez les propositions, puis appliquez-les à votre site ou exportez-les.</p></div>
        <div class="acts">${hasTextFixes ? '<button class="ghostbtn" type="button" id="fxAi">Réécrire avec l’IA</button>' : ''}<button class="ghostbtn" type="button" id="fxPack">Exporter le pack</button><button class="btn" type="button" id="fxApply">Appliquer à un dossier du site</button></div></div>
      <div id="fxBanner"></div>
      <div class="sec"><h2>Fichiers du site</h2><div class="files">${F.siteFiles.map((f, i) => `<div class="fcard"><b>${esc(f.name)}</b><span class="tag ${f.needed ? 'important' : 'ok'}" style="align-self:flex-start">${f.needed ? 'à mettre à jour' : 'déjà correct'}</span><p>${esc(f.why)}</p><div class="row"><button class="mini" data-sf-view="${i}">Voir</button><button class="mini" data-sf-copy="${i}">Copier</button></div></div>`).join('')}
        ${F.orgTag ? `<div class="fcard"><b>Organization (JSON-LD)</b><span class="tag ${report.pages.some(p => p.schema && p.schema.hasOrg) ? 'ok' : 'important'}" style="align-self:flex-start">${report.pages.some(p => p.schema && p.schema.hasOrg) ? 'déjà présent' : 'à ajouter'}</span><p>Fait reconnaître la marque « ${esc(F.brand)} » par les IA. Ajouté automatiquement à l’accueil.</p><div class="row"><button class="mini" data-org-view>Voir</button><button class="mini" data-org-copy>Copier</button></div></div>` : ''}</div></div>
      ${F.redirects.length ? `<div class="sec"><h2>Redirections <small>${F.redirects.length}</small></h2>
        <div class="toolbar"><select class="sel" id="rfmt" aria-label="Format"><option value="htaccess">Apache (.htaccess) : Hostinger, OVH, o2switch…</option><option value="nginx">Nginx</option><option value="netlify">Netlify, Cloudflare Pages (_redirects)</option><option value="vercel">Vercel (vercel.json)</option></select><button class="ghostbtn" type="button" id="rcopy">Copier</button></div>
        <div class="tablewrap"><table><thead><tr><th>Ancienne adresse</th><th>Nouvelle adresse</th><th>Raison</th></tr></thead><tbody>${F.redirects.map(r => `<tr><td class="url">${esc(short(r.from, report.host))}</td><td class="url">${esc(short(r.to, report.host))}</td><td>${esc(r.why)}${r.confident ? '' : ' <span class="tag important">à vérifier</span>'}</td></tr>`).join('')}</tbody></table></div></div>` : ''}
      <div class="sec"><h2>Page par page <small>${F.pageFixes.length} pages</small></h2>
        <div class="filters"><button class="chip" data-all="1">Tout cocher</button><button class="chip" data-all="0">Tout décocher</button></div>
        <div id="pfList">${F.pageFixes.map((pf, i) => `<div class="pfix" data-pf="${i}"><button type="button" aria-expanded="false"><span><span class="pu">${esc(short(pf.url, report.host))}</span><br><span class="muted" style="font-size:13px">${[...new Set(pf.fixes.map(f => TYPE_LABEL[f.type]))].join(' · ')}</span></span><span class="nb mono" style="background:var(--panel-3);padding:6px 10px;border-radius:9px">${pf.fixes.filter(f => f.enabled).length}/${pf.fixes.length}</span></button></div>`).join('')}</div></div>`;

    // bannière du dernier passage (annuler)
    const banner = $('#fxBanner', el);
    if (lastApply && lastApply.report.id) {
      const r = lastApply.report;
      banner.innerHTML = `<div class="banner"><p><b>${fmt(r.done)} corrections appliquées</b> dans ${fmt(r.files.length)} fichiers${r.notFound.length ? ` · ${r.notFound.length} pages introuvables dans le dossier` : ''}. Une sauvegarde a été faite avant chaque modification.</p><div style="display:flex;gap:8px"><button class="ghostbtn" type="button" id="fxOpen">Ouvrir le dossier</button><button class="ghostbtn" type="button" id="fxUndo">Annuler ces corrections</button></div></div>`;
      $('#fxOpen', el).addEventListener('click', () => api.revealFolder(lastApply.root));
      $('#fxUndo', el).addEventListener('click', async () => {
        try { const u = await api.undoLocal(lastApply.root, r.id); toast(`Annulé : ${u.restored} fichiers restaurés`); lastApply = null; fixesTab(el); } catch (e) { toast(e.message); }
      });
    }

    // fichiers du site
    $$('[data-sf-view]', el).forEach(b => b.addEventListener('click', () => { const f = F.siteFiles[+b.dataset.sfView]; modal(`<h2>${esc(f.name)}</h2><pre class="pre" style="max-height:52vh">${esc(f.content)}</pre><div class="acts"><button class="ghostbtn" data-close>Fermer</button><button class="btn" id="mc">Copier</button></div>`, (m) => $('#mc', m).addEventListener('click', () => copyText(f.content))); }));
    $$('[data-sf-copy]', el).forEach(b => b.addEventListener('click', () => copyText(F.siteFiles[+b.dataset.sfCopy].content)));
    const ov = $('[data-org-view]', el); if (ov) ov.addEventListener('click', () => modal(`<h2>Organization</h2><p>À placer dans le &lt;head&gt; de la page d’accueil. Complétez-le si besoin (téléphone, adresse).</p><pre class="pre">${esc(F.orgTag)}</pre><div class="acts"><button class="ghostbtn" data-close>Fermer</button><button class="btn" id="mc">Copier</button></div>`, (m) => $('#mc', m).addEventListener('click', () => copyText(F.orgTag))));
    const oc = $('[data-org-copy]', el); if (oc) oc.addEventListener('click', () => copyText(F.orgTag));
    const rf = $('#rfmt', el); if (rf) { rf.value = rfmt; rf.addEventListener('change', () => { rfmt = rf.value; }); $('#rcopy', el).addEventListener('click', () => copyText(F.redirectFormats[rfmt])); }

    // pages
    const renderPf = (box) => {
      const pf = F.pageFixes[+box.dataset.pf];
      box.querySelector('.fxbody')?.remove();
      const body = document.createElement('div'); body.className = 'fxbody';
      body.innerHTML = pf.fixes.map((f, j) => {
        const big = f.type === 'head' || f.type === 'manual';
        const len = (f.type === 'title' || f.type === 'description') ? `<div class="len ${f.type === 'title' ? (f.proposed.length > 60 || f.proposed.length < 30 ? 'bad' : '') : (f.proposed.length > 160 || f.proposed.length < 70 ? 'bad' : '')}">${f.proposed.length} caractères</div>` : '';
        const cur = f.type === 'alt' ? `<div class="cur plain">${esc(short(f.current, report.host))}</div>` : f.current ? `<div class="cur">${esc(f.current)}</div>` : '';
        return `<div class="fx ${f.enabled ? '' : 'off'}" data-j="${j}"><input type="checkbox" ${f.enabled ? 'checked' : ''} aria-label="Inclure"><div class="lb">${esc(f.label)}${f.ai ? '<span class="ai-tag">IA</span>' : ''}<small>${esc(f.why)}${f.auto ? '' : ' · non appliqué automatiquement'}</small></div><div>${cur}${big ? `<textarea class="code" rows="5">${esc(f.proposed)}</textarea>` : `<textarea rows="${f.type === 'description' ? 3 : 1}">${esc(f.proposed)}</textarea>`}${len}</div></div>`;
      }).join('');
      box.appendChild(body);
      $$('.fx', body).forEach(row => {
        const f = pf.fixes[+row.dataset.j];
        row.querySelector('input[type=checkbox]').addEventListener('change', (e) => { f.enabled = e.target.checked; row.classList.toggle('off', !f.enabled); updateCount(box, pf); });
        const ta = row.querySelector('textarea');
        ta.addEventListener('input', () => { f.proposed = ta.value; const l = row.querySelector('.len'); if (l) { l.textContent = ta.value.length + ' caractères'; l.classList.toggle('bad', f.type === 'title' ? ta.value.length > 60 || ta.value.length < 30 : ta.value.length > 160 || ta.value.length < 70); } });
      });
    };
    const updateCount = (box, pf) => { box.querySelector('.nb').textContent = pf.fixes.filter(f => f.enabled).length + '/' + pf.fixes.length; };
    $$('.pfix > button', el).forEach(b => b.addEventListener('click', () => {
      const box = b.parentElement, open = b.getAttribute('aria-expanded') !== 'true';
      b.setAttribute('aria-expanded', String(open));
      if (open) renderPf(box); else box.querySelector('.fxbody')?.remove();
    }));
    $$('[data-all]', el).forEach(b => b.addEventListener('click', () => {
      const on = b.dataset.all === '1';
      F.pageFixes.forEach(pf => pf.fixes.forEach(f => { if (f.proposed) f.enabled = on; }));
      fixesTab(el);
    }));

    $('#fxPack', el).addEventListener('click', exportPack);
    $('#fxApply', el).addEventListener('click', () => applyToFolder(el));
    const ai = $('#fxAi', el); if (ai) ai.addEventListener('click', () => aiRewrite(el, ai));
  }

  async function exportPack() {
    if (!api || !api.exportFolder) return toast('Disponible dans l’application de bureau.');
    const files = VX.fixes.packFiles(report, report.fixes);
    const name = 'corrections-vantix-' + report.host.replace(/[^\w.-]/g, '_') + '-' + new Date().toISOString().slice(0, 10);
    try { const d = await api.exportFolder(name, files); if (d) toast('Pack enregistré : ' + files.length + ' fichiers'); } catch (e) { toast('L’export a échoué : ' + e.message); }
  }

  async function applyToFolder(el) {
    if (!api || !api.pickFolder) return toast('Disponible dans l’application de bureau.');
    const root = await api.pickFolder(); if (!root) return;
    const F = report.fixes;
    const paths = F.pageFixes.map(pf => { try { return new URL(pf.url).pathname; } catch { return '/'; } });
    let map = {};
    try { map = await api.scanFolder(root, paths); } catch (e) { return toast(e.message); }
    const found = paths.filter(p => map[p]).length;
    const nEdits = F.pageFixes.filter(pf => { try { return map[new URL(pf.url).pathname]; } catch { return false; } }).reduce((s, pf) => s + pf.fixes.filter(f => f.enabled && f.auto && f.proposed).length, 0);
    const needed = F.siteFiles.filter(f => f.needed);
    if (!found && !needed.length) return modal(`<h2>Aucune page trouvée</h2><p>Ce dossier ne contient pas les fichiers HTML de ${esc(report.host)}. Choisissez le dossier qui contient la page d’accueil (index.html).</p><p class="muted" style="font-size:14px">Site WordPress, Wix ou Shopify ? Utilisez plutôt « Exporter le pack » : il contient chaque correction à recopier, page par page.</p><div class="acts"><button class="btn" data-close>Compris</button></div>`);
    modal(`<h2>Appliquer les corrections</h2>
      <p class="mono" style="font-size:12px;overflow-wrap:anywhere">${esc(root)}</p>
      <ul><li><b>${found}</b> pages sur ${paths.length} trouvées dans ce dossier</li><li><b>${nEdits}</b> corrections dans ces pages</li></ul>
      <label class="chk"><input type="checkbox" id="mFiles" ${needed.length ? 'checked' : ''}><span>Écrire les fichiers du site (${needed.map(f => esc(f.name)).join(', ') || 'aucun nécessaire'})</span></label>
      ${F.redirects.length ? `<label class="chk"><input type="checkbox" id="mRed" checked><span>Ajouter les ${F.redirects.length} redirections</span></label><select id="mFmt"><option value="htaccess">dans .htaccess (Apache : Hostinger, OVH…)</option><option value="netlify">dans _redirects (Netlify, Cloudflare)</option></select>` : ''}
      <p class="muted" style="font-size:14px">Chaque fichier modifié est d’abord copié dans le dossier .vantix-backups. Vous pourrez tout annuler en un clic.</p>
      <div class="acts"><button class="ghostbtn" data-close>Annuler</button><button class="btn" id="mGo">Appliquer</button></div>`, (m, close) => {
      $('#mGo', m).addEventListener('click', async () => {
        const opts = { siteFiles: $('#mFiles', m).checked, redirects: $('#mRed', m) ? $('#mRed', m).checked : false, redirectFormat: $('#mFmt', m) ? $('#mFmt', m).value : null };
        $('#mGo', m).disabled = true; $('#mGo', m).textContent = 'Application…';
        try {
          const ops = VX.fixes.localOps(report, F, opts);
          const r = await api.applyLocal(root, ops);
          lastApply = { root, report: r };
          close(); fixesTab(el);
          toast(r.done ? `${r.done} corrections appliquées` : 'Rien à modifier : tout était déjà correct');
        } catch (e) { $('#mGo', m).disabled = false; $('#mGo', m).textContent = 'Appliquer'; toast('Échec : ' + e.message); }
      });
    });
  }

  async function aiRewrite(el, btn) {
    if (!api || !api.aiHasKey) return toast('Disponible dans l’application de bureau.');
    if (!(await api.aiHasKey())) return openAiSettings(() => aiRewrite(el, btn));
    const F = report.fixes;
    const items = F.pageFixes.filter(pf => pf.fixes.some(f => (f.type === 'title' || f.type === 'description') && f.enabled)).map(pf => {
      const p = pageIndex.get(pf.url) || {};
      return { url: pf.url, title_actuel: p.title || '', h1: (p.h1 || [])[0] || '', intro: (p.geo && p.geo.firstParagraph) || '', mots_cles: (p.keywords || []).slice(0, 6).map(k => k[0]), description_actuelle: p.description || '' };
    });
    if (!items.length) return toast('Aucun title ni description à réécrire.');
    btn.disabled = true; btn.textContent = `Réécriture de ${items.length} pages…`;
    try {
      let model = 'claude-haiku-5-5'; try { model = localStorage.getItem('vx-ai-model') || model; } catch {}
      const res = await api.aiRewrite({ model, items, brand: F.brand, lang: F.lang });
      VX.fixes.mergeAi(F, res);
      toast(`${res.length} pages réécrites par l’IA`);
      fixesTab(el);
    } catch (e) { toast('IA : ' + e.message); btn.disabled = false; btn.textContent = 'Réécrire avec l’IA'; }
  }

  async function openAiSettings(after) {
    if (!api || !api.aiHasKey) return toast('Disponible dans l’application de bureau.');
    const hasKey = await api.aiHasKey();
    let model = 'claude-haiku-5-5'; try { model = localStorage.getItem('vx-ai-model') || model; } catch {}
    modal(`<h2>Clé API Claude</h2>
      <p>Optionnelle. Avec une clé, VANTIX fait réécrire les titles et les descriptions par Claude. Sans clé, les propositions sont générées par des règles.</p>
      <p class="muted" style="font-size:14px">Créez une clé sur console.anthropic.com, rubrique API Keys. Comptez environ un centime pour 15 pages avec le modèle rapide. La clé est chiffrée par votre système et ne quitte votre ordinateur que pour appeler Claude.</p>
      <input type="password" id="mKey" placeholder="${hasKey ? 'Clé enregistrée : laisser vide pour la garder' : 'sk-ant-…'}" autocomplete="off" spellcheck="false" aria-label="Clé API">
      <select id="mModel" aria-label="Modèle"><option value="claude-haiku-5-5">Rapide et économique (Claude Haiku)</option><option value="claude-sonnet-5-5">Meilleure rédaction (Claude Sonnet)</option></select>
      <div class="acts">${hasKey ? '<button class="ghostbtn" id="mDel">Supprimer la clé</button>' : ''}<button class="ghostbtn" data-close>Fermer</button><button class="btn" id="mSave">Enregistrer</button></div>`, (m, close) => {
      $('#mModel', m).value = model;
      const del = $('#mDel', m); if (del) del.addEventListener('click', async () => { await api.aiSetKey(''); toast('Clé supprimée'); close(); });
      $('#mSave', m).addEventListener('click', async () => {
        try { localStorage.setItem('vx-ai-model', $('#mModel', m).value); } catch {}
        const k = $('#mKey', m).value.trim();
        try {
          if (k) { if (!/^sk-ant-/.test(k)) { toast('Cette clé ne ressemble pas à une clé Claude (sk-ant-…)'); return; } await api.aiSetKey(k); toast('Clé enregistrée'); }
          close(); if (after && (k || hasKey)) after();
        } catch (e) { toast(e.message); }
      });
    });
  }
  $('#aiBtn').addEventListener('click', () => openAiSettings());

  refreshHistory();
  setTimeout(() => $('#url').focus(), 100);
  window.__vxOpenReport = openReport; // utilisé par les tests
  window.__vxUi = { toast, modal, esc, show, $, $$, fmt }; // partagé avec le Radar IA
})();
