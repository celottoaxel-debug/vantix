// VANTIX — exports : rapport HTML autonome, CSV (pages, liens, problèmes), JSON
(function (VX) {
  'use strict';
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const csvCell = (v) => { const s = v == null ? '' : String(v); return /[";\n,]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  const csv = (rows) => '﻿' + rows.map(r => r.map(csvCell).join(';')).join('\r\n');
  const SEV_LABEL = { critique: 'Critique', important: 'Important', mineur: 'Mineur', info: 'Info' };

  function pagesCsv(r) {
    const head = ['URL', 'Statut', 'Redirige vers', 'Title', 'Longueur title', 'Meta description', 'Longueur description', 'H1', 'Mots', 'Lisibilité', 'Mot principal', 'Profondeur', 'Liens entrants', 'Liens sortants', 'Temps (ms)', 'TTFB (ms)', 'Poids (octets)', 'Compression', 'Canonical', 'Noindex', 'Dans le sitemap', 'Images sans alt', 'Schema.org', 'Problèmes'];
    return csv([head, ...r.pages.map(p => [p.url, p.status, p.redirectTo || '', p.title || '', (p.title || '').length, p.description || '', (p.description || '').length, (p.h1 || []).join(' | '), p.mainWordCount || '', p.readability ?? '', p.focus ? p.focus.word : '', p.depth ?? 'orpheline', p.inlinks || 0, (p.links || []).length, p.timeMs || '', p.ttfbMs || '', p.bytes || '', p.headers ? p.headers.encoding || 'non' : '', p.canonical || '', p.noindex ? 'oui' : '', p.inSitemap ? 'oui' : 'non', p.images ? p.images.noAlt : '', p.schema ? p.schema.types.join(', ') : '', (p.issueIds || []).length])]);
  }
  function linksCsv(r) {
    return csv([['Page source', 'Lien vers', 'Type', 'Interne', 'Statut', 'Redirigé', 'Texte du lien', 'nofollow', 'sponsored', 'ugc'],
      ...r.links.map(l => [l.from, l.to, l.kind, l.internal ? 'oui' : 'non', l.status ?? (l.error || ''), l.redirect ? 'oui' : '', l.anchor, l.nofollow ? 'oui' : '', l.sponsored ? 'oui' : '', l.ugc ? 'oui' : ''])]);
  }
  function issuesCsv(r) {
    const rows = [['Gravité', 'Catégorie', 'Problème', 'URL', 'Détail', 'Comment corriger']];
    for (const i of r.issues) for (const it of i.items) rows.push([SEV_LABEL[i.sev], r.categories[i.cat], i.title, it.url, it.detail || '', i.fix]);
    return csv(rows);
  }

  function html(r) {
    const ring = (v, label, color) => `<div class="sc"><svg viewBox="0 0 96 96"><circle cx="48" cy="48" r="40" fill="none" stroke="#1d1d24" stroke-width="7"/><circle cx="48" cy="48" r="40" fill="none" stroke="${color}" stroke-width="7" stroke-linecap="round" stroke-dasharray="${(2 * Math.PI * 40 * v / 100).toFixed(1)} 999" transform="rotate(-90 48 48)"/><text x="48" y="55" text-anchor="middle" fill="#fff" font-size="24" font-family="Arial">${v}</text></svg><span>${label}</span></div>`;
    const sevColor = { critique: '#ff5a6e', important: '#ffb829', mineur: '#8f8fa3', info: '#5b8cff' };
    return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rapport VANTIX · ${esc(r.host)}</title>
<style>body{margin:0;background:#050507;color:#f4f4f6;font:15px/1.55 -apple-system,Segoe UI,Roboto,Arial,sans-serif}main{max-width:1100px;margin:0 auto;padding:48px 24px}h1{font-weight:300;font-size:44px;letter-spacing:-.03em;margin:0}h2{font-weight:400;font-size:24px;margin:48px 0 16px}.muted{color:#9a9aa6}.scores{display:flex;flex-wrap:wrap;gap:28px;margin-top:32px}.sc{display:flex;flex-direction:column;align-items:center;gap:8px;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#9a9aa6}.sc svg{width:96px}.stats{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-top:28px}.stat{background:#0e0e13;border-radius:14px;padding:14px 16px}.stat b{display:block;font-size:24px;font-weight:400}.stat span{font-size:12px;color:#9a9aa6}details{background:#0e0e13;border-radius:14px;margin:10px 0;padding:14px 18px}summary{cursor:pointer;font-size:16px}.sev{display:inline-block;font-size:11px;text-transform:uppercase;letter-spacing:.06em;padding:3px 8px;border-radius:99px;margin-right:10px}.fix{margin:10px 0;padding:10px 14px;border-left:2px solid #8052ff;background:#13131a;border-radius:8px}ul{margin:8px 0 0;padding-left:18px;font-size:13px;color:#cfcfd8;word-break:break-all}table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:8px;border-bottom:1px solid #1d1d24;text-align:left;vertical-align:top;word-break:break-all}th{color:#9a9aa6;font-weight:400}</style></head><body><main>
<p class="muted">Rapport VANTIX · ${new Date(r.date).toLocaleString('fr-FR')}</p><h1>${esc(r.host)}</h1>
<div class="scores">${ring(r.scores.global, 'Global', '#8052ff')}${ring(r.scores.seo, 'SEO', '#a98bff')}${ring(r.scores.geo, 'GEO', '#ffb829')}${ring(r.scores.technique, 'Technique', '#4d8bff')}${ring(r.scores.contenu, 'Contenu', '#2fbf8f')}${ring(r.scores.liens, 'Liens', '#d14cff')}</div>
<div class="stats">${[[r.stats.pages, 'adresses explorées'], [r.stats.indexable, 'pages indexables'], [r.stats.words.toLocaleString('fr-FR'), 'mots analysés'], [r.stats.links.toLocaleString('fr-FR'), 'liens indexés'], [r.stats.brokenLinks, 'liens cassés'], [r.stats.avgTime + ' ms', 'temps moyen'], [r.stats.critical, 'problèmes critiques'], [r.stats.issues, 'types de problèmes']].map(([b, s]) => `<div class="stat"><b>${b}</b><span>${s}</span></div>`).join('')}</div>
<h2>Problèmes à corriger</h2>${r.issues.map(i => `<details><summary><span class="sev" style="background:${sevColor[i.sev]}22;color:${sevColor[i.sev]}">${SEV_LABEL[i.sev]}</span>${esc(i.title)} <span class="muted">· ${i.items.length}</span></summary><p class="muted">${esc(i.why)}</p><div class="fix">${esc(i.fix)}</div><ul>${i.items.slice(0, 200).map(it => `<li>${esc(it.url)}${it.detail ? ' · ' + esc(it.detail) : ''}</li>`).join('')}${i.items.length > 200 ? `<li>… et ${i.items.length - 200} autres</li>` : ''}</ul></details>`).join('')}
<h2>Mots les plus présents sur le site</h2><p class="muted">${r.keywords.slice(0, 60).map(([w, c, n]) => `${esc(w)} (${c})`).join(' · ')}</p>
<h2>Robots d'IA</h2><table><tr><th>Robot</th><th>Accès à l'accueil</th><th>Règle explicite</th></tr>${r.robots.ai.map(b => `<tr><td>${b.bot}</td><td>${b.home ? 'autorisé' : '<b style="color:#ff5a6e">bloqué</b>'}</td><td>${b.explicit ? 'oui' : 'non'}</td></tr>`).join('')}</table>
<h2>Pages</h2><table><tr><th>URL</th><th>Statut</th><th>Mots</th><th>Profondeur</th><th>Temps</th></tr>${r.pages.slice(0, 2000).map(p => `<tr><td>${esc(p.url)}</td><td>${p.status}</td><td>${p.mainWordCount ?? ''}</td><td>${p.depth ?? 'orpheline'}</td><td>${p.timeMs ?? ''} ms</td></tr>`).join('')}</table>
<p class="muted" style="margin-top:48px">Généré par VANTIX Desktop</p></main></body></html>`;
  }

  VX.report = { pagesCsv, linksCsv, issuesCsv, html, esc };
})(window.VX = window.VX || {});
